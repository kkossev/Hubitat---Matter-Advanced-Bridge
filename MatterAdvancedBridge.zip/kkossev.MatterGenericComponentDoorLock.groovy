 /*
  *  'Matter Generic Component Door Lock' - component driver for Matter Advanced Bridge
  *
  *  https://community.hubitat.com/t/dynamic-capabilities-commands-and-attributes-for-drivers/98342
  *  https://community.hubitat.com/t/project-zemismart-m1-matter-bridge-for-tuya-zigbee-devices-matter/127009
  *
  *  Licensed Virtual the Apache License, Version 2.0 (the "License"); you may not use this file except
  *  in compliance with the License. You may obtain a copy of the License at:
  *
  *      http://www.apache.org/licenses/LICENSE-2.0
  *
  *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
  *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
  *  for the specific language governing permissions and limitations under the License.
  *
  * ver. 1.0.0  2024-04-05 dds82   - first version by Daniel Segall
  * ver. 1.1.0  2024-07-20 kkossev - added Battery capability; added Identify command; added warning state and log messages; added handling of unprocessed Door Lock events
  * ver. 1.1.1  2024-07-23 kkossev - added switch capability (for Apple Home integration workaround)
  * ver. 1.1.2  2024-08-12 kkossev - fixed importURL
  * ver. 1.2.0  2025-01-10 kkossev + Calude Sonnet 4.5 : Matter events handling rework; Door Lock working! :) added ping command and RTT attribute; removed switch capability
  * ver. 1.3.0  2025-01-14 kkossev - moved component methods from parent to component driver; major refactoring 
  * ver. 1.3.1  2025-01-22 kkossev + Claude Haiku 4.5 : Aqara U200 Door Lock support improvements (clearUser seems to be working!)
  * ver. 1.3.2  2025-01-25 kkossev + GPT-4.1 : newParse: true decoding; use matterCommonLib; capability 'LockCodes' is commented out temporarily: (lock codes still not working)
  * ver. 1.3.3  2025-02-06 kkossev   added events 'locking', 'unlocking' for better UI feedback; experimenting ...
  * ver. 1.3.4  2025-02-19 kkossev   moved common methods to matterCommonLib;
  * ver. 1.4.0  2026-05-25 kkossev   capability 'LockCodes' attempt (blind implementation) - first test version.
  * ver. 1.4.1  2026-05-27 kkossev   (dev. branch) fixed EZ dashboards unhappy face; added unlockWithTimeout command; added UnboltDoor command; 
  *                                  DuplicateDoorLockEventFilter; added the needed data: Map required by the LCM 
  * 
  *                                  TODO: 
  *                                  TODO: 
  *                                  TODO: 
  *                                  TODO: add [physical] [digital] event type to events and logs
  *                                  TODO: analyze https://github.com/SmartThingsCommunity/SmartThingsEdgeDrivers/tree/main/drivers/SmartThings/matter-lock 
  *                                  TODO: analyze https://matter-survey.org/cluster/0x0101
  *                                  TODO: update gitHub documentation
  *                                  
  *   WORKING MATTER functions       :  identify(), lock(), unlock(), unlockWithTimeout (0x03), unboltDoor (0x27), matterSetCredentialPIN (0x22), matterClearCredential (0x26), 
  *                                  
  *
*/

import groovy.transform.Field
import groovy.transform.CompileStatic
import hubitat.helper.HexUtils
import hubitat.matter.DataType
import groovy.json.JsonOutput


@Field static final String matterComponentLockVersion = '1.4.1'
@Field static final String matterComponentLockStamp   = '2026/05/27 7:28 AM'

@Field static final Boolean _DEBUG_LOCK = false             // MAKE IT false for PRODUCTION !   
@Field static final Boolean _DEFAULT_LOG_ENABLE = false     // disable on production

@Field static final Integer DELETE_TIMEOUT_SECONDS = 5      // time to wait for lock code deletion confirmation event before removing code from lockCodes attribute (to avoid ghost codes in case of failed deletion)
@Field static final Integer SET_CODE_TIMEOUT_SECONDS = 45  // time to wait for lock code set confirmation event before clearing 'setting...' status in lockCodes attribute (to avoid stuck 'setting...' status in case of failed set)

metadata {
    definition(name: 'Matter Generic Component Door Lock', namespace: 'kkossev', author: 'Krassimir Kossev', importUrl: 'https://raw.githubusercontent.com/kkossev/Hubitat---Matter-Advanced-Bridge/development/Components/Matter_Generic_Component_Door_Lock') {
        capability 'Sensor'
        capability 'Actuator'
        capability 'Battery'
        capability 'Lock'       // lock - ENUM ["locked", "unlocked with timeout", "unlocked", "unknown"]
        capability 'LockCodes'  // lockCodes, codeChanged, codeLength, maxCodes | setCode(pos,pin,name), deleteCode(pos), getCodes(), setCodeLength(len)
        capability 'Refresh'

        command    'identify', [[name: 'Identify the lock device']]
        command    'getInfo', [[name: 'Check the live logs and the device data for additional infoormation on this device']]
        command    'unlockWithTimeout', [[name: 'timeout*', type: 'NUMBER', description: 'Auto-relock timeout in seconds (1-65535)']]
        command    'unboltDoor', [[name: 'Unbolt door (latch retraction only, not available on all locks)']]
        command    'clearStatistics', [[name: 'Clear event statistics counters and duplicate-event cache']]
        /*
        //command    'unlockWithPIN', [[name: 'pin*', type: 'STRING', description: 'unlock with PIN (not available on all locks)']]
        
        // LockCodes custom commands with dynamic feature support indication
        command    'setCode', [[name: 'codePosition*', type: 'NUMBER', description: 'Code slot (1-based)'],
                               [name: 'pinCode*', type: 'STRING', description: 'PIN code (4-8 digits)'],
                               [name: 'name', type: 'STRING', description: "User name (optional)<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        command    'deleteCode', [[name: 'codePosition*', type: 'NUMBER', description: "Code slot to delete<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        command    'getCodes', [[name: "Retrieve all PIN codes<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        */
        // TODO - move these to state variables or device data ?
        // attribute 'lock', 'ENUM', ["locked", "unlocked with timeout", "unlocked", "unknown", "locking", "unlocking"]  // added 'locking' and 'unlocking' for better UI feedback during lock/unlock operations
        // lockType, actuatorEnabled, operatingMode, supportedOperatingModes are stored in state.lockAttr (not Hubitat attributes)
        
        // Event-related attributes
        // TODO: consider moving these to state variables or device data instead of attributes ?
        attribute 'lastLockOperation', 'STRING'
        attribute 'lastOperationSource', 'STRING'
        attribute 'lastLockOperationError', 'STRING'
        attribute 'lastUserChange', 'STRING'
        attribute 'lastCodeName', 'STRING'
        attribute 'lockAlarm', 'STRING'
        attribute 'doorState', 'STRING'
        
        // Infrastructure/health-check attributes
        attribute 'powerSourceStatus', 'ENUM', ['active', 'standby', 'unavailable']

        if (_DEBUG_LOCK) {
              command  'matterSetCredentialPIN' , [[name:'credentialIndex*', type: 'NUMBER', description: 'Credential Index (1-255)', defaultValue: '1'],
                                           [name:'pinCode*', type: 'STRING', description: 'PIN code (4-8 digits)', defaultValue: '1234'],
                                           [name:'userIndex', type: 'NUMBER', description: 'User Index (1-65534)', defaultValue: '1']]
              command 'matterClearCredential', [[name:'credentialType*', type: 'NUMBER', description: 'Credential Type (0:ProgrammingPIN,1:PIN,2:RFID,3:Fingerprint,4:FingerVein,5:Face)', defaultValue: '1'],
                                     [name:'credentialIndex', type: 'NUMBER', description: 'Credential Index (0 to clear all)', defaultValue: '9']]

              //command 'matterGetCredentialStatus', [[name:'pinIndex*', type: 'STRING', description: 'PIN Index (1-255)', defaultValue: '1']]
              //command 'matterGetUser', [[name:'userIndex*', type: 'STRING', description: 'User Index (0-65534)', defaultValue: '1']]
              //command 'matterClearUser', [[name:'userIndex*', type: 'STRING', description: 'User Index (0-65534)', defaultValue: '1']]
              /*
              command 'matterSetUser', [[name: 'codePosition*', type: 'NUMBER', description: 'Code slot (1-based)'],
                                           [name: 'pinCode*', type: 'STRING', description: 'PIN code (4-8 digits)'],
                                           [name: 'name', type: 'STRING', description: "User name (optional)<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
              */
            command 'testInvoke', [[name: 'testInvoke', type: 'STRING', description: 'test', defaultValue : '']]    // for debug purposes only
            command 'testUnlockWithCode', [[name: 'pinCode', type: 'STRING', description: 'Simulate physical unlock with this PIN code', defaultValue: '1234']]
        }
    }
}

preferences {
    section {
	    input name: "helpInfo", type: "hidden", title: fmtHelpInfo("Community Link")
        input name: 'logEnable',
              type: 'bool',
              title: '<b>Enable debug logging</b>',
              required: false,
              defaultValue: _DEFAULT_LOG_ENABLE

        input name: 'txtEnable',
              type: 'bool',
              title: '<b>Enable descriptionText logging</b>',
              required: false,
              defaultValue: true
        //input name: 'optEncrypt', type: 'bool', title: '<b>Enable lockCode encryption</b>', description: '<i>Encrypt PIN codes stored in lockCodes attribute and codeChanged events</i>', defaultValue: false
        input name: 'advancedOptions', type: 'bool', title: '<b>Advanced Options</b>', description: '<i>These advanced options should be already automatically set in an optimal way for your device...</i>', defaultValue: false
        if (device && advancedOptions == true) {
            input name: 'ignoreCompatibilityChecks', type: 'bool', title: '<b>Ignore Compatibility Checks</b>', description: '<i>Allow executing commands that may not be supported by this lock</i>', defaultValue: false
        }

    }
}


void parse(String description) { log.warn 'parse(String description) not implemented' }

// parse commands from parent
void parse(List<Map> parsedEvents) {
    //if (logEnable) { log.debug "${parsedEvents}" }
    parsedEvents.each { d ->
        if (d.name == 'lock') {
            if (device.currentValue('lock') != d.value) {
                if (d.descriptionText) { logInfo "${d.descriptionText}" }
                sendEvent(d)
            }
            else {
                logDebug "parse: ${parsedEvents} : ignored lock event '${d.value}' (no change)"
            }
        }
        else if (d.name == 'rtt') {
            // Delegate to health status library
            parseRttEvent(d)
        }
        else if (d.name in  ['unprocessed', 'handleInChildDriver']) {
            handleLockMessage(d)
        }
        else {
            if (d.descriptionText) { logInfo "${d.descriptionText}" }
            sendEvent(d)
        }
    }
}

void handleLockMessage(Map description) {
    //logDebug "handleLockMessage: description = ${description}"
    Map descMap =[:]
    try {
        descMap = description.value as Map
    }
    catch (e) {
        logWarn "handleLockMessage: exception ${e} while parsing description.value = ${description.value}"
        return
    }
    logDebug "handleLockMessage: parsed descMap = ${descMap}"
    if (descMap.cluster != '0101') { logWarn "handleLockMessage: unexpected cluster:${descMap.cluster} (attrId:${descMap.attrId})"; return }

    // Check if this is an event (has evtId) or an attribute (has attrId)
    if (descMap.evtId != null) {
        if (isDuplicateDoorLockEvent(descMap)) {
            logDebug "handleLockMessage: filtered duplicated Door Lock event evtId=${descMap.evtId}, eventSerial=${descMap.eventSerial}"
            return
        }
        processDoorLockEvent(descMap)
        return
    }
    // else - process attribute report
    processDoorLockAttributeReport(descMap)
}

// Maps Door Lock cluster attrId → state.lockAttr key for automatic raw-integer storage.
// All values are stored as Integer via safeHexToInt(descMap.value).
// Excluded: 0000 LockState (lives in 'lock' attribute), 0021 Language (String, handled explicitly),
//           0042-0047 event masks (verbose), 0080-0088 Nuki non-standard,
//           FFFC/FFFB/FFFD/FFF8/FFF9 (already in fingerprintData).
@Field static final Map<String, String> LOCK_ATTR_STORE = [
    // Group A — core device characteristics
    '0001': 'lockType',                 '0002': 'actuatorEnabled',          '0003': 'doorState',
    '0011': 'numberOfTotalUsers',       '0012': 'numberOfPINUsers',
    '0017': 'maxPINCodeLength',         '0018': 'minPINCodeLength',
    '001B': 'credentialRulesSupport',   '001C': 'numberOfCredentialsPerUser',
    '0025': 'operatingMode',            '0026': 'supportedOperatingModes',
    '0030': 'wrongCodeEntryLimit',      '0031': 'userCodeTempDisableTime',
    '0033': 'requirePINforRemoteOp',
    // Group B — optional configuration
    '0004': 'doorOpenEvents',           '0005': 'doorClosedEvents',         '0006': 'openPeriod',
    '0010': 'numberOfLogRecords',       '0013': 'numberOfRFIDUsers',
    '0014': 'weekDaySchedulesPerUser',  '0015': 'yearDaySchedulesPerUser',  '0016': 'numberOfHolidaySchedules',
    '0019': 'maxRFIDCodeLength',        '001A': 'minRFIDCodeLength',
    '0020': 'enableLogging',
    '0022': 'ledSettings',              '0023': 'autoRelockTime',           '0024': 'soundVolume',
    '0027': 'defaultConfigRegister',
    '0028': 'enableLocalProgramming',   '0029': 'enableOneTouchLocking',
    '002A': 'enableInsideStatusLED',    '002B': 'enablePrivacyModeButton',  '002C': 'localProgrammingFeatures',
    '0032': 'sendPINoverTheAir',        '0034': 'securityLevel',            '0035': 'expiringUserTimeout',
]
void processDoorLockAttributeReport(Map descMap) {
    
    if (state.lockAttr == null) { state.lockAttr = [:] }
    String eventValue = descMap.value
    String descriptionText = "${device.displayName} ${descMap.cluster}:${descMap.attrId} value:${eventValue}"
    
    // Declare variables for conditional logging
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${descMap.attrId}] " : ""
    String message = null
    boolean useDebugLog = false  // Flag to use logDebug instead of logInfo when isInfoMode is false
    
    switch (descMap.attrId) {
        case '0000': // LockState
            // LockState is typically handled by parent driver
            // But log it here for debugging if it arrives
            String lockStateText = DoorLockClusterLockState[safeHexToInt(descMap.value)] ?: "Unknown (${descMap.value})"
            message = "${prefix}LockState: ${lockStateText} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0001': // LockType
            eventValue= DooorLockClusterLockType[safeHexToInt(descMap.value)]
            message = "${prefix}lockType: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0002': // ActuatorEnabled
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}ActuatorEnabled: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0003': // DoorState
            Integer doorStateValue = safeHexToInt(descMap.value)
            eventValue = DoorLockClusterDoorState[doorStateValue] ?: "Unknown/OutOfSpec"
            if (doorStateValue > 0x05) {
                message = "${prefix}DoorState: ${eventValue} (raw:0x${descMap.value} - value out of spec 0x00-0x05)"
            } else {
                descriptionText = "${device.displayName} DoorState: ${eventValue} (raw:${descMap.value})"
                //sendEvent(name: 'doorState', value: eventValue, descriptionText: descriptionText)
                message = "${prefix}DoorState: ${eventValue} (raw:${descMap.value})"
            }
            useDebugLog = true
            break
        case '0004': // DoorOpenEvents
            Integer doorOpenEvents = safeHexToInt(descMap.value)
            message = "${prefix}DoorOpenEvents: ${doorOpenEvents}"
            break
        case '0005': // DoorClosedEvents
            Integer doorClosedEvents = safeHexToInt(descMap.value)
            message = "${prefix}DoorClosedEvents: ${doorClosedEvents}"
            break
        case '0006': // OpenPeriod
            Integer openPeriod = safeHexToInt(descMap.value)
            message = "${prefix}OpenPeriod: ${openPeriod} minutes"
            break
        case '0010': // NumberOfLogRecordsSupported
            message = processNumericAttribute('NumberOfLogRecordsSupported', descMap)
            break
        case '0011': // NumberOfTotalUsersSupported
            message = processNumericAttribute('NumberOfTotalUsersSupported', descMap)
            sendEvent(name: 'maxCodes', value: safeHexToInt(descMap.value), descriptionText: "${device.displayName} supports up to ${safeHexToInt(descMap.value)} total users")
            break
        case '0012': // NumberOfPINUsersSupported
            message = processNumericAttribute('NumberOfPINUsersSupported', descMap)
            break
        case '0013': // NumberOfRFIDUsersSupported
            message = processNumericAttribute('NumberOfRFIDUsersSupported', descMap)
            break
        case '0014': // NumberOfWeekDaySchedulesSupportedPerUser
            message = processNumericAttribute('NumberOfWeekDaySchedulesSupportedPerUser', descMap)
            break
        case '0015': // NumberOfYearDaySchedulesSupportedPerUser
            message = processNumericAttribute('NumberOfYearDaySchedulesSupportedPerUser', descMap)
            break
        case '0016': // NumberOfHolidaySchedulesSupported
            message = processNumericAttribute('NumberOfHolidaySchedulesSupported', descMap)
            break
        case '0017': // MaxPINCodeLength
            Integer maxPinLength = safeHexToInt(descMap.value)
            descriptionText = "${device.displayName} maximum PIN code length is ${maxPinLength}"
            sendEvent(name: 'codeLength', value: maxPinLength, type: 'physical', descriptionText: descriptionText)
            message = "${prefix}MaxPINCodeLength: ${maxPinLength}"
            break
        case '0018': // MinPINCodeLength
            Integer minPinLength = safeHexToInt(descMap.value)
            message = "${prefix}MinPINCodeLength: ${minPinLength}"
            break
        case '0019': // MaxRFIDCodeLength
            message = processNumericAttribute('MaxRFIDCodeLength', descMap)
            break
        case '001A': // MinRFIDCodeLength
            message = processNumericAttribute('MinRFIDCodeLength', descMap)
            break
        case '001B': // CredentialRulesSupport
            Integer credRules = safeHexToInt(descMap.value)
            String credRulesText = decodeCredentialRules(credRules)
            message = "${prefix}CredentialRulesSupport: ${credRulesText} (0x${descMap.value})"
            break
        case '001C': // NumberOfCredentialsSupportedPerUser
            message = processNumericAttribute('NumberOfCredentialsSupportedPerUser', descMap)
            break
        case '0020': // EnableLogging
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableLogging: ${eventValue} (raw:${descMap.value})"
            break
        case '0021': // Language
            String language = descMap.value instanceof List ? descMap.value.join('') : descMap.value
            state.lockAttr['language'] = language
            message = "${prefix}Language: ${language}"
            break
        case '0022': // LEDSettings
            Integer ledSettings = safeHexToInt(descMap.value)
            message = "${prefix}LEDSettings: 0x${descMap.value}"
            break
        case '0023': // AutoRelockTime
            Integer autoRelockTime = safeHexToInt(descMap.value)
            message = "${prefix}AutoRelockTime: ${autoRelockTime} seconds"
            break
        case '0024': // SoundVolume
            Integer soundVolume = safeHexToInt(descMap.value)
            message = "${prefix}SoundVolume: ${soundVolume}"
            break
        case '0025' : // OperatingMode
            // OperatingMode: 00 (raw:00)
            eventValue = DoorLockClusterOperatingModeEnum[safeHexToInt(descMap.value)]
            message = "${prefix}OperatingMode: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0026' : // SupportedOperatingModes
            // SupportedOperatingModes: FFF6 (raw:FFF6)
            Integer intValue = safeHexToInt(descMap.value)
            List<String> supportedModes = []
            // Iterate through each bit position and check if the corresponding bit in eventValue is set to 0
            DoorLockClusterSupportedOperatingModes.each { bitPosition, modeName ->
                if ((intValue & (1 << bitPosition)) == 0) {/* ...existing code... */}
            }
            String supportedModesString = supportedModes.join(', ')
            state.lockAttr['supportedOperatingModes'] = supportedModesString    // decoded string kept for display (raw bitmap stored by generic block below)
            message = "${prefix}SupportedOperatingModes: ${supportedModesString} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0027': // DefaultConfigurationRegister
            message = "${prefix}DefaultConfigurationRegister: 0x${descMap.value}"
            break
        case '0028': // EnableLocalProgramming
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableLocalProgramming: ${eventValue} (raw:${descMap.value})"
            break
        case '0029': // EnableOneTouchLocking
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableOneTouchLocking: ${eventValue} (raw:${descMap.value})"
            break
        case '002A': // EnableInsideStatusLED
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableInsideStatusLED: ${eventValue} (raw:${descMap.value})"
            break
        case '002B': // EnablePrivacyModeButton
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnablePrivacyModeButton: ${eventValue} (raw:${descMap.value})"
            break
        case '002C': // LocalProgrammingFeatures
            message = "${prefix}LocalProgrammingFeatures: 0x${descMap.value}"
            break
        case '0030': // WrongCodeEntryLimit
            Integer wrongCodeLimit = safeHexToInt(descMap.value)
            message = "${prefix}WrongCodeEntryLimit: ${wrongCodeLimit}"
            break
        case '0031': // UserCodeTemporaryDisableTime
            Integer disableTime = safeHexToInt(descMap.value)
            message = "${prefix}UserCodeTemporaryDisableTime: ${disableTime} seconds"
            break
        case '0032': // SendPINOverTheAir
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}SendPINoverTheAir: ${eventValue} (raw:${descMap.value})"
            break
        case '0033': // RequirePINforRemoteOperation
            eventValue = descMap.value == '01' ? 'required' : 'not required'
            message = "${prefix}RequirePINforRemoteOperation: ${eventValue} (raw:${descMap.value})"
            break
        case '0034': // SecurityLevel (Deprecated)
            Integer securityLevel = safeHexToInt(descMap.value)
            String securityLevelName = ['Unspecified', 'Low', 'Medium', 'High'][securityLevel] ?: "Unknown(${securityLevel})"
            message = "${prefix}SecurityLevel: ${securityLevelName} (deprecated, raw:${descMap.value})"
            break
        case '0035': // ExpiringUserTimeout
            Integer expiringUserTimeout = safeHexToInt(descMap.value)
            message = "${prefix}ExpiringUserTimeout: ${expiringUserTimeout} minutes"
            break
        case '0042': // RemoteOperationEventMask
            message = processEventMaskAttribute('0042', 'RemoteOperationEventMask', descMap, this.&decodeRemoteOperationEventMask)
            useDebugLog = true
            break
        case '0043': // ManualOperationEventMask
            message = processEventMaskAttribute('0043', 'ManualOperationEventMask', descMap, this.&decodeManualOperationEventMask)
            useDebugLog = true
            break
        case '0044': // RFIDOperationEventMask
            message = processEventMaskAttribute('0044', 'RFIDOperationEventMask', descMap, this.&decodeRFIDOperationEventMask)
            useDebugLog = true
            break
        case '0045': // KeypadProgrammingEventMask
            message = processEventMaskAttribute('0045', 'KeypadProgrammingEventMask', descMap, this.&decodeKeypadProgrammingEventMask)
            // NOTE: Nuki disables PINCleared (0x08) and PINChanged (0x10) events
            // This means PIN deletion/modification events won't be received automatically
            useDebugLog = true
            break
        case '0046': // RemoteProgrammingEventMask
            message = processEventMaskAttribute('0046', 'RemoteProgrammingEventMask', descMap, this.&decodeRemoteProgrammingEventMask)
            useDebugLog = true
            break
        case '0047': // RFIDProgrammingEventMask
            message = processEventMaskAttribute('0047', 'RFIDProgrammingEventMask', descMap, this.&decodeRFIDProgrammingEventMask)
            useDebugLog = true
            break
        case '0080': // Nuki non-standard attribute (spec=0x40 AlarmMask)
        case '0081': // Nuki non-standard attribute (spec=0x41 KeypadOperationEventMask)
        case '0082': // Nuki non-standard attribute (spec=0x42 RemoteOperationEventMask)
        case '0083': // Nuki non-standard attribute (spec=0x43 ManualOperationEventMask)
        case '0087': // Nuki non-standard attribute (spec=0x44 RFIDOperationEventMask)
        case '0088': // Nuki non-standard attribute (spec=0x45 KeypadProgrammingEventMask)
            message = "${prefix} UNKNOWN Nuki non-standard attribute 0x${descMap.attrId}: ${descMap.value}"
            break
        case 'FFFC': // FeatureMap
            Integer featureMap = safeHexToInt(descMap.value)
            String featuresText = decodeFeatureMap(featureMap)
            // FeatureMapRaw is stored in fingerprintData as '0101_FFFC'
            message = "${prefix}FeatureMap: ${featuresText} (0x${descMap.value})"
            break
        case 'FFFB': // AttributeList
            // AttributeList is stored in fingerprintData, no need to store separately
            message = "${prefix}AttributeList: ${descMap.value}"
            useDebugLog = true
            // device.updateDataValue('AttributeList', ...) - removed, now in fingerprintData
            break
        case 'FFFD': // ClusterRevision
            Integer revision = safeHexToInt(descMap.value)
            message = "${prefix}ClusterRevision: ${revision}"
            break
        case 'FFF8': // GeneratedCommandList (events supported) - stored in fingerprintData only
            message = "${prefix}GeneratedCommandList: ${descMap.value}"
            useDebugLog = true
            // Data is in fingerprintData['0101_FFF8'], no duplicate storage needed
            break
        case 'FFF9': // AcceptedCommandList - stored in fingerprintData only
            message = "${prefix}AcceptedCommandList: ${descMap.value}"
            useDebugLog = true
            // Data is in fingerprintData['0101_FFF9'], no duplicate storage needed
            break
        default:
            // Check for command responses
            if (descMap.cmdId == '25' || descMap.value?.contains('credentialExists')) {
                processGetCredentialStatusResponse(descMap)
            } else if (descMap.cmdId == '28' || descMap.value?.contains('userName')) {
                processGetUserResponse(descMap)
            } else {
                logWarn "handleLockMessage: unexpected attrId:${descMap.attrId}"
            }
            break
    }
    
    // Conditional logging after the switch
    if (message != null) {
        if (isInfoMode) {
            logInfo message
        } else {
            if (useDebugLog) {
                logDebug message
            } else {
                logInfo message
            }
        }
    }
    // Store raw integer for every attribute listed in LOCK_ATTR_STORE.
    // Language (0021) is handled explicitly above; all others are numeric.
    String lockAttrKey = LOCK_ATTR_STORE[descMap.attrId]
    if (lockAttrKey != null) {
        state.lockAttr[lockAttrKey] = safeHexToInt(descMap.value)
    }
}


// -------------------------------- Hubitat commands wrappers ----------------------------------
//
// Hubitat Attributes  : lockCodes
//                       codeChanged - ENUM ["added", "changed", "deleted", "failed"]
//                       codeLength
//                       maxCodes 
// Hubitat Commands    : setCode(pos,pin,name), deleteCode(pos), getCodes(), setCodeLength(len)

// Hubitat wrap for setUser
void setCode(codePosition, pinCode, name = null) {
    if (!supportsLockCodes()) {
        logWarn "setCode: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }

    if (state.isSettingCode == true) {
        logDebug "setCode: Previous setCode operation is still in progress, coommand setCode(${codePosition}, ${pinCode}, ${name}) ignored."
        return
    }

    // Hubitat Lock Code Manager app will call setCode with codePosition, pinCode and name, and expects to see the result in the device attributes.
    // setCode() will be called up to 10 times, 4 second apart!
    // we need to prevent calling setCode again until the job is done!
    // the timout timer will be stopped and the state.isSettingCode flag will be cleared when we receive the codeChanged event from the lock (in processDoorLockEvent)
    state.isSettingCode = true
    ensureLockCodeStateMaps()
    // Keep minimal pending request context keyed by credential slot until confirmation event arrives.
    state.pendingSetByCredential["${codePosition}"] = [requestedAt: now(), pinCode: pinCode, name: name]

    runIn(SET_CODE_TIMEOUT_SECONDS, "clearSettingCodeFlagOnTimeout", [overwrite: true])     // 45 seconds !

    // a non-standard codeChanged value - just for better logging and debugging
    String descriptionText = "${device.displayName} setCode: setting code ${codePosition} to ${pinCode} for lock code name ${name}"
    sendEvent(name: 'codeChanged', value: "setting...", descriptionText: descriptionText, isStateChange: true)
    logInfo descriptionText

    matterSetCredentialPIN(codePosition, pinCode)
    // lockCodes and codeChanged will be updated when the lock confirms via LockUserChange event
}   


/**
 * Delete a PIN code (LockCodes capability)
 * @param codePosition Position/slot number (1-based)
 */
void deleteCode(codePosition) {
    logInfo "deleteCode: codePosition=${codePosition}"
    if (!supportsLockCodes()) {
        String msg = "${device.displayName} deleteCode: code position ${codePosition} failed - lock does not support PIN credential management"
        logInfo "deleteCode: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'codeChanged', value: 'failed', descriptionText: msg, isStateChange: true)
        return
    }
    
    state.isDeletingCode = true
    state.lastDeleteCode = [codePosition: codePosition, timestamp: now()]
    runIn(DELETE_TIMEOUT_SECONDS, 'clearDeletingCodeFlagOnTimeout', [overwrite: true])  // 5 seconds should be enough to receive the confirmation event from the lock

    String descriptionText = "${device.displayName} deleteCode: deleting code at position ${codePosition}"
    logInfo descriptionText
    sendEvent(name: 'codeChanged', value: 'deleting...', descriptionText: descriptionText, isStateChange: true)

    matterClearCredential(1, codePosition)
    // confirmation will arrive as LockUserChange event (evtId:4) with dataOpType=1 (Clear)
    // if no confirmation within 5, clearDeletingCodeFlagOnTimeout() fires
}


/**
 * Get all PIN codes (LockCodes capability)
 * Called by HE Lock Code Manager app on 'Request lock codes from all existing devices'
 */
void getCodes() {
    if (!supportsLockCodes()) {
        logWarn "getCodes: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }
    // Re-send the current lockCodes attribute with isStateChange:true so Hubitat Lock Code Manager
    // receives and processes the codes we already have stored locally.
    // Full Matter-based querying (GetUser loop) is not yet implemented.
    String currentCodes = device.currentValue('lockCodes') ?: '{}'
    logInfo "getCodes: re-sending current lockCodes: ${currentCodes}"
    sendEvent(name: 'lockCodes', value: currentCodes, descriptionText: "${device.displayName} getCodes: re-sending current lock codes", isStateChange: true)
}

// Command to set the maximum PIN code length for this lock (per Hubitat LockCodes capability)
// NOTE: Matter locks have FIXED PIN length constraints (MaxPINCodeLength/MinPINCodeLength are read-only)
// This command only updates the Hubitat codeLength attribute for compatibility
void setCodeLength(BigDecimal length) {
    if (!length) {
        logWarn "setCodeLength: PIN code length is required"
        return
    }
    Integer codeLength = length.toInteger()
    if (codeLength < 4 || codeLength > 8) {
        logWarn "setCodeLength: PIN code length must be 4-8 digits, got '${length}'"
        return
    }
    
    logInfo "setCodeLength: updating Hubitat codeLength attribute to ${codeLength} (Matter locks have fixed PIN length constraints)"
    
    // Update codeLength attribute with digital event type for Hubitat compatibility
    sendEvent(name: 'codeLength', value: codeLength, type: 'digital', descriptionText: "${device.displayName} code length set to ${codeLength}")
}

// -------- Hubitat code wrappers helpers ---------

void clearSettingCodeFlagOnTimeout() {
    state.isSettingCode = false
    logDebug "clearSettingCodeFlagOnTimeout: isSettingCode flag cleared (timed out after ${SET_CODE_TIMEOUT_SECONDS} seconds)"
    String descriptionText = "${device.displayName} setCode operation timed out without confirmation from lock (no codeChanged event received)"
    sendEvent(name: 'codeChanged', value: "failed", descriptionText: descriptionText, isStateChange: true)
    logWarn descriptionText
}

void clearDeletingCodeFlagOnTimeout() {
    Integer codePosition = state.lastDeleteCode?.codePosition
    state.isDeletingCode = false
    Map existingEntry = codePosition != null ? (getLockCodes()["${codePosition}"] ?: [:]) : [:]
    String descriptionText = "${device.displayName} deleteCode: no confirmation event received from lock (position ${codePosition}) — assuming deleted"
    if (codePosition != null) {
        removeLockCode(codePosition)
        removeCredentialMeta("${codePosition}")
    }
    Map codeData = codePosition != null ? ["${codePosition}": existingEntry] : [:]
    def eventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(codeData)) : codeData
    logLockCodeEventPayload('codeChanged', 'deleted', codeData)
    sendEvent(name: 'codeChanged', value: 'deleted', data: eventData, descriptionText: descriptionText, isStateChange: true)
    logWarn descriptionText
}


// ------- Hubitat command wrappers end -------

// ------- Matter command implementations -------

void identify() {
    List<String> serverList = getFingerprintData()?.get('ServerList') ?: []
    if (!serverList.contains('0003')) {
        logWarn "Identify command not supported: Cluster 0003 not present in ServerList"
        return
    }
    logInfo "identifying ..."
    parent?.componentIdentify(device)
}

// 5.2.10.1. LockDoor Command (0x00)
// This command causes the lock device to lock the door. This command includes an optional code for the lock. The door lock MAY require a PIN depending on the value of the RequirePINForRemoteOperation attribute.
void lock() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    //sendEvent(name: 'lock', value: 'locking', descriptionText: "${device.displayName} is locking...", type: 'digital')
    logInfo "locking..."
    parent?.componentLog(device, 'debug', 'locking...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x00, 2000)
    parent?.sendToDevice(cmd)
}

// 5.2.10.2. UnlockDoor Command (0x01)
// This command causes the lock device to unlock the door. This command includes an optional code for the lock. The door lock MAY require a code depending on the value of the RequirePINForRemoteOperation attribute.
void unlock() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    //sendEvent(name: 'lock', value: 'unlocking', descriptionText: "${device.displayName} is unlocking...", type: 'digital')
    logInfo "unlocking..."
    parent?.componentLog(device, 'debug', 'unlocking...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x01, 2000)
    parent?.sendToDevice(cmd)
}

// 5.2.10.3. UnlockWithTimeout Command (0x03)
// This command causes the lock device to unlock the door, then automatically relock after the given timeout.
void unlockWithTimeout(BigDecimal timeoutSeconds) {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    Integer timeout = timeoutSeconds?.intValue()
    if (timeout == null || timeout < 1 || timeout > 65535) {
        logWarn "unlockWithTimeout: timeout must be 1..65535 seconds, got '${timeoutSeconds}'"
        return
    }
    if (!isDoorLockCommandSupported('0003') && settings?.ignoreCompatibilityChecks != true) {
        logWarn 'unlockWithTimeout: This lock does not support UnlockWithTimeout (0x0003 not in AcceptedCommandList). Enable \'Ignore Compatibility Checks\' to force.'
        return
    }
    String timeoutHexLE = zigbee.swapOctets(HexUtils.integerToHexString(timeout, 2))
    String tlv = '15' + '25' + '00' + timeoutHexLE + '18'
    state.lastCmdIsTimeout = true
    logInfo "unlocking with timeout ${timeout} seconds..."
    parent?.componentLog(device, 'debug', "unlocking with timeout ${timeout}s...")
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x03, 2000, tlv)
    parent?.sendToDevice(cmd)
}

// 5.2.10.4. UnboltDoor Command (0x27)
// This command causes the lock device to retract the bolt (unlatch) without fully unlocking.
// Requires the UBOLT feature (FEATURE_UNBOLT bit in FeatureMap).
void unboltDoor() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    if (!isFeatureEnabled(FEATURE_UNBOLT) && settings?.ignoreCompatibilityChecks != true) {
        logWarn 'unboltDoor: This lock does not support the Unbolt feature (FEATURE_UNBOLT / bit 12 not set in FeatureMap). Enable \'Ignore Compatibility Checks\' to force.'
        return
    }
    logInfo 'unbolting...'
    parent?.componentLog(device, 'debug', 'unbolting...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x27, 2000)
    parent?.sendToDevice(cmd)
}


// 5.2.10.42 SetCredential Command (0x22)
// Implemented for PIN only (credentialType = 1)
//
// Usage examples:
//   matterSetCredentialPIN(1, "1234")           // set PIN in credential slot 1 (userIndex null)
//   matterSetCredentialPIN(1, "1234", 1)        // set PIN in credential slot 1 and associate to userIndex 1
//
// Notes:
// - credentialIndex is usually 1..NumberOfPINUsersSupported (often 1..10 for U200)
// - userIndex is often the same as credentialIndex for many locks (but not always)
// - operationType = 0 (Add)
// 
// WORKING !! :) 
//
void matterSetCredentialPIN(BigDecimal credentialIndexPar, String pinCode, BigDecimal userIndexPar = null) {
    if (!supportsLockCodes()) {
        logWarn "matterSetCredentialPIN: This lock <b>does not</b> support PIN/User management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Lock does not support PIN/User management", isStateChange: true)
        return
    }

    if (credentialIndexPar == null) {
        logWarn "matterSetCredentialPIN: credential index is required"
        return
    }
    Integer credentialIndex = credentialIndexPar.intValue()
    if (credentialIndex < 1 || credentialIndex > 255) {
        logWarn "matterSetCredentialPIN: credential index must be 1..255, got '${credentialIndex}'"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Invalid credential index ${credentialIndex}", isStateChange: true)
        return
    }

    if (!pinCode) {
        logWarn "matterSetCredentialPIN: pinCode is required"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Missing pinCode", isStateChange: true)
        return
    }

    // Basic sanity (you can relax this if your lock supports other lengths)
    if (pinCode.size() < 4 || pinCode.size() > 8) {
        logWarn "matterSetCredentialPIN: pinCode length must be 4..8 digits, got ${pinCode.size()}"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Invalid PIN length", isStateChange: true)
        return
    }

    Integer userIndex = (userIndexPar != null) ? userIndexPar.intValue() : null
    if (userIndex != null && (userIndex < 1 || userIndex > 65534)) {
        logWarn "matterSetCredentialPIN: userIndex must be 1..65534 (or null), got '${userIndex}'"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Invalid userIndex ${userIndex}", isStateChange: true)
        return
    }

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) {
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "deviceNumber is null", isStateChange: true)
        return
    }

    // ---- Build TLV ----
    // operationType enum8 (tag 0): Add=0
    String opTypeHex = "00" // "00" for Add, "01" for Clear, "02" for Modify

    // credential struct (tag 1)
    //   tag0: credentialType enum8 = 1 (PIN)
    //   tag1: credentialIndex uint16 LE
    String credTypeHex = "01"
    String credIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(credentialIndex, 2))  // 1 -> 0100

    // credentialData octet string (tag 2): bytes of PIN ASCII/UTF-8
    byte[] pinBytes = pinCode.getBytes('UTF-8')
    int pinLen = pinBytes.length
    String pinHex = pinBytes.collect { String.format('%02X', it) }.join()

    // Encode credentialData as ByteString1/2 (octet string), context tag 2
    // Context(1-byte) control for ByteString1 is 0x30, for ByteString2 is 0x31 (matches your UTF8 0x2C/0x2D logic)

    // credentialData octet string (tag 2) encoded as OctetString2
    // 0x31 = context-specific octet string with 2-byte length
    String lenHexLE = zigbee.swapOctets(HexUtils.integerToHexString(pinLen, 2))
    String credentialDataTlv = "31" + "02" + lenHexLE + pinHex

    // userIndex nullable uint16 (tag 3)
    String userIndexTlv
    if (userIndex == null) {
        // NULL: control 0x34 (context + null), tag 3
        userIndexTlv = "34" + "03"
    } else {
        String userIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userIndex, 2))
        // uint16: control 0x25 (context + uint16), tag 3
        userIndexTlv = "25" + "03" + userIndexHexLE
    }

    // userStatus nullable enum8 (tag 4)
    // SmartThings sends OCCUPIED_ENABLED, not NULL
    String userStatusTlv = "24" + "04" + "01"

    // userType nullable enum8 (tag 5)
    // SmartThings sends UNRESTRICTED_USER, not NULL
    String userTypeTlv = "24" + "05" + "00"

    // Credential struct field (tag 1): control 0x35 (context + struct), tag 1
    // Follow the same working pattern as matterClearCredential(): NO extra inner "15" here.
    String credentialStructField =
            "35" + "01" +
                "24" + "00" + credTypeHex +
                "25" + "01" + credIndexHexLE +
            "18"

    // Full command struct
    String tlv =
            "15" +
                "24" + "00" + opTypeHex +   // tag0 operationType
                credentialStructField +      // tag1 credential struct
                credentialDataTlv +          // tag2 credentialData (octet string)
                userIndexTlv +               // tag3 userIndex (nullable)
                userStatusTlv +              // tag4 userStatus (nullable)
                userTypeTlv +                // tag5 userType (nullable)
            "18"

    // Use Hubitat invoke envelope (timed invoke)
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x0022, 2000, tlv)

    logDebug "matterSetCredentialPIN: credIndex=${credentialIndex}, userIndex=${userIndex}, pinLen=${pinLen}, credIndexHexLE=${credIndexHexLE}, tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "setting PIN credential slot ${credentialIndex}..." + (userIndex != null ? " (user ${userIndex})" : ""))
    parent?.sendToDevice(cmd)

    // The response will be in SetCredentialResponse 0x23, however it is not exposed by Hubitat as an event, so we won't receive it in parse() and can't correlate it with the request
    // However, the lock will send later [callbackType:Event, endpointInt:1, clusterInt:257, evtId:4, timestamp:1779534535384, timestampType:1, priority:1, eventSerial:18153577, data:[4:STRUCT:[6:UINT:8, 3:UINT:3, 0:UINT:6, 1:UINT:0, 4:UINT:3, 5:UINT:112233, 2:UINT:7]], value:[6:8, 3:3, 0:6, 1:0, 4:3, 5:112233, 2:7], cluster:0101, endpoint:01]
    // this will result in sendEvent(name: 'codeChanged', value: "${credentialIndex} set", descriptionText: "SetCredential sent for slot ${credentialIndex}", isStateChange: true)
} // matterSetCredentialPIN



// 5.2.10.44. ClearCredential Command (0x26)
// Clears a single credential, all credentials of one type, or all credentials of all types.
// Usage:
//   matterClearCredential()                  // Clear all credentials of all types
//   matterClearCredential(type)              // Clear all credentials of one type (type: CredentialTypeEnum)
//   matterClearCredential(type, index)       // Clear a single credential (type: CredentialTypeEnum, index: credential index)
//
// CredentialTypeEnum: 1=PIN, 2=RFID, 3=Fingerprint, 4=Face, etc. (ProgrammingPIN not allowed)
// For all credentials of a type: index = 0xFFFE
// For all credentials of all types: type = null, index = null
// For a single credential: type = credential type, index = credential index
//
// cmdFields: ID:0, Name:Credential, Type:CredentialStruct, Quality:desc, Conformance:Mandatory
//
// **** seems to work! :)
//
void matterClearCredential(BigDecimal credentialTypePar = null, BigDecimal credentialIndexPar = null) {
    logDebug "matterClearCredential: type=${credentialTypePar}, index=${credentialIndexPar}"
    Integer credentialType = credentialTypePar != null ? credentialTypePar.intValue() : null
    Integer credentialIndex = credentialIndexPar != null ? credentialIndexPar.intValue() : null
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return

    if (credentialType == null && credentialIndex == null) {
        // Clear all credentials of all types (Credential field SHALL be null)
        logInfo 'matterClearCredential: clearing all credentials of all types'
        String cmd = matter.invoke(deviceNumber, 0x0101, 0x26)
        parent?.sendToDevice(cmd)
        return
    }

    if (credentialType == 0) {
        logWarn 'matterClearCredential: ProgrammingPIN cannot be cleared.'
        return
    }

    int index = (credentialIndex != null) ? credentialIndex : 1

    String typeHex  = HexUtils.integerToHexString(credentialType, 1)             // e.g. "01"
    String indexHex = zigbee.swapOctets(HexUtils.integerToHexString(index, 2))  // e.g. "0900"

    // Build TLV dynamically
    String tlv =
            "15" +            // start outer struct
            "35" + "00" +     // context tag 0, STRUCTURE (CredentialStruct)
            "24" + "00" + typeHex +     // tag 0: uint8 credentialType
            "25" + "01" + indexHex +    // tag 1: uint16 credentialIndex (LE)
            "18" +            // end inner struct
            "18"              // end outer struct


    String cmd = matter.invoke(0x01, 0x0101, 0x0026, 2000, tlv)

    logDebug "matterClearCredential: type=${credentialType}, index=${index}, tlv=${tlv}, cmd=${cmd}"
    parent?.sendToDevice(cmd)
}






/*

// NOT WORKING! :( )
// 5.2.10.34. SetUser Command (0x1A)
void matterSetUser(codePosition, pinCode, name = null) {
    if (!supportsLockCodes()) {
        logWarn "setCode: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Lock <b>does not</b> support PIN codes", isStateChange: true)
        return
    }
    
    if (!codePosition) {
        logWarn 'matterSetUser: user index is required'
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: 'matterSetUser: missing user index', isStateChange: true)
        return
    }

    Integer userIndex
    try {
        userIndex = (codePosition as BigDecimal)?.intValue()
    } catch (Exception ignored) {
        userIndex = null
    }
    if (userIndex == null || userIndex < 1 || userIndex > 255) {
        logWarn "matterSetUser: user index must be 1-255, got '${codePosition}'"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "matterSetUser: invalid user index '${codePosition}'", isStateChange: true)
        return
    }

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) {
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: 'matterSetUser: deviceNumber is null', isStateChange: true)
        return
    }

    
    // ---- Build TLV payload ----
    // 0: userIndex (uint16)
    // 1: userName (string, nullable on some implementations)
    // 2: userUniqueID (nullable uint32) -> we send NULL
    // 3: userStatus (enum8)
    // 4: userType (enum8)
    // 5: credentialRule (enum8)

    String userIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userIndex, 2))

    int userStatus = 0x01      // OccupiedEnabled (common)
    int userType = 0x00        // UnrestrictedUser (common)
    int credentialRule = 0x00  // Single (common)

    String userStatusHex = HexUtils.integerToHexString(userStatus, 1)
    String userTypeHex = HexUtils.integerToHexString(userType, 1)
    String credentialRuleHex = HexUtils.integerToHexString(credentialRule, 1)

    // userName:
    // If no name provided -> send NULL (more compatible than empty string on some locks)
    String userNameTlv
    if (name == null || name.toString().trim().isEmpty()) {
        userNameTlv = "2C" + "01" + "00"   // empty UTF-8 string, not NULL
    } else {
        String userName = name.toString()
        byte[] userNameBytes = userName.getBytes('UTF-8')
        int userNameLen = userNameBytes.length
        String userNameHex = userNameBytes.collect { String.format('%02X', it) }.join()

        if (userNameLen <= 0xFF) {
            // UTF81: control 0x2C, tag 1, 1-byte length
            userNameTlv = "2C" + "01" + HexUtils.integerToHexString(userNameLen, 1) + userNameHex
        } else {
            // UTF82: control 0x2D, tag 1, 2-byte length (LE)
            String lenHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userNameLen, 2))
            userNameTlv = "2D" + "01" + lenHexLE + userNameHex
        }
    }
    userNameTlv = "2C0100"          // !!!!!!!!!!!!!!!!!!! for testing !!!!!!!!!!
    // userUniqueID: NULL (tag 2)
    // String userUniqueIdTlv = "34" + "02"
// userUniqueID: uint32 (tag 2) -> use userIndex as value
String userUniqueIdHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userIndex, 4))
// control 0x26 = context-specific + uint32
String userUniqueIdTlv = "26" + "02" + userUniqueIdHexLE    
    userUniqueIdTlv = "26" + "02" + "00000000"      /// !!!!!!!!!!!!!!!! for testing !!!!!!!!!!

    // Build command struct
    String tlv =
            "15" +
              "25" + "00" + userIndexHexLE +   // tag 0 uint16
              userNameTlv +                    // tag 1 string or NULL
              userUniqueIdTlv +                // tag 2 NULL
              "24" + "03" + userStatusHex +    // tag 3 enum8
              "24" + "04" + userTypeHex +      // tag 4 enum8
              "24" + "05" + credentialRuleHex +// tag 5 enum8
            "18"

    // IMPORTANT: use matter.invoke() to build the Hubitat envelope correctly
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001A, 2000, tlv)

    logDebug "matterSetUser: index=${userIndex}, tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "setting user ${userIndex}..." + (name ? " (${name})" : ""))
    parent?.sendToDevice(cmd)

    // event should be sent later when confired
    // sendEvent(name: 'codeChanged', value: "changed", descriptionText: "matterSetUser sent for user ${userIndex}", isStateChange: true)

} // SetUser Command (0x1A)

*/

/*

// TODO
// 5.2.10.35. GetUser Command (0x1B)
// Retrieve user.
void matterGetUser(String userIndex) {
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "matterGetUser: This lock <b>does not</b> support User management (FeatureMap indicates no User support)"
        return
    }
    
    if (!userIndex) { logWarn "matterGetUser: User index is required" ; return }

    Integer index = userIndex as Integer
    // TODO: use device data "Number Of Total Users Supported" to validate index ! ( U200 supports up to 10 users )
    if (index < 1 || index > 10) {
        logWarn "matterGetUser: User index must be 1-10, got '${userIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    

    // cmdFields: ID:0, Name:UserIndex, Type:uint16, Constraint: 1 to NumberOfTotalUsersSupported, Conformance:Mandatory
    // An InvokeResponse command SHALL be sent with an appropriate error (e.g. FAILURE, INVALID COMMAND, etc.) as needed otherwise the GetUserResponse Command SHALL be sent implying a status of SUCCESS
    // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    List<Map<String, String>> cmdFields = []
    cmdFields.add(matter.cmdField(DataType.UINT16, 0x00, zigbee.swapOctets(HexUtils.integerToHexString(index, 2))))

    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001B, 2000, cmdFields)
    logDebug "matterGetUser: cmd=${cmd}"
    parent?.componentLog(device, 'debug', "querying user information for index ${index}...")
    parent?.sendToDevice(cmd)
}

*/


/*
// 5.2.10.37. ClearUser Command (0x1D) - WORKING ! :) 
// Clears a user or all Users. 
// // cmdFields: ID:0, Name:UserIndex, Type:uint16, Constraint: 1 to NumberOfTotalUsersSupported, Default:0xFFFE, Conformance:Mandatory
void matterClearUser(String userIndex) {
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "matterClearUser: This lock <b>does not</b> support User management (FeatureMap indicates no User support)"
        return
    }
    
    if (!userIndex) {
        logWarn "matterClearUser: User index is required"
        return
    }
    // TODO: use device data "Number Of Total Users Supported" to validate index ! ( U200 supports up to 10 users )
    Integer index = userIndex as Integer
    if (index < 1 || index > 10) {
        logWarn "matterClearUser: User index must be 1-10, got '${userIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', "clearing user at index ${index}...")
    logDebug "matterClearUser: clearing user at index ${index}"
    List<Map<String, String>> cmdFields = []
    cmdFields.add(matter.cmdField(DataType.UINT16, 0x00, zigbee.swapOctets(HexUtils.integerToHexString(index, 2))))
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001D, 2000, cmdFields)

    parent?.sendToDevice(cmd)
    // matterClearUser is working, for existing users it returns a response in an event : 
    //       descMap = [callbackType:Event, endpointInt:1, clusterInt:257, evtId:4, timestamp:946765068557, priority:1, data:[4:STRUCT:[6:UINT:8, 3:UINT:8, 0:UINT:2, 1:UINT:1, 4:UINT:3, 5:UINT:112233, 2:UINT:7]], value:[6:8, 3:8, 0:2, 1:1, 4:3, 5:112233, 2:7], cluster:0101, endpoint:01]
    // :) 
}
*/




/*

// Command to query PIN credential status
void matterGetCredentialStatus(String pinIndex) {
    if (!supportsLockCodes()) {
        logWarn "matterGetCredentialStatus: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }
    
    if (!pinIndex) {
        logWarn "matterGetCredentialStatus: PIN index is required"
        return
    }
    Integer index = pinIndex as Integer
    if (index < 1 || index > 255) {
        logWarn "matterGetCredentialStatus: PIN index must be 1-255, got '${pinIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', "querying PIN credential status for index ${index}...")

    // Build TLV using the SAME pattern as matterClearCredential() (known-good)
    // Outer struct:
    //   tag 0: CredentialStruct (struct)
    //        tag 0: credentialType (uint8/enum8)
    //        tag 1: credentialIndex (uint16 LE)

    int credentialType = 1  // PIN

    String typeHex    = HexUtils.integerToHexString(credentialType, 1)                 // 01
    String indexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(index, 2))       // 3 -> 0300

    // IMPORTANT: follow the SAME encoding pattern as matterClearCredential()
    // outer struct:
    //   tag0: CredentialStruct (struct)
    //      tag0: type (uint8/enum8)
    //      tag1: index (uint16 LE)
    String tlv =
            "15" +
              "35" + "00" +
                "24" + "00" + typeHex +
                "25" + "01" + indexHexLE +
              "18" +
            "18"

    String cmd = matter.invoke(deviceNumber, 0x0101, 0x0024, 2000, tlv)

    logDebug "matterGetCredentialStatus: type=${credentialType}, index=${index}, tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "querying credential status: type=${credentialType}, index=${index}...")
    parent?.sendToDevice(cmd)

}

*/


// Helper function to check if setCodeLength is supported by this lock
Boolean isSetCodeLengthEnabled() {
    // TODO: Check FeatureMap or device capabilities to determine support
    return false
}

/**
 * Check if a specific Matter Door Lock feature is enabled on this lock
 * @param featureBit The feature bit to check (use FEATURE_* constants)
 * @return true if the feature is enabled, false otherwise
 */
Boolean isFeatureEnabled(Integer featureBit) {
    // Bypass feature checks if ignoreCompatibilityChecks is enabled
    if (settings?.ignoreCompatibilityChecks == true) {
        //logDebug "isFeatureEnabled: ignoreCompatibilityChecks enabled - bypassing feature check for 0x${Integer.toHexString(featureBit).toUpperCase()}"
        return true
    }
    
    // Get FeatureMap from fingerprintData
    Map fingerprint = getFingerprintData()
    def featureMapRaw = fingerprint?.get('0101_FFFC')

    if (featureMapRaw == null) {
        logWarn "isFeatureEnabled: FeatureMap not available in fingerprintData - features unknown"
        return false
    }

    // Parse FeatureMap value - stored as uppercase hex string (e.g. "0D93") by newParseCompatibilityPatch.
    // safeHexToInt handles both hex strings and raw integers defensively.
    Integer featureMap = safeHexToInt(featureMapRaw)
    
    // Check if the specific feature bit is set
    boolean enabled = (featureMap & featureBit) != 0
    
    //logDebug "isFeatureEnabled: FeatureMap=0x${Integer.toHexString(featureMap).toUpperCase()}, checking bit 0x${Integer.toHexString(featureBit).toUpperCase()}: ${enabled}"
    
    return enabled
}

/**
 * Check if this lock supports PIN credential management (LockCodes capability)
 * @return true if PIN credentials and user management are supported
 */
Boolean supportsLockCodes() {
    // Bypass feature checks if ignoreCompatibilityChecks is enabled
    if (settings?.ignoreCompatibilityChecks == true) {
        //logDebug "supportsLockCodes: ignoreCompatibilityChecks enabled - bypassing PIN/User feature checks"
        return true
    }
    
    return isFeatureEnabled(FEATURE_PIN_CREDENTIAL) && isFeatureEnabled(FEATURE_USER_MANAGEMENT)
}

/**
 * Helper method for dynamic command parameter display
 * Returns a string indicating whether this device supports PIN code management
 * Used in command metadata to show feature support status to users
 */
String isCodeAllowed() {
    if (false/*supportsLockCodes()*/) {
        return "Your device ${device?.displayName} SUPPORTS PIN code management"
    } else {
        Map fingerprint = getFingerprintData()
        String featureMapHex = fingerprint?.get('0101_FFFC') ?: '??'
        return "Your device ${device?.displayName} <b>does NOT</b> support PIN code management (FeatureMap=0x${featureMapHex})"
    }
}

// ========== LockCodes Capability Methods ==========
// Note: These methods are part of the LockCodes capability which is always declared
// However, not all Matter locks support PIN management. Each method checks feature support.





// ========== End LockCodes Capability Methods ==========


// Read FeatureMap attribute to see which features are supported
// TODO - move to the main driver
void readFeatureMap() {
    parent?.componentLog(device, 'debug', 'reading FeatureMap attribute...')
    String endpoint = device.getDataValue('id') ?: '1'
    String cluster = '257'  // 0x0101 Door Lock cluster
    String attribute = '65532'  // 0xFFFC FeatureMap
    parent?.readAttribute([endpoint, cluster, attribute])
}


// Helper method to generate info string with feature support status
String generateInfoString() {
    Map fingerprint = getFingerprintData()
    String featureMapHex = fingerprint?.get('0101_FFFC') ?: '??'
    // Check actual hardware FeatureMap bits directly — not subject to ignoreCompatibilityChecks bypass,
    // since this method reports what the hardware actually supports, not what is overridden.
    Integer featureMap   = safeHexToInt(featureMapHex)
    Boolean pinEnabled   = (featureMap & FEATURE_PIN_CREDENTIAL)  != 0
    Boolean userEnabled  = (featureMap & FEATURE_USER_MANAGEMENT) != 0
    Boolean isEnabled    = pinEnabled && userEnabled
    //log.trace "generateInfoString: FeatureMap=0x${featureMapHex}, PIN_CREDENTIAL=${pinEnabled}, USER_MANAGEMENT=${userEnabled}, isEnabled=${isEnabled}"
    String featureInfo = isEnabled ?
        "Your lock ${device.displayName} supports PIN codes/users management (FeatureMap=0x${featureMapHex})" :
        "Your lock ${device.displayName} <b>does NOT</b> support PIN codes/users management (FeatureMap=0x${featureMapHex})"
    return "${featureInfo}"
}

// Called when the device is first created
void installed() {
    log.info "${device.displayName} driver installed"
    // Seed attributes with safe defaults so dashboards and automations
    // never see null before the first Matter report arrives.
    sendEvent(name: 'lock',              value: 'unknown',      descriptionText: "${device.displayName} lock initialized to unknown")
    sendEvent(name: 'lockCodes',         value: '{}',           descriptionText: "${device.displayName} lockCodes initialized")
    sendEvent(name: 'codeLength',        value: 4,              descriptionText: "${device.displayName} codeLength defaulted to 4 (pending discovery)")
    sendEvent(name: 'maxCodes',          value: 10,             descriptionText: "${device.displayName} maxCodes defaulted to 10 (pending discovery)")
    runIn(2,  'updated')   // delay to allow settings to be saved
    runIn(30, 'getInfo')   // read all Door Lock attributes once discovery has populated fingerprintData
}

// Called when the device is removed
void uninstalled() {
    log.info "${device.displayName} driver uninstalled"
}

// Called when the settings are updated
void updated() {
    log.info "${device.displayName} driver configuration updated"
    clearOldStateVariables()
    state.info = generateInfoString()
    log.info "${device.displayName} ${state.info}"
    if (logEnable) {
        logDebug settings as String
        runIn(86400, 'logsOff')
    }
    updateEncryption()
}

// Clean up old/deprecated state variables
void clearOldStateVariables() {
    List<String> oldStateVars = ['warning', 'working', 'Warning', 'Working', 'comment', 'lastSetCode']
    oldStateVars.each { String varName ->
        if (state.containsKey(varName)) {
            logDebug "clearOldStateVariables: removing '${varName}'"
            state.remove(varName)
        }
    }
}

private void logsOff() {
    log.warn "debug logging disabled for ${device.displayName} "
    device.updateSetting('logEnable', [value: 'false', type: 'bool'] )
}

void refresh() {
    logInfo "refreshing device state and attributes..."
    clearOldStateVariables()
    parent?.componentRefresh(this.device)
}



/**
 * Get the Door Lock cluster AttributeList (0x0101_FFFB)
 * @return List of attribute IDs as 4-digit hex strings (e.g., ["0000", "0001", "0002", ...])
 */
List<String> getDoorLockAttributeList() {
    Map fingerprint = getFingerprintData()
    if (fingerprint == null) {
        logDebug "getDoorLockAttributeList: fingerprint data not available"
        return []
    }
    
    return fingerprint['0101_FFFB'] ?: []
}

/**
 * Check if a specific attribute is supported by the Door Lock cluster
 * @param attrHex Attribute ID as 4-digit hex string (e.g., "0000" for LockState)
 * @return true if attribute is in Door Lock AttributeList
 */
boolean isDoorLockAttributeSupported(String attrHex) {
    List<String> attrList = getDoorLockAttributeList()
    return attrList.contains(attrHex?.toUpperCase())
}

/**
 * Get AcceptedCommandList for Door Lock cluster from fingerprint data
 * @return List of command IDs as 4-digit hex strings (e.g., ['0000', '0001', '0003', ...])
 */
List<String> getDoorLockAcceptedCommandList() {
    Map fingerprint = getFingerprintData()
    if (!fingerprint) {
        logDebug "getDoorLockAcceptedCommandList: fingerprint data not available"
        return []
    }
    return fingerprint.get('0101_FFF9') ?: []
}

/**
 * Check if a specific Door Lock command is supported
 * @param commandHex The command ID as 4-digit hex string (e.g., '0000', '0001', etc.)
 * @return true if command is in the AcceptedCommandList
 */
Boolean isDoorLockCommandSupported(String commandHex) {
    List<String> cmdList = getDoorLockAcceptedCommandList()
    return cmdList.contains(commandHex?.toUpperCase())
}


// Helper function to process event mask attributes (reduces code duplication)
// Returns the message to be logged (caller handles logging)
String processEventMaskAttribute(String attrId, String attrName, Map descMap, Closure decoder) {
    String rawValue = (descMap.value instanceof List) ? 
        (descMap.value.size() > 0 ? descMap.value[0]?.toString() : '00') : 
        descMap.value?.toString()
    String maskValue = rawValue?.take(4) ?: '00'
    Integer mask = safeParseHex(maskValue)
    String decoded = decoder(mask)
    
    if (rawValue?.length() > 4) { 
        logWarn "${attrName}: value truncated from 0x${rawValue}" 
    }
    
    // Build and return message (prefix will be added by caller)
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${attrId}] " : ""
    return "${prefix}${attrName}: 0x${maskValue} - Enabled: ${decoded}"
}

// Helper function to process numeric attributes in handleLockMessage method
// Returns the message to be logged (caller handles logging)
String processNumericAttribute(String attrName, Map descMap) {
    Integer value = safeHexToInt(descMap.value)
    
    // Build and return message (prefix will be added by caller)
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${descMap.attrId}] " : ""
    return "${prefix}${attrName}: ${value}"
}



void processGetCredentialStatusResponse(Map descMap) {
    logDebug "processGetCredentialStatusResponse: descMap=${descMap}"
    
    // Response fields: credentialExists, userIndex, creatorFabricIndex, lastModifiedFabricIndex, nextCredentialIndex
    // For now, just log the raw response to see the format
    logInfo "GetCredentialStatus Response: ${descMap}"
    
    // TODO: Parse TLV response structure once we see the actual format
    // Expected structure: {credentialExists: bool, userIndex: uint16, ...}
}

void processGetUserResponse(Map descMap) {
    logDebug "processGetUserResponse: descMap=${descMap}"
    
    // Response fields: userIndex, userName, userUniqueID, userStatus, userType, credentialRule, credentials, creatorFabricIndex, lastModifiedFabricIndex
    // For now, just log the raw response to see the format
    logInfo "GetUser Response: ${descMap}"
    
    // TODO: Parse TLV response structure once we see the actual format
    // Expected structure: {userIndex: uint16, userName: string, userStatus: enum8, userType: enum8, ...}
}

// 5.2.11. Events 
void processDoorLockEvent(Map eventMap) {
    def evtId = safeToInt(eventMap.evtId)
    logDebug "processDoorLockEvent: evtId=${evtId}"
    
    switch (evtId) {
        case 0x00: // DoorLockAlarm (0x00)
            processDoorLockAlarmEvent(eventMap)
            break
        case 0x01: // DoorStateChange (0x01)
            processDoorStateChangeEvent(eventMap)
            break
        case 0x02: // LockOperation (0x02)
            processLockOperationEvent(eventMap)
            break
        case 0x03: // LockOperationError (0x03)
            processLockOperationErrorEvent(eventMap)
            break
        case 0x04: // LockUserChange (0x04)
            processLockUserChangeEvent(eventMap)
            break
        default:
            logWarn "processDoorLockEvent: unknown evtId=${evtId}"
    }
}

void processDoorLockAlarmEvent(Map eventMap) {
    // Event fields: alarmCode
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    Integer alarmCode = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null

    String alarmText = DoorLockClusterAlarmCode[alarmCode] ?: "Unknown (${alarmCode})"
    String descriptionText = "${device.displayName} ALARM: ${alarmText}"

    logWarn "${descriptionText}"
    sendEvent(name: 'lockAlarm', value: alarmText, descriptionText: descriptionText, isStateChange: true)
}

void processDoorStateChangeEvent(Map eventMap) {
    // Event fields: doorState
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    Integer doorState = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null

    String doorStateText = DoorLockClusterDoorState[doorState] ?: "Unknown (${doorState})"
    String descriptionText = "${device.displayName} door is ${doorStateText}"

    logInfo "${descriptionText}"
    sendEvent(name: 'doorState', value: doorStateText, descriptionText: descriptionText)
}

// 5.2.11.3. LockOperation Event #2
// The door lock server sends out a LockUserChange event when a lock user, schedule, or credential change has occurred.
void processLockOperationEvent(Map eventMap) {
    // Event fields: lockOperationType, operationSource, userIndex, fabricIndex, sourceNode, credentials
    // eventMap = [callbackType:Event, endpointInt:1, clusterInt:257, evtId:2, timestamp:37455661, priority:2, 
    //           data:[2:STRUCT:[
    //              3:NULL:null,        // FabricIndex
    //              0:UINT:1,           // LockOperationType 
    //              1:UINT:7,           // OperationSource
    //              2:NULL:null,        // UserIndex
    //              5:NULL:null,        // Credentials
    //              4:NULL:null]],      // SourceNode
    //           value:[3:null, 0:1, 1:7, 2:null, 5:null, 4:null], 
    //           cluster:0101, endpoint:01]
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    logDebug "processLockOperationEvent: parsed values=${values}"

    Integer lockOpType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer opSource = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer userIndex = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    logDebug "processLockOperationEvent: lockOpType=${lockOpType}, opSource=${opSource}, userIndex=${userIndex}"

    String operation = DoorLockClusterLockOperationType[lockOpType] ?: "Unknown (${lockOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"

    String descriptionText = "${operation} by ${source}" + (userIndex != null ? " (User ${userIndex})" : "")

    // Optimized lock state mapping — handle 'unlocked with timeout' when triggered by unlockWithTimeout()
    String lockState
    if (lockOpType == 0) {
        lockState = 'locked'
        state.lastCmdIsTimeout = false
    } else if (lockOpType == 1 && state.lastCmdIsTimeout == true) {
        lockState = 'unlocked with timeout'
    } else if (lockOpType == 1) {
        lockState = 'unlocked'
    } else if (lockOpType == 4) {
        lockState = 'unlocked'   // Unlatch (unboltDoor); Hubitat Lock has no 'unlatched' state
    } else {
        lockState = 'unknown'
    }
    String lockDesc = "${device.displayName} is ${lockState} (${descriptionText})"

    // When userIndex is present (keypad/code unlock), resolve credential slot for LCM data matching.
    if (userIndex != null) {
        String credentialKey = resolveCredentialKeyFromUserIndex(userIndex) ?: "${userIndex}"
        Map codeEntry = getLockCodes()[credentialKey] ?: [name: "code #${credentialKey}"]
        lockDesc = "${device.displayName} is ${lockState} by ${source.toLowerCase()} (${codeEntry.name})"
        Map codeData = [(credentialKey): codeEntry]
        def lockEventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(codeData)) : codeData
        logLockCodeEventPayload('lock', lockState, codeData)
        sendEvent(name: 'lock', value: lockState, data: lockEventData, descriptionText: lockDesc, isStateChange: true)
        if (codeEntry.name != "code #${credentialKey}") {  // only send lastCodeName if we found the actual code
            sendEvent(name: 'lastCodeName', value: codeEntry.name, descriptionText: "${device.displayName} operated by ${codeEntry.name}", isStateChange: true)
        }
        upsertCredentialMeta(credentialKey, [
            userIndex: userIndex,
            credentialIndex: safeToInt(credentialKey),
            operationSource: opSource,
            operationSourceName: source
        ])
        logDebug "processLockOperationEvent: userIndex=${userIndex} -> credential=${credentialKey}, codeName='${codeEntry.name}'"
    } else {
        sendEvent(name: 'lock', value: lockState, descriptionText: lockDesc, isStateChange: true)
    }

    logInfo lockDesc
    sendEvent(name: 'lastLockOperation', value: operation, descriptionText: descriptionText, isStateChange: true)
    sendEvent(name: 'lastOperationSource', value: source, descriptionText: descriptionText, isStateChange: true)
}

// LockOperationError (0x03)
void processLockOperationErrorEvent(Map eventMap) {
    // Event fields: lockOperationType, operationSource, operationError, userIndex, fabricIndex, sourceNode, credentials
    logDebug "processLockOperationErrorEvent: description=${eventMap}"
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    logDebug "processLockOperationErrorEvent: parsed values=${values}"

    Integer lockOpType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer opSource = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer opError = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    Integer userIndex = values[3] != null && values[3] != 'null' ? safeToInt(values[3]) : null

    String operation = DoorLockClusterLockOperationType[lockOpType] ?: "Unknown (${lockOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"
    String error = DoorLockClusterOperationError[opError] ?: "Unknown (${opError})"

    String descriptionText = "${device.displayName} ${operation} FAILED: ${error} (source: ${source}"
    if (userIndex != null) {
        descriptionText += ", User ${userIndex}"
    }
    descriptionText += ")"

    logWarn "*** ${descriptionText} ***"
    sendEvent(name: 'lastLockOperationError', value: error, descriptionText: descriptionText, isStateChange: true)
}

// LockUserChange (0x04) event
// Observed U200 behavior:
//   setCode(pos)   → TWO events: PIN Add (DataIndex=codePosition) then UserIndex Add (DataIndex=userSlot)
//   deleteCode(pos)→ ONE event:  UserIndex Clear (DataIndex=userSlot; codePosition NOT in event)
//
// codeChanged deduplication strategy:
//   - isSettingCode==true   : setCode() already sent codeChanged optimistically → confirm only, no re-fire
//   - isDeletingCode==true  : deleteCode waiting for confirmation → fire 'deleted' + sync lockCodes
//   - isPinEvent (type==PIN): external credential change → fire codeChanged
//   - UserIndex Add/Modify  : follow-up from our setCode or unhandled → suppress codeChanged
//   - UserIndex Clear (external): external delete → fire 'deleted', warn lockCodes may be out of sync
void processLockUserChangeEvent(Map description) {
    Map values = description.value instanceof Map ? description.value : [:]

    Integer lockDataType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer dataOpType   = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer opSource     = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    Integer userIndex    = values[3] != null && values[3] != 'null' ? safeToInt(values[3]) : null
    Integer fabricIndex  = values[4] != null && values[4] != 'null' ? safeToInt(values[4]) : null
    Integer sourceNode   = values[5] != null && values[5] != 'null' ? safeToInt(values[5]) : null
    Integer dataIndex    = values[6] != null && values[6] != 'null' ? safeToInt(values[6]) : null

    String dataType  = DoorLockClusterLockDataType[lockDataType] ?: "Unknown (${lockDataType})"
    String operation = DoorLockClusterDataOperationType[dataOpType] ?: "Unknown (${dataOpType})"
    String source    = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"

    logDebug "processLockUserChangeEvent: type=${dataType}(${lockDataType}), op=${operation}, user=${userIndex}, dataIdx=${dataIndex}, source=${source}"

    // Recover Hubitat credential slot where possible.
    boolean isPinEvent = (lockDataType == 0x06)
    String credentialKey = null
    if (isPinEvent && dataIndex != null) {
        credentialKey = "${dataIndex}"   // PIN events carry credential index in DataIndex
    } else if (state.isDeletingCode && state.lastDeleteCode?.codePosition != null) {
        credentialKey = "${state.lastDeleteCode.codePosition}" // command correlation for deleteCode()
    } else if (dataOpType == 1 && userIndex != null) {
        // External UserIndex Clear: try resolving slot from metadata learned from prior events.
        credentialKey = resolveCredentialKeyFromUserIndex(userIndex)
    }
    ensureLockCodeStateMaps()
    if (credentialKey == null && state.isSettingCode == true && state.pendingSetByCredential?.size() == 1) {
        // Fallback when lock omits expected slot fields for set confirmation.
        credentialKey = state.pendingSetByCredential.keySet().first()
    }
    Integer codePosition = credentialKey != null ? safeToInt(credentialKey) : null

    if (credentialKey != null) {
        upsertCredentialMeta(credentialKey, [
            userIndex: userIndex,
            credentialIndex: codePosition,
            lastDataIndex: dataIndex,
            lastDataType: lockDataType,
            lastDataOperationType: dataOpType,
            lastSource: opSource,
            lastSourceName: source,
            fabricIndex: fabricIndex,
            sourceNode: sourceNode
        ])
    }

    String posText = codePosition != null ? " [pos=${codePosition}]" : ""
    String descriptionText = "${device.displayName}${posText} ${dataType} ${operation}"
    if (userIndex    != null) { descriptionText += " for User ${userIndex}" }
    if (dataIndex    != null) { descriptionText += ", (Data Index ${dataIndex})" }
    if (fabricIndex  != null) { descriptionText += ", (Fabric ${fabricIndex})" }
    if (sourceNode   != null) { descriptionText += ", (Node ${sourceNode})" }
    descriptionText += " (source: ${source})"

    logInfo "${descriptionText}"
    sendEvent(name: 'lastUserChange', value: "${operation} ${dataType}", descriptionText: descriptionText, isStateChange: true)

    // --- codeChanged and lockCodes sync ---
    if (state.isSettingCode == true) {
        // Lock confirmed setCode — update lockCodes and fire codeChanged now
        state.isSettingCode = false
        unschedule('clearSettingCodeFlagOnTimeout')
        Map entry = credentialKey != null ? (state.pendingSetByCredential?.get(credentialKey) ?: [:]) : [:]
        String storedPin  = entry?.pinCode ?: ''
        String storedName = entry?.name    ?: (credentialKey != null ? (getLockCodes()[credentialKey]?.name ?: "code #${credentialKey}") : '')
        Map lockcodes = getLockCodes()
        boolean newCode = credentialKey != null ? !lockcodes.containsKey(credentialKey) : false
        if (credentialKey != null) {
            lockcodes[credentialKey] = [code: storedPin, name: storedName]
        }
        updateLockCodes(lockcodes)
        String codeChangedVal = newCode ? 'added' : 'changed'
        Map codeData = credentialKey != null ? [(credentialKey): [code: storedPin, name: storedName]] : [:]
        def eventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(codeData)) : codeData
        logLockCodeEventPayload('codeChanged', codeChangedVal, codeData)
        sendEvent(name: 'codeChanged', value: codeChangedVal, data: eventData, descriptionText: descriptionText, isStateChange: true)
        if (credentialKey != null) { state.pendingSetByCredential?.remove(credentialKey) }
        logDebug "processLockUserChangeEvent: setCode confirmed - credential=${credentialKey}, ${codeChangedVal}, lockCodes updated"

    } else if (state.isDeletingCode == true && dataOpType == 1) {
        // deleteCode confirmation — fire codeChanged='deleted' and remove from lockCodes
        state.isDeletingCode = false
        unschedule('clearDeletingCodeFlagOnTimeout')
        Map existingEntry = credentialKey != null ? (getLockCodes()[credentialKey] ?: [:]) : [:]
        Map codeData = credentialKey != null ? [(credentialKey): existingEntry] : [:]
        def eventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(codeData)) : codeData
        logLockCodeEventPayload('codeChanged', 'deleted', codeData)
        sendEvent(name: 'codeChanged', value: 'deleted', data: eventData, descriptionText: descriptionText, isStateChange: true)
        if (codePosition != null) {
            removeLockCode(codePosition)
            removeCredentialMeta("${codePosition}")
        }

    } else if (isPinEvent) {
        // External PIN credential change (not from our commands)
        String hubitatOperation = HubitatCodeChangedType[dataOpType] ?: 'unknown'
        Map extPinData
        if (dataOpType == 1 && credentialKey != null) {
            extPinData = [(credentialKey): getLockCodes()[credentialKey] ?: [:]]
        } else {
            extPinData = credentialKey != null ? [(credentialKey): [name: "code #${credentialKey}"]] : [:]
        }
        def extPinEventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(extPinData)) : extPinData
        logLockCodeEventPayload('codeChanged', hubitatOperation, extPinData)
        sendEvent(name: 'codeChanged', value: hubitatOperation, data: extPinEventData, descriptionText: descriptionText, isStateChange: true)
        if (dataOpType == 1 && codePosition != null) {
            removeLockCode(codePosition)   // external PIN Clear — remove from lockCodes
            removeCredentialMeta("${codePosition}")
        } else {
            logWarn "processLockUserChangeEvent: external credential change (pos=${codePosition}) — lockCodes attribute not automatically synced"
        }

    } else if (dataOpType == 1) {
        // UserIndex Clear with no pending deleteCode — external delete; try metadata mapping.
        String posDesc = credentialKey != null ? "pos=${credentialKey}" : "userIndex=${userIndex}"
        if (credentialKey == null) {
            logWarn "processLockUserChangeEvent: external credential delete (${posDesc}) — lockCodes attribute not automatically synced"
        } else {
            logInfo "processLockUserChangeEvent: external credential delete resolved (${posDesc})"
        }
        Map extDelEntry = credentialKey != null ? (getLockCodes()[credentialKey] ?: [:]) : [:]
        Map extDelData = credentialKey != null ? [(credentialKey): extDelEntry] : [:]
        def extDelEventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(extDelData)) : extDelData
        logLockCodeEventPayload('codeChanged', 'deleted', extDelData)
        sendEvent(name: 'codeChanged', value: 'deleted', data: extDelEventData, descriptionText: descriptionText, isStateChange: true)
        if (credentialKey != null && codePosition != null) {
            removeLockCode(codePosition)
            removeCredentialMeta("${codePosition}")
        }

    } else {
        // UserIndex Add/Modify follow-up or other unhandled type — suppress codeChanged
        logDebug "processLockUserChangeEvent: suppressing codeChanged for non-PIN ${operation} event (type=${dataType})"
    }
}

// Remove a code entry from the lockCodes attribute by Hubitat codePosition
private void removeLockCode(Integer codePosition) {
    Map lockcodes = new HashMap(getLockCodes())   // copy into mutable HashMap to avoid LazyMap.remove() issues
    String key = "${codePosition}"
    if (lockcodes.containsKey(key)) {
        lockcodes.remove(key)
        updateLockCodes(lockcodes)
        logDebug "removeLockCode: removed codePosition=${codePosition} from lockCodes"
    } else {
        logDebug "removeLockCode: codePosition=${codePosition} not found in lockCodes (already removed or never added)"
    }
}

// ---- Lock code helpers (Hubitat Lock Code Manager compatibility) ----

private void ensureLockCodeStateMaps() {
    if (state.pendingSetByCredential == null) { state.pendingSetByCredential = [:] }
    if (state.codeMetaByCredential == null) { state.codeMetaByCredential = [:] }
    if (state.lastProcessedEventSerialById == null) { state.lastProcessedEventSerialById = [:] }
}

private void ensureStats() {
    if (state.stats == null) { state.stats = [:] }
    if (state.stats.totalEvents    == null) { state.stats.totalEvents    = 0 }
    if (state.stats.duplicateEvents == null) { state.stats.duplicateEvents = 0 }
    if (state.stats.outOfOrderEvents == null) { state.stats.outOfOrderEvents = 0 }
    if (state.stats.lastSerialByStream == null) { state.stats.lastSerialByStream = [:] }
}

void clearStatistics() {
    state.stats = [totalEvents: 0, duplicateEvents: 0, outOfOrderEvents: 0, lastSerialByStream: [:]]
    state.seenDoorLockEvents = [:]
    logInfo 'clearStatistics: event statistics and duplicate-event cache cleared'
}

private Boolean isDuplicateDoorLockEvent(Map descMap) {
    if (descMap?.callbackType != "Event") return false
    if ((descMap.clusterInt as Integer) != 0x0101) return false
    if (descMap.eventSerial == null) return false

    ensureStats()
    state.stats.totalEvents = (state.stats.totalEvents as Integer) + 1

    // Out-of-order detection: compare serial against highest seen for this stream
    String streamKey = "${descMap.endpointInt}:${descMap.clusterInt}:${descMap.evtId}"
    Long currentSerial = descMap.eventSerial as Long
    Long lastSerial = state.stats.lastSerialByStream[streamKey] != null ? (state.stats.lastSerialByStream[streamKey] as Long) : null
    if (lastSerial != null && currentSerial < lastSerial) {
        state.stats.outOfOrderEvents = (state.stats.outOfOrderEvents as Integer) + 1
        logDebug "isDuplicateDoorLockEvent: out-of-order event detected stream=${streamKey}, serial=${currentSerial} < lastSeen=${lastSerial}"
    }
    if (lastSerial == null || currentSerial > lastSerial) {
        state.stats.lastSerialByStream[streamKey] = currentSerial
    }

    String key = "${descMap.endpointInt}:${descMap.clusterInt}:${descMap.evtId}:${descMap.eventSerial}"
    Long nowMs = now()

    Map seen = state.seenDoorLockEvents ?: [:]

    // Keep only recent events
    seen = seen.findAll { k, v ->
        (nowMs - ((v ?: 0L) as Long)) < 10000L
    }

    if (seen.containsKey(key)) {
        state.stats.duplicateEvents = (state.stats.duplicateEvents as Integer) + 1
        logDebug "Duplicate DoorLock event suppressed: ${key}"
        state.seenDoorLockEvents = seen
        return true
    }

    seen[key] = nowMs
    state.seenDoorLockEvents = seen
    return false
}

private String resolveCredentialKeyFromUserIndex(Integer userIndex) {
    if (userIndex == null) return null
    ensureLockCodeStateMaps()
    String direct = "${userIndex}"
    if (getLockCodes().containsKey(direct)) {
        return direct
    }
    def found = state.codeMetaByCredential.find { String k, def v ->
        safeToInt(v?.userIndex) == userIndex
    }
    return found?.key
}

private void upsertCredentialMeta(String credentialKey, Map patch) {
    if (credentialKey == null) return
    ensureLockCodeStateMaps()
    Map cur = state.codeMetaByCredential[credentialKey] instanceof Map ? state.codeMetaByCredential[credentialKey] : [:]
    Map merged = [:] + cur + (patch ?: [:])
    merged.updatedAt = now()
    state.codeMetaByCredential[credentialKey] = merged
}

private void removeCredentialMeta(String credentialKey) {
    if (credentialKey == null) return
    ensureLockCodeStateMaps()
    state.codeMetaByCredential.remove(credentialKey)
}

private Map redactLockCodePayload(Map payload) {
    Map redacted = [:]
    (payload ?: [:]).each { String slot, def entry ->
        if (entry instanceof Map) {
            Map copy = [:] + (Map) entry
            if (copy.containsKey('code')) {
                String codeString = copy.code != null ? "${copy.code}" : ''
                copy.code = codeString ? ('*' * codeString.length()) : ''
                copy.codeLength = codeString.length()
            }
            redacted[slot] = copy
        } else {
            redacted[slot] = entry
        }
    }
    return redacted
}

private void logLockCodeEventPayload(String eventName, String eventValue, Map payload) {
    Map redacted = redactLockCodePayload(payload)
    String mode = settings?.optEncrypt ? 'encrypted' : 'plain'
    logDebug "sendEvent payload: name=${eventName}, value=${eventValue}, mode=${mode}, data=${redacted}"
}

// Read the lockCodes attribute and return as a Map; handles optional encryption transparently.
private Map getLockCodes() {
    String current = device.currentValue('lockCodes') ?: '{}'
    try {
        if (current[0] != '{') { current = decrypt(current) }  // encrypted strings don\'t start with '{'
        return parseJson(current) ?: [:]
    } catch (Exception e) {
        logWarn "getLockCodes: failed to parse lockCodes: ${e.message}"
        return [:]
    }
}

// Serialize lockCodes Map and send as the lockCodes attribute, encrypting if optEncrypt is set.
private void updateLockCodes(Map lockcodes) {
    String json = JsonOutput.toJson(lockcodes ?: [:])
    String value = settings?.optEncrypt ? encrypt(json) : json
    logLockCodeEventPayload('lockCodes', 'updated', lockcodes ?: [:])
    sendEvent(name: 'lockCodes', value: value, isStateChange: true)
}

// Re-encrypt or decrypt the stored lockCodes attribute when the optEncrypt preference changes.
private void updateEncryption() {
    String current = device.currentValue('lockCodes')
    if (!current) return
    if (settings?.optEncrypt && current[0] == '{') {        // currently plain — re-send encrypted
        sendEvent(name: 'lockCodes', value: encrypt(current), isStateChange: true)
    } else if (!settings?.optEncrypt && current[0] != '{') {  // currently encrypted — re-send plain
        sendEvent(name: 'lockCodes', value: decrypt(current), isStateChange: true)
    }
}

// Command to get all supported Door Lock attributes (for info/debugging)
void getInfo() {
    // Check if Door Lock cluster is supported
    if (!isClusterSupported('0101')) {
        logWarn "getInfo: Door Lock cluster (0x0101) is not supported by this device"
        logInfo "getInfo: ServerList contains: ${getServerList()}"
        return
    }
    logInfo "getInfo: reading all supported Door Lock attributes: ${getDoorLockAttributeList()}"
    
    // Set state flags for info mode
    if (state.states == null) { state.states = [:] }
    if (state.lastTx == null) { state.lastTx = [:] }
    state.states.isInfo = true
    state.lastTx.infoTime = now()
    
    // Schedule job to turn off info mode after 10 seconds
    runIn(10, 'clearInfoMode')
    
    String endpointHex = device.getDataValue('id') ?: '1'
    Integer endpoint = HexUtils.hexStringToInt(endpointHex)
    parent?.readAttribute(endpoint, 0x0101, -1)      // 0x00 Door Lock cluster - read all attributes
    // battery info is processed in parent driver !
    // parent?.readAttribute(endpoint, 0x002F, -1)       // 0x002F Power Source cluster - read all attributes
}

// Clear info mode flag (called by scheduled job)
void clearInfoMode() {
    if (state.states == null) { state.states = [:] }
    state.states.isInfo = false
    logDebug "clearInfoMode: info mode disabled"
}

// ============ Matter Door Lock Cluster Attributes Map ============
// Complete list of all Door Lock cluster (0x0101) attributes per Matter spec
@Field static final Map<Integer, String> DoorLockClusterAttributes = [
    // Mandatory and common attributes
    0x0000  : 'LockState',                                          // LockStateEnum, R V, M
    0x0001  : 'LockType',                                           // LockTypeEnum, R V, M
    0x0002  : 'ActuatorEnabled',                                    // bool, R V, M
    0x0003  : 'DoorState',                                          // DoorStateEnum, R V, DPS
    0x0004  : 'DoorOpenEvents',                                     // uint32, RW, DPS
    0x0005  : 'DoorClosedEvents',                                   // uint32, RW, DPS
    0x0006  : 'OpenPeriod',                                         // uint16, RW, DPS
    
    // User and credential management
    0x0010  : 'NumberOfLogRecordsSupported',                        // uint16, R V, O
    0x0011  : 'NumberOfTotalUsersSupported',                        // uint16, R V, USR
    0x0012  : 'NumberOfPINUsersSupported',                          // uint16, R V, PIN
    0x0013  : 'NumberOfRFIDUsersSupported',                         // uint16, R V, RID
    0x0014  : 'NumberOfWeekDaySchedulesSupportedPerUser',           // uint8, R V, WDSCH
    0x0015  : 'NumberOfYearDaySchedulesSupportedPerUser',           // uint8, R V, YDSCH
    0x0016  : 'NumberOfHolidaySchedulesSupported',                  // uint8, R V, HDSCH
    0x0017  : 'MaxPINCodeLength',                                   // uint8, R V, PIN
    0x0018  : 'MinPINCodeLength',                                   // uint8, R V, PIN
    0x0019  : 'MaxRFIDCodeLength',                                  // uint8, R V, RID
    0x001A  : 'MinRFIDCodeLength',                                  // uint8, R V, RID
    0x001B  : 'CredentialRulesSupport',                             // DlCredentialRuleMask, R V, USR
    0x001C  : 'NumberOfCredentialsSupportedPerUser',                // uint8, R V, USR
    
    // Lock configuration attributes
    0x0020  : 'EnableLogging',                                      // bool, RW, O
    0x0021  : 'Language',                                           // string, RW, O
    0x0022  : 'LEDSettings',                                        // uint8, RW, O
    0x0023  : 'AutoRelockTime',                                     // uint32, RW, O
    0x0024  : 'SoundVolume',                                        // uint8, RW, O
    0x0025  : 'OperatingMode',                                      // OperatingModeEnum, RW, M
    0x0026  : 'SupportedOperatingModes',                            // DlSupportedOperatingModes, R V, M
    0x0027  : 'DefaultConfigurationRegister',                       // DlDefaultConfigurationRegister, R V, O
    0x0028  : 'EnableLocalProgramming',                             // bool, RW, O
    0x0029  : 'EnableOneTouchLocking',                              // bool, RW, O
    0x002A  : 'EnableInsideStatusLED',                              // bool, RW, O
    0x002B  : 'EnablePrivacyModeButton',                            // bool, RW, O
    0x002C  : 'LocalProgrammingFeatures',                           // DlLocalProgrammingFeatures, RW, O
    
    // Security and access control
    0x0030  : 'WrongCodeEntryLimit',                                // uint8, RW, O
    0x0031  : 'UserCodeTemporaryDisableTime',                       // uint8, RW, O
    0x0032  : 'SendPINOverTheAir',                                  // bool, RW, O
    0x0033  : 'RequirePINforRemoteOperation',                       // bool, RW, O
    0x0034  : 'SecurityLevel',                                      // SecurityLevelEnum, RW, O (Deprecated)
    0x0035  : 'ExpiringUserTimeout',                                // uint16, RW, O
    
    // Event masks (Notification feature)
    0x0040  : 'AlarmMask',                                          // DlAlarmMask, RW, NOT
    0x0041  : 'KeypadOperationEventMask',                           // DlKeypadOperationEventMask, RW, NOT
    0x0042  : 'RemoteOperationEventMask',                           // DlRemoteOperationEventMask, RW, NOT
    0x0043  : 'ManualOperationEventMask',                           // DlManualOperationEventMask, RW, NOT
    0x0044  : 'RFIDOperationEventMask',                             // DlRFIDOperationEventMask, RW, NOT
    0x0045  : 'KeypadProgrammingEventMask',                         // DlKeypadProgrammingEventMask, RW, NOT
    0x0046  : 'RemoteProgrammingEventMask',                         // DlRemoteProgrammingEventMask, RW, NOT
    0x0047  : 'RFIDProgrammingEventMask',                           // DlRFIDProgrammingEventMask, RW, NOT
    
    // Standard cluster attributes
    0xFFFB  : 'AttributeList',                                      // list, R V, M
    0xFFFC  : 'FeatureMap',                                         // FeatureMap, R V, M
    0xFFFD  : 'ClusterRevision'                                     // uint16, R V, M
]

// Aqara U200 : [FFF9] AcceptedCommandList: [0000, 0001, 0003, 001A, 001B, 001D, 0022, 0024, 0026]
// Aqara U200 : [FFF8] GeneratedCommandList: [001C, 0023, 0025]

@Field static final Map<Integer, String> DoorLockClusterCommands = [
    // Command ID : Name (per Matter 5.2.10)
    0x00    : 'LockDoor',                    // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:M
    0x01    : 'UnlockDoor',                  // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:M
    0x02    : 'Toggle',                      // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:X
    0x03    : 'UnlockWithTimeout',           // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:O
    0x04    : 'GetLogRecord',                // Direction:client ⇒ server; Response:GetLogRecordResponse; Access:M; Conformance:LOG
    0x05    : 'SetPINCode',                  // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x06    : 'GetPINCode',                  // Direction:client ⇒ server; Response:GetPINCodeResponse; Access:A; Conformance:!USR & PIN
    0x07    : 'ClearPINCode',                // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x08    : 'ClearAllPINCodes',            // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x09    : 'SetUserStatus',               // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x0A    : 'GetUserStatus',               // Direction:client ⇒ server; Response:GetUserStatusResponse; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x0B    : 'SetWeekDaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:WDSCH
    0x0C    : 'GetWeekDaySchedule',          // Direction:client ⇒ server; Response:GetWeekDayScheduleResponse; Access:A; Conformance:WDSCH
    0x0D    : 'ClearWeekDaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:WDSCH
    0x0E    : 'SetYearDaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:YDSCH
    0x0F    : 'GetYearDaySchedule',          // Direction:client ⇒ server; Response:GetYearDayScheduleResponse; Access:A; Conformance:YDSCH
    0x10    : 'ClearYearDaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:YDSCH
    0x11    : 'SetHolidaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:HDSCH
    0x12    : 'GetHolidaySchedule',          // Direction:client ⇒ server; Response:GetHolidayScheduleResponse; Access:A; Conformance:HDSCH
    0x13    : 'ClearHolidaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:HDSCH
    0x14    : 'SetUserType',                 // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x15    : 'GetUserType',                 // Direction:client ⇒ server; Response:GetUserTypeResponse; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x16    : 'SetRFIDCode',                 // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x17    : 'GetRFIDCode',                 // Direction:client ⇒ server; Response:GetRFIDCodeResponse; Access:A; Conformance:!USR & RID
    0x18    : 'ClearRFIDCode',               // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x19    : 'ClearAllRFIDCodes',           // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x1A    : 'SetUser',                     // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x1B    : 'GetUser',                     // Direction:client ⇒ server; Response:GetUserResponse; Access:A; Conformance:USR
    0x1C    : 'GetUserResponse',             // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x1D    : 'ClearUser',                   // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x20    : 'OperatingEventNotification',  // Direction:client ⇐ server; Response:No; Access:N; Conformance:[NOT]
    0x21    : 'ProgrammingEventNotification',// Direction:client ⇐ server; Response:No; Access:N; Conformance:[NOT]
    0x22    : 'SetCredential',               // Direction:client ⇒ server; Response:SetCredentialResponse; Access:A T; Conformance:USR
    0x23    : 'SetCredentialResponse',       // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x24    : 'GetCredentialStatus',         // Direction:client ⇒ server; Response:GetCredentialStatusResponse; Access:A; Conformance:USR
    0x25    : 'GetCredentialStatusResponse', // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x26    : 'ClearCredential',             // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x27    : 'UnboltDoor'                   // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:UBOLT
]



// 5.2.6.2. LockState Attribute (0x0000)
@Field static final Map<Integer, String> DoorLockClusterLockState = [
    0x00    : 'NotFullyLocked',
    0x01    : 'Locked',
    0x02    : 'Unlocked',
    0x03    : 'Unlatched'   // optional
]

// 5.2.6.3. LockType Attribute (0x0001)
@Field static final Map<String, String> DooorLockClusterLockType = [
    0x00    : 'deadbolt',   // Physical lock type is dead bolt
    0x01    : 'magnetic',   // Physical lock type is magnetic
    0x02    : 'other',      // Physical lock type is other
    0x03    : 'mortise',    // Physical lock type is mortise
    0x04    : 'rim',        // Physical lock type is rim
    0x05    : 'latchbolt',  // Physical lock type is latch bolt
    0x06    : 'cylindricalLock',// Physical lock type is cylindrical lock
    0x07    : 'tubularLock',    // Physical lock type is tubular lock
    0x08    : 'interconnectedLock', // Physical lock type is interconnected lock
    0x09    : 'deadLatch',  // Physical lock type is dead latch
    0x0A    : 'doorFurniture', // Physical lock type is door furniture
    0x0B    : 'eurocylinder'   // Physical lock type is eurocylinder
]

/*
The ActuatorEnabled attribute indicates if the lock is currently able to (Enabled) or not able to (Disabled)
process remote Lock, Unlock, or Unlock with Timeout commands.
This attribute has the following possible values:
Boolean Value Summary
0 Disabled
1 Enabled
*/

@Field static final Map<Integer, String> DoorLockClusterSupportedOperatingModes = [
    0x00    : 'Normal',             // (mandatory)
    0x01    : 'Vacation',
    0x02    : 'Privacy',
    0x03    : 'NoRemoteLockUnlock', // (mandatory)
    0x04    : 'Passage'
]

@Field static final Map<Integer, String> DoorLockClusterOperatingModeEnum = [
    0x00    : 'Normal',
    0x01    : 'Vacation',
    0x02    : 'Privacy',
    0x03    : 'NoRemoteLockUnlock',
    0x04    : 'Passage'
]

// Door Lock Event Enums
@Field static final Map<Integer, String> DoorLockClusterAlarmCode = [
    0x00    : 'LockJammed',
    0x01    : 'LockFactoryReset',
    0x03    : 'LockRadioPowerCycled',
    0x04    : 'WrongCodeEntryLimit',
    0x05    : 'FrontEsceutcheonRemoved',
    0x06    : 'DoorForcedOpen',
    0x07    : 'DoorAjar',
    0x08    : 'ForcedUser'
]

@Field static final Map<Integer, String> DoorLockClusterDoorState = [
    0x00    : 'Open',
    0x01    : 'Closed',
    0x02    : 'Jammed',
    0x03    : 'ForcedOpen',
    0x04    : 'UnspecifiedError',
    0x05    : 'Ajar'
]

@Field static final Map<Integer, String> DoorLockClusterLockOperationType = [
    0x00    : 'Lock',
    0x01    : 'Unlock',
    0x02    : 'NonAccessUserEvent',
    0x03    : 'ForcedUserEvent',
    0x04    : 'Unlatch'
]

@Field static final Map<Integer, String> DoorLockClusterOperationSource = [
    0x00    : 'Unspecified',
    0x01    : 'Manual',
    0x02    : 'ProprietaryRemote',
    0x03    : 'Keypad',
    0x04    : 'Auto',
    0x05    : 'Button',
    0x06    : 'Schedule',
    0x07    : 'Remote',
    0x08    : 'RFID',
    0x09    : 'Biometric'
]

@Field static final Map<Integer, String> DoorLockClusterOperationError = [
    0x00    : 'Unspecified',
    0x01    : 'InvalidCredential',
    0x02    : 'DisabledUserDenied',
    0x03    : 'Restricted',
    0x04    : 'InsufficientBattery'
]

@Field static final Map<Integer, String> DoorLockClusterLockDataType = [
    0x00    : 'Unspecified',
    0x01    : 'ProgrammingCode',
    0x02    : 'UserIndex',
    0x03    : 'WeekDaySchedule',
    0x04    : 'YearDaySchedule',
    0x05    : 'HolidaySchedule',
    0x06    : 'PIN',
    0x07    : 'RFID',
    0x08    : 'Fingerprint',
    0x09    : 'FingerVein',
    0x0A    : 'Face'
]

@Field static final Map<Integer, String> DoorLockClusterDataOperationType = [
    0x00    : 'Add',
    0x01    : 'Clear',
    0x02    : 'Modify'
]

@Field static final Map<Integer, String> HubitatCodeChangedType = [
    0x00    : 'added',
    0x01    : 'deleted',
    0x02    : 'changed',
    0x04    : 'failed'
]

@Field static final Map<Integer, String> CredentialTypeEnum = [
    0: 'ProgrammingPIN', // Programming PIN code credential type (O)
    1: 'PIN',            // PIN code credential type (PIN)
    2: 'RFID',           // RFID identifier credential type (RID)
    3: 'Fingerprint',    // Fingerprint identifier credential type (FGP)
    4: 'FingerVein',     // Finger vein identifier credential type (FGP)
    5: 'Face'            // Face identifier credential type (FACE)
]

@Field static final Map<Integer, String> DataOperationTypeEnum = [
    0: 'Add',    // Data is being added or was added (M)
    1: 'Clear',  // Data is being cleared or was cleared (M)
    2: 'Modify'  // Data is being modified or was modified (M)
]

// Helper method to decode CredentialRulesSupport bitmap
String decodeCredentialRules(Integer rules) {
    List<String> supported = []
    if (rules & 0x01) { supported.add('Single') }
    if (rules & 0x02) { supported.add('Dual') }
    if (rules & 0x04) { supported.add('Triple') }
    return supported.isEmpty() ? 'None' : supported.join(', ')
}


// 5.2.4. Features This cluster SHALL support the FeatureMap bitmap attribute as defined below.

// Matter Door Lock Feature Map bits (from Matter specification 1.3)
@Field static final Integer FEATURE_PIN_CREDENTIAL = 0x0001          // Bit 0: PIN credential support
@Field static final Integer FEATURE_RFID_CREDENTIAL = 0x0002         // Bit 1: RFID credential support
@Field static final Integer FEATURE_FINGER_CREDENTIALS = 0x0004      // Bit 2: Fingerprint credential support
@Field static final Integer FEATURE_LOGGING = 0x0008                 // Bit 3: Logging support
@Field static final Integer FEATURE_WEEK_DAY_SCHEDULES = 0x0010      // Bit 4: Week day access schedules
@Field static final Integer FEATURE_DOOR_POSITION_SENSOR = 0x0020    // Bit 5: Door position sensor
@Field static final Integer FEATURE_FACE_CREDENTIALS = 0x0040        // Bit 6: Face recognition credentials
@Field static final Integer FEATURE_COTA = 0x0080                    // Bit 7: Credential Over The Air (COTA)
@Field static final Integer FEATURE_USER_MANAGEMENT = 0x0100         // Bit 8: User management
@Field static final Integer FEATURE_NOTIFICATION = 0x0200            // Bit 9: Notification support
@Field static final Integer FEATURE_YEAR_DAY_SCHEDULES = 0x0400      // Bit 10: Year day access schedules
@Field static final Integer FEATURE_HOLIDAY_SCHEDULES = 0x0800       // Bit 11: Holiday schedules
@Field static final Integer FEATURE_UNBOLT = 0x1000                  // Bit 12: Unbolt support

String decodeFeatureMap(Integer featureMap) {
    if (featureMap == 0) { return 'None (Mandatory features only)' }
    List<String> features = []
    
    if (featureMap & 0x0001) { features.add('PIN') }                     // Bit 0   PIN - Lock supports PIN credentials (via keypad, or over-the-air)
    if (featureMap & 0x0002) { features.add('RFID') }                    // Bit 1   RID - Lock supports RFID credentials
    if (featureMap & 0x0004) { features.add('Fingerprint') }             // Bit 2   FGP - Lock supports finger related credentials (fingerprint, finger vein)
    if (featureMap & 0x0008) { features.add('Logging') }                 // Bit 3   LOG
    if (featureMap & 0x0010) { features.add('WeekDaySchedules') }        // Bit 4   WDSCH
    if (featureMap & 0x0020) { features.add('DoorPositionSensor') }      // Bit 5   DPS
    if (featureMap & 0x0040) { features.add('FaceCredential') }          // Bit 6   FACE
    if (featureMap & 0x0080) { features.add('COTA') }                    // Bit 7   COTA - CredentialOverTheAirAccess - PIN codes overtheair supported for lock/unlock operations
    if (featureMap & 0x0100) { features.add('UserManagement') }          // Bit 8   USR - [ PIN | RID | FGP |FACE ] - Lock supports the user commands and database
    if (featureMap & 0x0200) { features.add('Notification') }            // Bit 9   NOT
    if (featureMap & 0x0400) { features.add('YearDaySchedules') }        // Bit 10  YDSCH
    if (featureMap & 0x0800) { features.add('HolidaySchedules') }        // Bit 11  HDSCH
    if (featureMap & 0x1000) { features.add('Unbolt') }                  // Bit 12  UBOLT - Unbolting - Lock supports unbolting
    
    return features.join(', ')
}

// Helper method to decode KeypadOperationEventMask bitmap (DlKeypadOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidPIN
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidCode
// Bit 6 (0x40): UnlockInvalidSchedule
// Bit 7 (0x80): NonAccessUserOpEvent
String decodeKeypadOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidPIN') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidCode') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    if (mask & 0x80) { enabled.add('NonAccessUserOpEvent') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode KeypadProgrammingEventMask bitmap (DlKeypadProgrammingEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ProgrammingPINChanged
// Bit 2 (0x04): PINAdded
// Bit 3 (0x08): PINCleared
// Bit 4 (0x10): PINChanged
// Bit 6 (0x40): OUT OF SPEC - possibly Nuki proprietary extension
String decodeKeypadProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ProgrammingPINChanged') }
    if (mask & 0x04) { enabled.add('PINAdded') }
    if (mask & 0x08) { enabled.add('PINCleared') }
    if (mask & 0x10) { enabled.add('PINChanged') }
    if (mask & 0x20) { enabled.add('Reserved(0x20)') }
    if (mask & 0x40) { enabled.add('Unknown/Proprietary(0x40)') }  // Nuki specific?
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode RemoteOperationEventMask bitmap (DlRemoteOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidCode
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidCode
// Bit 6 (0x40): UnlockInvalidSchedule
String decodeRemoteOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidCode') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidCode') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode ManualOperationEventMask bitmap (DlManualOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ThumbturnLock
// Bit 2 (0x04): ThumbturnUnlock
// Bit 3 (0x08): OneTouchLock
// Bit 4 (0x10): KeyLock
// Bit 5 (0x20): KeyUnlock
// Bit 6 (0x40): AutoLock
// Bit 7 (0x80): ScheduleLock
// Bit 8 (0x100): ScheduleUnlock
// Bit 9 (0x200): ManualLock
// Bit 10 (0x400): ManualUnlock
String decodeManualOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ThumbturnLock') }
    if (mask & 0x04) { enabled.add('ThumbturnUnlock') }
    if (mask & 0x08) { enabled.add('OneTouchLock') }
    if (mask & 0x10) { enabled.add('KeyLock') }
    if (mask & 0x20) { enabled.add('KeyUnlock') }
    if (mask & 0x40) { enabled.add('AutoLock') }
    if (mask & 0x80) { enabled.add('ScheduleLock') }
    if (mask & 0x100) { enabled.add('ScheduleUnlock') }
    if (mask & 0x200) { enabled.add('ManualLock') }
    if (mask & 0x400) { enabled.add('ManualUnlock') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode RFIDOperationEventMask bitmap (DlRFIDOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidRFID
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidRFID
// Bit 6 (0x40): UnlockInvalidSchedule
String decodeRFIDOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidRFID') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidRFID') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// AlarmMask (0x0080) decoder
// Bit 0 (0x01): LockJammed
// Bit 1 (0x02): LockFactoryReset
// Bit 2 (0x04): LockRadioPowerCycled
// Bit 3 (0x08): WrongCodeEntryLimit
// Bit 4 (0x10): FrontEscutcheonRemoved
// Bit 5 (0x20): DoorForcedOpen
// Bit 6 (0x40): DoorAjar
// Bit 7 (0x80): ForcedUser
String decodeAlarmMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('LockJammed') }
    if (mask & 0x02) { enabled.add('LockFactoryReset') }
    if (mask & 0x04) { enabled.add('LockRadioPowerCycled') }
    if (mask & 0x08) { enabled.add('WrongCodeEntryLimit') }
    if (mask & 0x10) { enabled.add('FrontEscutcheonRemoved') }
    if (mask & 0x20) { enabled.add('DoorForcedOpen') }
    if (mask & 0x40) { enabled.add('DoorAjar') }
    if (mask & 0x80) { enabled.add('ForcedUser') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// RemoteProgrammingEventMask (0x0046) decoder - per Matter specification
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ProgrammingPINChanged
// Bit 2 (0x04): PINAdded
// Bit 3 (0x08): PINCleared
// Bit 4 (0x10): PINChanged
// Bit 5 (0x20): PINCodeDuplicate
// Bit 6 (0x40): Reserved
// Bit 7 (0x80): Reserved
String decodeRemoteProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ProgrammingPINChanged') }
    if (mask & 0x04) { enabled.add('PINAdded') }
    if (mask & 0x08) { enabled.add('PINCleared') }
    if (mask & 0x10) { enabled.add('PINChanged') }
    if (mask & 0x20) { enabled.add('PINCodeDuplicate') }
    if (mask & 0x40) { enabled.add('Reserved(0x40)') }
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// RFIDProgrammingEventMask (0x0047) decoder - per Matter specification
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): RFIDCodeAdded
// Bit 2 (0x04): RFIDCodeCleared
// Bit 3 (0x08): RFIDCodeDuplicate
// Bit 4 (0x10): RFIDCodeInvalid
// Bit 5 (0x20): RFIDCodeChanged
// Bit 6 (0x40): Reserved
// Bit 7 (0x80): Reserved
String decodeRFIDProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('RFIDCodeAdded') }
    if (mask & 0x04) { enabled.add('RFIDCodeCleared') }
    if (mask & 0x08) { enabled.add('RFIDCodeDuplicate') }
    if (mask & 0x10) { enabled.add('RFIDCodeInvalid') }
    if (mask & 0x20) { enabled.add('RFIDCodeChanged') }
    if (mask & 0x40) { enabled.add('Reserved(0x40)') }
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// ============ Lock Command Helper Methods ============

/**
 * Convert ASCII PIN string to hex bytes
 * @param s ASCII string (e.g., "123456")
 * @return hex string (e.g., "313233343536")
 */
private static String asciiToHex(final String s) {
    if (s == null) return ''
    byte[] bytes = s.getBytes('US-ASCII')
    return bytes.collect { String.format('%02X', it) }.join()
}

@Field static final String DRIVER = 'Matter Advanced Bridge'
@Field static final String COMPONENT = 'Matter Generic Component Door Lock'
@Field static final String WIKI   = 'Get help on GitHub Wiki page:'
@Field static final String COMM_LINK =   "https://community.hubitat.com/t/release-matter-advanced-bridge-limited-device-support/135252/1"
@Field static final String GITHUB_LINK = "https://github.com/kkossev/Hubitat---Matter-Advanced-Bridge/wiki/Matter-Advanced-Bridge-%E2%80%90-Door-Locks"
// credits @jtp10181
String fmtHelpInfo(String str) {
	String info = "${DRIVER} v${parent?.version()}<br> ${COMPONENT} v${matterComponentLockVersion}"
	String prefLink = "<a href='${GITHUB_LINK}' target='_blank'>${WIKI}<br><div style='font-size: 70%;'>${info}</div></a>"
    String topStyle = "style='font-size: 18px; padding: 1px 12px; border: 2px solid green; border-radius: 6px; color: green;'"
    String topLink = "<a ${topStyle} href='${COMM_LINK}' target='_blank'>${str}<br><div style='font-size: 14px;'>${info}</div></a>"

	return "<div style='font-size: 160%; font-style: bold; padding: 2px 0px; text-align: center;'>${prefLink}</div>" +
		"<div style='text-align: center; position: absolute; top: 46px; right: 60px; padding: 0px;'><ul class='nav'><li>${topLink}</ul></li></div>"
}


// Helper method to safely parse hex string to Integer
Integer safeParseHex(String hexValue) {
    try {
        return Integer.parseInt(hexValue, 16)
    } catch (NumberFormatException e) {
        logWarn "safeParseHex: failed to parse '${hexValue}', returning 0"
        return 0
    }
}



def testInvoke(params) {

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) {
        logWarn "testSetCredentialSmartThingsStyleRemoteOnly: deviceNumber is null"
        return
    }

    /*
     * Same as SmartThings-style test, but:
     * userType = 9  REMOTE_ONLY_USER
     */

    String tlv = "1524000035012400012501010018300206313233343536340324040124050918"

    String cmd = matter.invoke(deviceNumber, 0x0101, 0x0022, 2000, tlv)

    logDebug "testSetCredentialSmartThingsStyleRemoteOnly: tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "testing SmartThings-style SetCredential: PIN 123456, credentialIndex=1, userIndex=NULL, userType=REMOTE_ONLY_USER...")
    parent?.sendToDevice(cmd)


}

void testUnlockWithCode(code = null) {
    if (logEnable) log.debug "testUnlockWithCode: ${code}"
    // getLockCodes() is the Hubitat-standard helper; in the virtual lock reference this is the implicit 'lockCodes' property
    Map lockCodesMap = getLockCodes()
    Object lockCode = lockCodesMap.find { it.value.code == "${code}" }
    if (lockCode) {
        Map payloadData = ["${lockCode.key}": lockCode.value]
        String descriptionText = "${device.displayName} was unlocked by ${lockCode.value.name}"
        if (txtEnable) log.info "${descriptionText}"
        def eventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(payloadData)) : payloadData
        logLockCodeEventPayload('lock', 'unlocked', payloadData)
        sendEvent(name: 'lock', value: 'unlocked', descriptionText: descriptionText, type: 'physical', data: eventData, isStateChange: true)
        sendEvent(name: 'lastCodeName', value: lockCode.value.name, descriptionText: descriptionText, isStateChange: true)
    } else {
        if (txtEnable) log.debug "testUnlockWithCode: no matching code found for '${code}'"
    }
}

// --------- common matter libraries included below --------

#include kkossev.matterCommonLib
#include kkossev.matterHealthStatusLib
