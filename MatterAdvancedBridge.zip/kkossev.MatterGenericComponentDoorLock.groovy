/* groovylint-disable BitwiseOperatorInConditional, CompileStatic, DuplicateStringLiteral, LineLength, PublicMethodsBeforeNonPublicMethods */
/*
  *  'Matter Generic Component Door Lock' - component driver for Matter Advanced Bridge
  *
  *  https://community.hubitat.com/t/dynamic-capabilities-commands-and-attributes-for-drivers/98342
  *  https://community.hubitat.com/t/project-zemismart-m1-matter-bridge-for-tuya-zigbee-devices-matter/127009
  *
  *  Licensed Virtual the Apache License, Version 2.0 (the "License"); you may not use this file except
  *  in compliance with the License. You may obtain a copy of the License at:
  *
  *      http://www.apache.org/licenses/LICENSE-2.0
  *
  *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
  *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
  *  for the specific language governing permissions and limitations under the License.
  *
  * ver. 1.0.0  2024-04-05 dds82   - first version
  * ver. 1.1.0  2024-07-20 kkossev - added Battery capability; added Identify command; added warning state and log messages; added handling of unprocessed Door Lock events
  * ver. 1.1.1  2024-07-23 kkossev - added switch capability (for Apple Home integration workaround)
  * ver. 1.1.2  2024-08-12 kkossev - fixed importURL
  * ver. 1.2.0  2025-01-10 kkossev + Calude Sonnet 4.5 : Matter events handling rework; Door Lock working! :) added ping command and RTT attribute; removed switch capability
  * ver. 1.3.0  2025-01-14 kkossev - moved component methods from parent to component driver; major refactoring 
  * ver. 1.3.1  2025-01-22 kkossev + Claude Haiku 4.5 : Aqara U200 Door Lock support improvements (clearUser seems to be working!)
  * 
  *                                  TODO: add driver version to the state variables 
  *                                  TODO: initialize lock with 'unknown' attributes when the device is created
  *                                  TODO: filter duplicated events
  *                                  TODO: add [physical] [digital] event type to events and logs
  *                                  TODO: analyze https://github.com/SmartThingsCommunity/SmartThingsEdgeDrivers/tree/main/drivers/SmartThings/matter-lock 
  *                                  TODO: analyze https://matter-survey.org/cluster/0x0101
  *                                  TODO: update gitHub documentation
  *                                  
  *
*/

import groovy.transform.Field
import groovy.transform.CompileStatic
import hubitat.helper.HexUtils
import hubitat.matter.DataType

@Field static final String matterComponentLockVersion = '1.3.1'
@Field static final String matterComponentLockStamp   = '2025/01/22 7:31 AM'

@Field static final Boolean _DEBUG_LOCK = true              // MAKE IT false for PRODUCTION !   
@Field static final Boolean _DEFAULT_LOG_ENABLE = true      // disable on production

// Matter Door Lock Feature Map bits (from Matter specification 1.3)
@Field static final Integer FEATURE_PIN_CREDENTIAL = 0x0001          // Bit 0: PIN credential support
@Field static final Integer FEATURE_RFID_CREDENTIAL = 0x0002         // Bit 1: RFID credential support
@Field static final Integer FEATURE_FINGER_CREDENTIALS = 0x0004      // Bit 2: Fingerprint credential support
@Field static final Integer FEATURE_LOGGING = 0x0008                 // Bit 3: Logging support
@Field static final Integer FEATURE_WEEK_DAY_SCHEDULES = 0x0010      // Bit 4: Week day access schedules
@Field static final Integer FEATURE_DOOR_POSITION_SENSOR = 0x0020    // Bit 5: Door position sensor
@Field static final Integer FEATURE_FACE_CREDENTIALS = 0x0040        // Bit 6: Face recognition credentials
@Field static final Integer FEATURE_COTA = 0x0080                    // Bit 7: Credential Over The Air (COTA)
@Field static final Integer FEATURE_USER_MANAGEMENT = 0x0100         // Bit 8: User management
@Field static final Integer FEATURE_NOTIFICATION = 0x0200            // Bit 9: Notification support
@Field static final Integer FEATURE_YEAR_DAY_SCHEDULES = 0x0400      // Bit 10: Year day access schedules
@Field static final Integer FEATURE_HOLIDAY_SCHEDULES = 0x0800       // Bit 11: Holiday schedules
@Field static final Integer FEATURE_UNBOLT = 0x1000                  // Bit 12: Unbolt support

metadata {
    definition(name: 'Matter Generic Component Door Lock', namespace: 'kkossev', author: 'Daniel Segall', importUrl: 'https://raw.githubusercontent.com/kkossev/Hubitat---Matter-Advanced-Bridge/main/Components/Matter_Generic_Component_Door_Lock') {
        capability 'Sensor'
        capability 'Actuator'
        capability 'Battery'
        capability 'Lock'       // lock - ENUM ["locked", "unlocked with timeout", "unlocked", "unknown"]
        capability 'LockCodes'  // lockCodes, codeChanged, codeLength, maxCodes | setCode(pos,pin,name), deleteCode(pos), getCodes(), setCodeLength(len)
        capability 'Refresh'

        command    'identify', [[name: 'Identify the lock device']]
        command    'getInfo', [[name: 'Check the live logs and the device data for additional infoormation on this device']]
        command    'unlockWithPIN', [[name: 'pin*', type: 'STRING', description: 'unlock with PIN (not available on all locks)']]
        command    'unboltDoor', [[name: 'Unbolt door (not available on all locks)']]
        
        // LockCodes custom commands with dynamic feature support indication
        command    'setCode', [[name: 'codePosition*', type: 'NUMBER', description: 'Code slot (1-based)'],
                               [name: 'pinCode*', type: 'STRING', description: 'PIN code (4-8 digits)'],
                               [name: 'name', type: 'STRING', description: "User name (optional)<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        command    'deleteCode', [[name: 'codePosition*', type: 'NUMBER', description: "Code slot to delete<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        command    'getCodes', [[name: "Retrieve all PIN codes<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]

        // TODO - move these to state variables or device data ?
        attribute 'lockType', 'ENUM', ['deadbolt', 'magnetic', 'other', 'mortise', 'rim', 'latchbolt', 'cylindricalLock', 'tubularLock', 'interconnectedLock', 'deadLatch', 'doorFurniture', 'eurocylinder']
        attribute 'actuatorEnabled', 'ENUM', ['enabled', 'disabled']
        attribute 'operatingMode', 'ENUM', ['Normal', 'Vacation', 'Privacy', 'NoRemoteLockUnlock', 'Passage']
        attribute 'supportedOperatingModes', 'STRING'
        
        // Event-related attributes
        // TODO: consider moving these to state variables or device data instead of attributes ?
        attribute 'lastLockOperation', 'STRING'
        attribute 'lastOperationSource', 'STRING'
        attribute 'lastLockOperationError', 'STRING'
        attribute 'lastUserChange', 'STRING'
        attribute 'lockAlarm', 'STRING'
        attribute 'doorState', 'STRING'
        
        // Infrastructure/health-check attributes
        attribute 'powerSourceStatus', 'ENUM', ['active', 'standby', 'unavailable']

        if (_DEBUG_LOCK) {
            command 'getCredentialStatus', [[name:'pinIndex*', type: 'STRING', description: 'PIN Index (1-255)', defaultValue: '1']]
            command 'getUser', [[name:'userIndex*', type: 'STRING', description: 'User Index (0-65534)', defaultValue: '1']]
            command 'clearUser', [[name:'userIndex*', type: 'STRING', description: 'User Index (0-65534)', defaultValue: '1']]
            command 'readFeatureMap'    // TODO - move to the main driver 
            command 'readAttributeList' // Read and display 0101_FFFB AttributeList
            command 'testLock', [[name: 'testLock', type: 'STRING', description: 'test', defaultValue : '']]    // for debug purposes only
        }
    }
}

preferences {
    section {
	    input name: "helpInfo", type: "hidden", title: fmtHelpInfo("Community Link")
        input name: 'logEnable',
              type: 'bool',
              title: '<b>Enable debug logging</b>',
              required: false,
              defaultValue: _DEFAULT_LOG_ENABLE

        input name: 'txtEnable',
              type: 'bool',
              title: '<b>Enable descriptionText logging</b>',
              required: false,
              defaultValue: true
        input name: 'advancedOptions', type: 'bool', title: '<b>Advanced Options</b>', description: '<i>These advanced options should be already automatically set in an optimal way for your device...</i>', defaultValue: false
        if (device && advancedOptions == true) {
            input name: 'ignoreCompatibilityChecks', type: 'bool', title: '<b>Ignore Compatibility Checks</b>', description: '<i>Allow executing commands that may not be supported by this lock</i>', defaultValue: false
        }

    }
}

import groovy.transform.CompileStatic

/* groovylint-disable-next-line UnusedMethodParameter */
void parse(String description) { log.warn 'parse(String description) not implemented' }

// parse commands from parent
void parse(List<Map> parsedEvents) {
    //if (logEnable) { log.debug "${parsedEvents}" }
    parsedEvents.each { d ->
        if (d.name == 'lock') {
            if (device.currentValue('lock') != d.value) {
                if (d.descriptionText) { logInfo "${d.descriptionText}" }
                sendEvent(d)
            }
            else {
                logDebug ": ignored lock event '${d.value}' (no change)"
            }
        }
        else if (d.name == 'rtt') {
            // Delegate to health status library
            parseRttEvent(d)
        }
        else if (d.name == 'unprocessed') {
            processUnprocessed(d)
        }
        else {
            if (d.descriptionText) { logInfo "${d.descriptionText}" }
            sendEvent(d)
        }
    }
}

void identify() {
    logDebug "identifying ..."
    parent?.componentIdentify(device)
}

// Command to lock device
void lock() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', 'locking...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x00, 2000)
    parent?.sendToDevice(cmd)
}

// Command to unlock device
void unlock() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', 'unlocking...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x01, 2000)
    parent?.sendToDevice(cmd)
}

// Command to unbolt door (for locks with separate bolt mechanism)
void unboltDoor() {
    // TODO: check if the lock supports this feature
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', 'unbolting door...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x27, 2000)
    parent?.sendToDevice(cmd)
}

//Command to unlock device with PIN
void unlockWithPIN(String pin) {
    if (!pin) {
        logWarn "unlockWithPIN: PIN is required"
        return
    }
    /* TODO: validate PIN format and length, depending on lock capabilities and the driver settings
    if (!(pin ==~ /^\d{6}$/)) {
        logWarn "unlockWithPIN: PIN must be exactly 6 digits, got '${pin}'"
        return
    }
    */
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', "unlocking with PIN...")
    
    // Build PINCode field manually as TLV octet string
    String pinHex = asciiToHex(pin)
    String pinLength = HexUtils.integerToHexString(pinHex.length() / 2, 1)
    
    // Build TLV structure: context tag 0, octet string type (0x0C), length, data
    String cmdPayload = '15'  // Structure start
    cmdPayload += '0C00' + pinLength + pinHex  // Context tag 0, OCTET_STRING1, length, PIN bytes
    cmdPayload += '18'  // Structure end
    
    // TODO - not tested yet!
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x01, 2000) + " {${cmdPayload}}"
    logDebug "unlockWithPIN: sending command with payload: ${cmdPayload}"
    parent?.sendToDevice(cmd)
}

// Command to query PIN credential status
void getCredentialStatus(String pinIndex) {
    if (!supportsLockCodes()) {
        logWarn "getCredentialStatus: This lock does not support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }
    
    if (!pinIndex) {
        logWarn "getCredentialStatus: PIN index is required"
        return
    }
    Integer index = pinIndex as Integer
    if (index < 1 || index > 255) {
        logWarn "getCredentialStatus: PIN index must be 1-255, got '${pinIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', "querying PIN credential status for index ${index}...")
    
    // Build GetCredentialStatus command (0x24)
    // Command has single field: credential structure {credentialType: enum8, credentialIndex: uint16}
    // Build TLV manually since we need nested structure
    
    String credIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(index, 2))
    
    // Build credential structure (anonymous struct)
    String credentialStruct = '15'  // Structure start (anonymous)
    credentialStruct += '2400' + '01'  // Context tag 0: credentialType = 1 (PIN), UINT8
    credentialStruct += '2501' + credIndexHexLE  // Context tag 1: credentialIndex, UINT16
    credentialStruct += '18'  // Structure end
    
    // Wrap the structure as field 0 of the command
    String cmdPayload = '15'  // Command structure start
    cmdPayload += '30' + credentialStruct  // Context tag 0: credential structure
    cmdPayload += '18'  // Command structure end
    
    logDebug "getCredentialStatus: payload={${cmdPayload}}"
    
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x24) + " {${cmdPayload}}"
    parent?.sendToDevice(cmd)
}

// Command to get user information
void getUser(String userIndex) {
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "getUser: This lock does not support User management (FeatureMap indicates no User support)"
        return
    }
    
    if (!userIndex) {
        logWarn "getUser: User index is required"
        return
    }
    Integer index = userIndex as Integer
    if (index < 1 || index > 65534) {
        logWarn "getUser: User index must be 1-65534, got '${userIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', "querying user information for index ${index}...")
    

    List<Map<String, String>> cmdFields = []
    cmdFields.add(matter.cmdField(0x05, 0x00, zigbee.swapOctets(HexUtils.integerToHexString(index, 2))))

    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001B, cmdFields)
    logDebug "getUser: cmd=${cmd}"
    parent?.sendToDevice(cmd)
}

// Command to clear/delete a user
void clearUser(String userIndex) {
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "clearUser: This lock does not support User management (FeatureMap indicates no User support)"
        return
    }
    
    if (!userIndex) {
        logWarn "clearUser: User index is required"
        return
    }
    Integer index = userIndex as Integer
    if (index < 1 || index > 65534) {
        logWarn "clearUser: User index must be 1-65534, got '${userIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', "clearing user at index ${index}...")
    logDebug "clearUser: clearing user at index ${index}"
    List<Map<String, String>> cmdFields = []
    cmdFields.add(matter.cmdField(0x05, 0x00, zigbee.swapOctets(HexUtils.integerToHexString(index, 2))))
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001D, 2000, cmdFields)

    parent?.sendToDevice(cmd)
}

// Helper function to check if setCodeLength is supported by this lock
Boolean isSetCodeLengthEnabled() {
    // TODO: Check FeatureMap or device capabilities to determine support
    return false
}

/**
 * Check if a specific Matter Door Lock feature is enabled on this lock
 * @param featureBit The feature bit to check (use FEATURE_* constants)
 * @return true if the feature is enabled, false otherwise
 */
Boolean isFeatureEnabled(Integer featureBit) {
    // Bypass feature checks if ignoreCompatibilityChecks is enabled
    if (settings?.ignoreCompatibilityChecks == true) {
        logDebug "isFeatureEnabled: ignoreCompatibilityChecks enabled - bypassing feature check for 0x${Integer.toHexString(featureBit).toUpperCase()}"
        return true
    }
    
    // Get FeatureMap from fingerprintData
    Map fingerprint = getFingerprintData()
    String featureMapHex = fingerprint?.get('0101_FFFC')
    
    if (!featureMapHex) {
        logWarn "isFeatureEnabled: FeatureMap not available in fingerprintData - features unknown"
        return false
    }
    
    // Parse FeatureMap value
    Integer featureMap = 0
    try {
        // Remove 0x prefix if present
        featureMapHex = featureMapHex.replaceFirst('^0x', '')
        featureMap = Integer.parseInt(featureMapHex, 16)
    } catch (Exception e) {
        logWarn "isFeatureEnabled: Failed to parse FeatureMap '${featureMapHex}': ${e.message}"
        return false
    }
    
    // Check if the specific feature bit is set
    boolean enabled = (featureMap & featureBit) != 0
    
    logDebug "isFeatureEnabled: FeatureMap=0x${Integer.toHexString(featureMap).toUpperCase()}, checking bit 0x${Integer.toHexString(featureBit).toUpperCase()}: ${enabled}"
    
    return enabled
}

/**
 * Check if this lock supports PIN credential management (LockCodes capability)
 * @return true if PIN credentials and user management are supported
 */
Boolean supportsLockCodes() {
    // Bypass feature checks if ignoreCompatibilityChecks is enabled
    if (settings?.ignoreCompatibilityChecks == true) {
        logDebug "supportsLockCodes: ignoreCompatibilityChecks enabled - bypassing PIN/User feature checks"
        return true
    }
    
    return isFeatureEnabled(FEATURE_PIN_CREDENTIAL) && isFeatureEnabled(FEATURE_USER_MANAGEMENT)
}

/**
 * Helper method for dynamic command parameter display
 * Returns a string indicating whether this device supports PIN code management
 * Used in command metadata to show feature support status to users
 */
String isCodeAllowed() {
    if (false/*supportsLockCodes()*/) {
        return "Your device ${device?.displayName} SUPPORTS PIN code management"
    } else {
        Map fingerprint = getFingerprintData()
        String featureMapHex = fingerprint?.get('0101_FFFC') ?: '??'
        return "Your device ${device?.displayName} does NOT SUPPORT PIN code management (FeatureMap=0x${featureMapHex})"
    }
}

// ========== LockCodes Capability Methods ==========
// Note: These methods are part of the LockCodes capability which is always declared
// However, not all Matter locks support PIN management. Each method checks feature support.

/**
 * Set a PIN code for a user (LockCodes capability)
 * @param codePosition Position/slot number (1-based)
 * @param pinCode PIN code (4-8 digits typically)
 * @param name Optional user name
 */
void setCode(codePosition, pinCode, name = null) {
    if (!supportsLockCodes()) {
        logWarn "setCode: This lock does not support PIN credential management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'codeChanged', value: "${codePosition} failed", descriptionText: "Lock does not support PIN codes", isStateChange: true)
        return
    }
    
    logInfo "setCode: position=${codePosition}, PIN=${pinCode ? '****' : 'null'}, name=${name}"
    
    // TODO: Implement SetCredential command (0x22) with proper TLV encoding
    // This requires:
    // 1. Check if user exists at this position (GetUser 0x1B)
    // 2. If not, create user (SetUser 0x1A)
    // 3. Set credential (SetCredential 0x22)
    
    logWarn "setCode: Not yet implemented - requires Matter User and Credential management"
    sendEvent(name: 'codeChanged', value: "${codePosition} failed", descriptionText: "setCode not yet implemented", isStateChange: true)
}

/**
 * Delete a PIN code (LockCodes capability)
 * @param codePosition Position/slot number (1-based)
 */
void deleteCode(codePosition) {
    if (!supportsLockCodes()) {
        logWarn "deleteCode: This lock does not support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }
    
    logInfo "deleteCode: position=${codePosition}"
    
    // TODO: Implement ClearCredential command (0x26)
    // May also need to clear the user (ClearUser 0x1D) depending on lock behavior
    
    logWarn "deleteCode: Not yet implemented - requires Matter Credential management"
    sendEvent(name: 'codeChanged', value: "${codePosition} deleted", descriptionText: "deleteCode not yet implemented", isStateChange: true)
}

/**
 * Get all PIN codes (LockCodes capability)
 * This populates the lockCodes attribute with current code information
 */
void getCodes() {
    if (!supportsLockCodes()) {
        logWarn "getCodes: This lock does not support PIN credential management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'lockCodes', value: '{}', descriptionText: "Lock does not support PIN codes")
        return
    }
    
    logInfo "getCodes: retrieving all PIN codes"
    
    // TODO: Implement:
    // 1. Get NumberOfPINUsersSupported to know how many to query
    // 2. Loop through GetUser (0x1B) for each position
    // 3. Build lockCodes JSON and update attribute
    
    logWarn "getCodes: Not yet implemented - requires Matter User query"
    sendEvent(name: 'lockCodes', value: '{}', descriptionText: "getCodes not yet implemented")
}

// ========== End LockCodes Capability Methods ==========

// Command to set the maximum PIN code length for this lock (per Hubitat LockCodes capability)
// NOTE: Matter locks have FIXED PIN length constraints (MaxPINCodeLength/MinPINCodeLength are read-only)
// This command only updates the Hubitat codeLength attribute for compatibility
void setCodeLength(BigDecimal length) {
    if (!length) {
        logWarn "setCodeLength: PIN code length is required"
        return
    }
    Integer codeLength = length.toInteger()
    if (codeLength < 4 || codeLength > 8) {
        logWarn "setCodeLength: PIN code length must be 4-8 digits, got '${length}'"
        return
    }
    
    logInfo "setCodeLength: updating Hubitat codeLength attribute to ${codeLength} (Matter locks have fixed PIN length constraints)"
    
    // Update codeLength attribute with digital event type for Hubitat compatibility
    sendEvent(name: 'codeLength', value: codeLength, type: 'digital', descriptionText: "${device.displayName} code length set to ${codeLength}")
}

// Read FeatureMap attribute to see which features are supported
// TODO - move to the main driver
void readFeatureMap() {
    parent?.componentLog(device, 'debug', 'reading FeatureMap attribute...')
    String endpoint = device.getDataValue('id') ?: '1'
    String cluster = '257'  // 0x0101 Door Lock cluster
    String attribute = '65532'  // 0xFFFC FeatureMap
    parent?.readAttribute([endpoint, cluster, attribute])
}

// Read AttributeList (0xFFFB) to see what attributes are supported
// This reads the raw attribute list from the lock and logs it for debugging
void readAttributeList() {
    logInfo "=== Reading AttributeList (0xFFFB) ==="
    
    // Check fingerprint data
    Map fingerprint = getFingerprintData()
    if (fingerprint) {
        List attrList = fingerprint['0101_FFFB']
        if (attrList) {
            logInfo "Fingerprint Data '0101_FFFB': ${attrList}"
        } else {
            logWarn "Fingerprint Data '0101_FFFB' not found in fingerprint"
        }
        
        // Also show all available cluster data
        logInfo "Available fingerprint keys: ${fingerprint.keySet()}"
    } else {
        logWarn "Fingerprint data not available in device data"
    }
    
    // Request fresh read from lock
    parent?.componentLog(device, 'debug', 'requesting AttributeList from lock...')
    String endpoint = device.getDataValue('id') ?: '1'
    String cluster = '257'  // 0x0101 Door Lock cluster
    String attribute = '65531'  // 0xFFFB AttributeList
    parent?.readAttribute([endpoint, cluster, attribute])
    
    logInfo "=== Expected per Matter spec: 0x40-0x45 for event masks ==="
    logInfo "=== If lock reports 0x80-0x88, this is non-standard ==="
    
    // Test: Read both standard and Nuki-reported attribute ranges
    logInfo "=== Testing: Reading spec-compliant event mask attributes (0x40-0x45) ==="
    parent?.readAttribute([endpoint, cluster, '64'])    // 0x40 AlarmMask (spec)
    parent?.readAttribute([endpoint, cluster, '65'])    // 0x41 KeypadOperationEventMask (spec)
    parent?.readAttribute([endpoint, cluster, '66'])    // 0x42 RemoteOperationEventMask (spec)
    parent?.readAttribute([endpoint, cluster, '67'])    // 0x43 ManualOperationEventMask (spec)
    parent?.readAttribute([endpoint, cluster, '68'])    // 0x44 RFIDOperationEventMask (spec)
    parent?.readAttribute([endpoint, cluster, '69'])    // 0x45 KeypadProgrammingEventMask (spec)
    
    logInfo "=== Testing: Reading Nuki-reported attributes (0x80-0x88) ==="
    parent?.readAttribute([endpoint, cluster, '128'])   // 0x80 (Nuki reports)
    parent?.readAttribute([endpoint, cluster, '129'])   // 0x81 (Nuki reports)
    parent?.readAttribute([endpoint, cluster, '130'])   // 0x82 (Nuki reports)
    parent?.readAttribute([endpoint, cluster, '131'])   // 0x83 (Nuki reports)
    parent?.readAttribute([endpoint, cluster, '135'])   // 0x87 (Nuki reports)
    parent?.readAttribute([endpoint, cluster, '136'])   // 0x88 (Nuki reports)
    
    logInfo "=== Check logs to see which attributes return valid data ==="
}

// Helper method to generate info string with feature support status
String generateInfoString() {
    Map fingerprint = getFingerprintData()
    String featureMapHex = fingerprint?.get('0101_FFFC') ?: '??'
    String featureInfo = supportsLockCodes() ? 
        "Your lock ${device.displayName} SUPPORTS PIN codes/users management" : 
        "Your lock ${device.displayName} does NOT support PIN codes/users management (FeatureMap=0x${featureMapHex})"
    return "${featureInfo}"
}

// Called when the device is first created
void installed() {
    log.info "${device.displayName} driver installed"
    state.info = generateInfoString()
    log.info "${device.displayName} ${state.info}"
}

// Called when the device is removed
void uninstalled() {
    log.info "${device.displayName} driver uninstalled"
}

// Called when the settings are updated
void updated() {
    log.info "${device.displayName} driver configuration updated"
    clearOldStateVariables()
    state.info = generateInfoString()
    log.info "${device.displayName} ${state.info}"
    if (logEnable) {
        logDebug settings as String
        runIn(86400, 'logsOff')
    }
}

// Clean up old/deprecated state variables
void clearOldStateVariables() {
    List<String> oldStateVars = ['warning', 'working', 'Warning', 'Working', 'comment', 'info']
    oldStateVars.each { String varName ->
        if (state.containsKey(varName)) {
            logDebug "clearOldStateVariables: removing '${varName}'"
            state.remove(varName)
        }
    }
}

/* groovylint-disable-next-line UnusedPrivateMethod */
private void logsOff() {
    log.warn "debug logging disabled for ${device.displayName} "
    device.updateSetting('logEnable', [value: 'false', type: 'bool'] )
}

void logInfo(msg)  { if (settings.txtEnable)   { log.info  "${device.displayName} " + msg } }
void logDebug(msg) { if (settings.logEnable)   { log.debug "${device.displayName} " + msg } }
void logTrace(msg) { if (settings.logEnable)   { log.trace "${device.displayName} " + msg } }
void logWarn(msg)  { if (settings.logEnable)   { log.warn  "${device.displayName} " + msg } }

void refresh() {
    clearOldStateVariables()
    parent?.componentRefresh(this.device)
}

// for use by parent driver
void setState(String stateName, String stateValue) {
    logDebug "setting state '${stateName}' to '${stateValue}'"
    state[stateName] = stateValue
}

// for use by parent driver
String getState(String stateName) {
    logDebug "getting state '${stateName}'"
    return state[stateName]
}

/**
 * Get the complete fingerprint data stored in device data
 * @return Map containing fingerprint data or null if not found
 */
Map getFingerprintData() {
    String fingerprintJson = device.getDataValue('fingerprintData')
    if (!fingerprintJson) {
        logDebug "getFingerprintData: fingerprintData not found in device data"
        return null
    }
    
    try {
        return new groovy.json.JsonSlurper().parseText(fingerprintJson)
    } catch (Exception e) {
        logWarn "getFingerprintData: failed to parse fingerprintData: ${e.message}"
        return null
    }
}

/**
 * Get ServerList from fingerprint data
 * @return List of cluster IDs as hex strings (e.g., ["03", "1D", "2F", "0101"])
 */
List<String> getServerList() {
    Map fingerprint = getFingerprintData()
    if (fingerprint == null) {
        logDebug "getServerList: fingerprint data not available"
        return []
    }
    
    return fingerprint['ServerList'] ?: []
}

/**
 * Check if a specific cluster is supported by this device
 * @param clusterHex Cluster ID as hex string (e.g., "0101" for Door Lock)
 * @return true if cluster is in ServerList
 */
boolean isClusterSupported(String clusterHex) {
    List<String> serverList = getServerList()
    return serverList.contains(clusterHex?.toUpperCase())
}

/**
 * Get the Door Lock cluster AttributeList (0x0101_FFFB)
 * @return List of attribute IDs as hex strings (e.g., ["00", "01", "02", ...])
 */
List<String> getDoorLockAttributeList() {
    Map fingerprint = getFingerprintData()
    if (fingerprint == null) {
        logDebug "getDoorLockAttributeList: fingerprint data not available"
        return []
    }
    
    return fingerprint['0101_FFFB'] ?: []
}

/**
 * Check if a specific attribute is supported by the Door Lock cluster
 * @param attrHex Attribute ID as hex string (e.g., "00" for LockState)
 * @return true if attribute is in Door Lock AttributeList
 */
boolean isDoorLockAttributeSupported(String attrHex) {
    List<String> attrList = getDoorLockAttributeList()
    return attrList.contains(attrHex?.toUpperCase())
}

/**
 * Get AcceptedCommandList for Door Lock cluster from fingerprint data
 * @return List of command IDs in hex (e.g., ['00', '01', '02', ...])
 */
List<String> getDoorLockAcceptedCommandList() {
    Map fingerprint = getFingerprintData()
    if (!fingerprint) {
        logDebug "getDoorLockAcceptedCommandList: fingerprint data not available"
        return []
    }
    return fingerprint.get('0101_FFF9') ?: []
}

/**
 * Get GeneratedCommandList for Door Lock cluster from fingerprint data
 * @return List of command IDs in hex (e.g., ['04', '05', ...])
 */
List<String> getDoorLockGeneratedCommandList() {
    Map fingerprint = getFingerprintData()
    if (!fingerprint) {
        logDebug "getDoorLockGeneratedCommandList: fingerprint data not available"
        return []
    }
    return fingerprint.get('0101_FFF8') ?: []
}

/**
 * Check if a specific Door Lock command is supported
 * @param commandHex The command ID in hex (e.g., '00', '01', etc.)
 * @return true if command is in the AcceptedCommandList
 */
Boolean isDoorLockCommandSupported(String commandHex) {
    List<String> cmdList = getDoorLockAcceptedCommandList()
    return cmdList.contains(commandHex?.toUpperCase())
}


// Helper function to process event mask attributes (reduces code duplication)
// Returns the message to be logged (caller handles logging)
String processEventMaskAttribute(String attrId, String attrName, Map descMap, Closure decoder) {
    String rawValue = (descMap.value instanceof List) ? 
        (descMap.value.size() > 0 ? descMap.value[0]?.toString() : '00') : 
        descMap.value?.toString()
    String maskValue = rawValue?.take(4) ?: '00'
    Integer mask = safeParseHex(maskValue)
    String decoded = decoder(mask)
    
    if (rawValue?.length() > 4) { 
        logWarn "${attrName}: value truncated from 0x${rawValue}" 
    }
    
    // Build and return message (prefix will be added by caller)
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${attrId}] " : ""
    return "${prefix}${attrName}: 0x${maskValue} - Enabled: ${decoded}"
}

// Helper function to process numeric attributes (reduces code duplication)
// Returns the message to be logged (caller handles logging)
String processNumericAttribute(String attrName, Map descMap) {
    Integer value = Integer.parseInt(descMap.value, 16)
    
    // Build and return message (prefix will be added by caller)
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${descMap.attrId}] " : ""
    return "${prefix}${attrName}: ${value}"
}

// Custom parsing for description strings with array values
// NOTE: This workaround may not be needed once complex structure parsing is fixed generally
Map patchParseDescriptionMap(String inputString) {
    Map<String, Object> resultMap = [:]
    
    // Remove outer brackets only
    String cleaned = inputString.replaceAll('^\\[', '').replaceAll('\\]$', '')
    
    // Split by ", " but preserve array values
    List<String> parts = []
    int bracketDepth = 0
    StringBuilder current = new StringBuilder()
    
    for (int i = 0; i < cleaned.length(); i++) {
        char c = cleaned.charAt(i)
        if (c == '[') {
            bracketDepth++
            current.append(c)
        } else if (c == ']') {
            bracketDepth--
            current.append(c)
        } else if (c == ',' && bracketDepth == 0 && i + 1 < cleaned.length() && cleaned.charAt(i + 1) == ' ') {
            parts.add(current.toString())
            current = new StringBuilder()
            i++ // skip the space after comma
        } else {
            current.append(c)
        }
    }
    if (current.length() > 0) {
        parts.add(current.toString())
    }
    
    // Now parse each key:value pair
    parts.each { pair ->
        String[] kvParts = pair.split(':', 2)
        if (kvParts.size() == 2) {
            String key = kvParts[0].trim()
            String value = kvParts[1].trim()
            // Check if value is an array
            if (value.startsWith('[') && value.endsWith(']')) {
                // Parse array value
                String arrayContent = value.substring(1, value.length() - 1)
                resultMap[key] = arrayContent.split(',\\s*').collect { it.trim() }
            } else {
                resultMap[key] = value
            }
        }
    }
    
    return resultMap
}


void processUnprocessed(Map description) {
    //logDebug "processing unprocessed: ${description}"

    String inputString = description.value
    logTrace "inputString: ${inputString}"
    
    // Parse the input string to handle array values like value:[09, 1800]
    Map descMap = patchParseDescriptionMap(inputString)
    logDebug "descMap: ${descMap}"
    
    //
    if (descMap.cluster != '0101') { logWarn "processUnprocessed: unexpected cluster:${descMap.cluster} (attrId:${descMap.attrId})"; return }
    
    // Check if this is an event (has evtId) or an attribute (has attrId)
    if (descMap.evtId != null) {
        processDoorLockEvent(description)
        return
    }
    
    String eventValue = descMap.value
    String descriptionText = "${device.displayName} ${descMap.cluster}:${descMap.attrId} value:${eventValue}"
    
    // Declare variables for conditional logging
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${descMap.attrId}] " : ""
    String message = null
    boolean useDebugLog = false  // Flag to use logDebug instead of logInfo when isInfoMode is false
    
    switch (descMap.attrId) {
        case '0000': // LockState
            // LockState is typically handled by parent driver
            // But log it here for debugging if it arrives
            String lockStateText = DoorLockClusterLockState[Integer.parseInt(descMap.value, 16)] ?: "Unknown (${descMap.value})"
            message = "${prefix}LockState: ${lockStateText} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0001': // LockType
            eventValue= DooorLockClusterLockType[Integer.parseInt(descMap.value, 16)]
            descriptionText = "${device.displayName} lockType: ${eventValue} (raw:${descMap.value})"
            sendEvent(name: 'lockType', value: eventValue, descriptionText: descriptionText)
            message = "${prefix}lockType: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0002': // ActuatorEnabled
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            descriptionText = "${device.displayName} ActuatorEnabled: ${eventValue} (raw:${descMap.value})"
            sendEvent(name: 'actuatorEnabled', value: eventValue, descriptionText: descriptionText)
            message = "${prefix}ActuatorEnabled: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0003': // DoorState
            Integer doorStateValue = Integer.parseInt(descMap.value, 16)
            eventValue = DoorLockClusterDoorState[doorStateValue] ?: "Unknown/OutOfSpec"
            if (doorStateValue > 0x05) {
                message = "${prefix}DoorState: ${eventValue} (raw:0x${descMap.value} - value out of spec 0x00-0x05)"
            } else {
                descriptionText = "${device.displayName} DoorState: ${eventValue} (raw:${descMap.value})"
                //sendEvent(name: 'doorState', value: eventValue, descriptionText: descriptionText)
                message = "${prefix}DoorState: ${eventValue} (raw:${descMap.value})"
            }
            useDebugLog = true
            break
        case '0004': // DoorOpenEvents
            Integer doorOpenEvents = safeParseHex(descMap.value)
            message = "${prefix}DoorOpenEvents: ${doorOpenEvents}"
            break
        case '0005': // DoorClosedEvents
            Integer doorClosedEvents = safeParseHex(descMap.value)
            message = "${prefix}DoorClosedEvents: ${doorClosedEvents}"
            break
        case '0006': // OpenPeriod
            Integer openPeriod = Integer.parseInt(descMap.value, 16)
            message = "${prefix}OpenPeriod: ${openPeriod} minutes"
            break
        case '0010': // NumberOfLogRecordsSupported
            message = processNumericAttribute('NumberOfLogRecordsSupported', descMap)
            break
        case '0011': // NumberOfTotalUsersSupported
            message = processNumericAttribute('NumberOfTotalUsersSupported', descMap)
            break
        case '0012': // NumberOfPINUsersSupported
            message = processNumericAttribute('NumberOfPINUsersSupported', descMap)
            break
        case '0013': // NumberOfRFIDUsersSupported
            message = processNumericAttribute('NumberOfRFIDUsersSupported', descMap)
            break
        case '0014': // NumberOfWeekDaySchedulesSupportedPerUser
            message = processNumericAttribute('NumberOfWeekDaySchedulesSupportedPerUser', descMap)
            break
        case '0015': // NumberOfYearDaySchedulesSupportedPerUser
            message = processNumericAttribute('NumberOfYearDaySchedulesSupportedPerUser', descMap)
            break
        case '0016': // NumberOfHolidaySchedulesSupported
            message = processNumericAttribute('NumberOfHolidaySchedulesSupported', descMap)
            break
        case '0017': // MaxPINCodeLength
            Integer maxPinLength = Integer.parseInt(descMap.value, 16)
            descriptionText = "${device.displayName} maximum PIN code length is ${maxPinLength}"
            sendEvent(name: 'codeLength', value: maxPinLength, type: 'physical', descriptionText: descriptionText)
            message = "${prefix}MaxPINCodeLength: ${maxPinLength}"
            break
        case '0018': // MinPINCodeLength
            Integer minPinLength = Integer.parseInt(descMap.value, 16)
            message = "${prefix}MinPINCodeLength: ${minPinLength}"
            break
        case '0019': // MaxRFIDCodeLength
            message = processNumericAttribute('MaxRFIDCodeLength', descMap)
            break
        case '001A': // MinRFIDCodeLength
            message = processNumericAttribute('MinRFIDCodeLength', descMap)
            break
        case '001B': // CredentialRulesSupport
            Integer credRules = Integer.parseInt(descMap.value, 16)
            String credRulesText = decodeCredentialRules(credRules)
            message = "${prefix}CredentialRulesSupport: ${credRulesText} (0x${descMap.value})"
            break
        case '001C': // NumberOfCredentialsSupportedPerUser
            message = processNumericAttribute('NumberOfCredentialsSupportedPerUser', descMap)
            break
        case '0020': // EnableLogging
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableLogging: ${eventValue} (raw:${descMap.value})"
            break
        case '0021': // Language
            String language = descMap.value instanceof List ? descMap.value.join('') : descMap.value
            message = "${prefix}Language: ${language}"
            break
        case '0022': // LEDSettings
            Integer ledSettings = Integer.parseInt(descMap.value, 16)
            message = "${prefix}LEDSettings: 0x${descMap.value}"
            break
        case '0023': // AutoRelockTime
            Integer autoRelockTime = safeParseHex(descMap.value)
            message = "${prefix}AutoRelockTime: ${autoRelockTime} seconds"
            break
        case '0024': // SoundVolume
            Integer soundVolume = Integer.parseInt(descMap.value, 16)
            message = "${prefix}SoundVolume: ${soundVolume}"
            break
        case '0025' : // OperatingMode
            // OperatingMode: 00 (raw:00)
            eventValue = DoorLockClusterOperatingModeEnum[Integer.parseInt(descMap.value, 16)]
            descriptionText = "${device.displayName} OperatingMode: ${eventValue} (raw:${descMap.value})"
            sendEvent(name: 'operatingMode', value: eventValue, descriptionText: descriptionText)
            message = "${prefix}OperatingMode: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0026' : // SupportedOperatingModes
            // SupportedOperatingModes: FFF6 (raw:FFF6)
            Integer intValue = Integer.parseInt(descMap.value, 16)
            List<String> supportedModes = []
            // Iterate through each bit position and check if the corresponding bit in eventValue is set to 0
            DoorLockClusterSupportedOperatingModes.each { bitPosition, modeName ->
                if ((intValue & (1 << bitPosition)) == 0) {
                    supportedModes.add(modeName)
                }
            }
            String supportedModesString = supportedModes.join(', ')
            descriptionText = "${device.displayName} SupportedOperatingModes: ${supportedModesString} (raw:${descMap.value})"
            sendEvent(name: 'supportedOperatingModes', value: supportedModesString, descriptionText: descriptionText)
            message = "${prefix}SupportedOperatingModes: ${supportedModesString} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0027': // DefaultConfigurationRegister
            message = "${prefix}DefaultConfigurationRegister: 0x${descMap.value}"
            break
        case '0028': // EnableLocalProgramming
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableLocalProgramming: ${eventValue} (raw:${descMap.value})"
            break
        case '0029': // EnableOneTouchLocking
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableOneTouchLocking: ${eventValue} (raw:${descMap.value})"
            break
        case '002A': // EnableInsideStatusLED
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableInsideStatusLED: ${eventValue} (raw:${descMap.value})"
            break
        case '002B': // EnablePrivacyModeButton
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnablePrivacyModeButton: ${eventValue} (raw:${descMap.value})"
            break
        case '002C': // LocalProgrammingFeatures
            message = "${prefix}LocalProgrammingFeatures: 0x${descMap.value}"
            break
        case '0030': // WrongCodeEntryLimit
            Integer wrongCodeLimit = Integer.parseInt(descMap.value, 16)
            message = "${prefix}WrongCodeEntryLimit: ${wrongCodeLimit}"
            break
        case '0031': // UserCodeTemporaryDisableTime
            Integer disableTime = Integer.parseInt(descMap.value, 16)
            message = "${prefix}UserCodeTemporaryDisableTime: ${disableTime} seconds"
            break
        case '0032': // SendPINOverTheAir
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}SendPINOverTheAir: ${eventValue} (raw:${descMap.value})"
            break
        case '0033': // RequirePINforRemoteOperation
            eventValue = descMap.value == '01' ? 'required' : 'not required'
            message = "${prefix}RequirePINforRemoteOperation: ${eventValue} (raw:${descMap.value})"
            break
        case '0034': // SecurityLevel (Deprecated)
            Integer securityLevel = Integer.parseInt(descMap.value, 16)
            String securityLevelName = ['Unspecified', 'Low', 'Medium', 'High'][securityLevel] ?: "Unknown(${securityLevel})"
            message = "${prefix}SecurityLevel: ${securityLevelName} (deprecated, raw:${descMap.value})"
            break
        case '0035': // ExpiringUserTimeout
            Integer expiringUserTimeout = Integer.parseInt(descMap.value, 16)
            message = "${prefix}ExpiringUserTimeout: ${expiringUserTimeout} minutes"
            break
        case '0040': // AlarmMask
            message = processEventMaskAttribute('0040', 'AlarmMask', descMap, this.&decodeAlarmMask)
            useDebugLog = true
            break
        case '0041': // KeypadOperationEventMask
            message = processEventMaskAttribute('0041', 'KeypadOperationEventMask', descMap, this.&decodeKeypadOperationEventMask)
            useDebugLog = true
            break
        case '0042': // RemoteOperationEventMask
            message = processEventMaskAttribute('0042', 'RemoteOperationEventMask', descMap, this.&decodeRemoteOperationEventMask)
            useDebugLog = true
            break
        case '0043': // ManualOperationEventMask
            message = processEventMaskAttribute('0043', 'ManualOperationEventMask', descMap, this.&decodeManualOperationEventMask)
            useDebugLog = true
            break
        case '0044': // RFIDOperationEventMask
            message = processEventMaskAttribute('0044', 'RFIDOperationEventMask', descMap, this.&decodeRFIDOperationEventMask)
            useDebugLog = true
            break
        case '0045': // KeypadProgrammingEventMask
            message = processEventMaskAttribute('0045', 'KeypadProgrammingEventMask', descMap, this.&decodeKeypadProgrammingEventMask)
            // NOTE: Nuki disables PINCleared (0x08) and PINChanged (0x10) events
            // This means PIN deletion/modification events won't be received automatically
            useDebugLog = true
            break
        case '0046': // RemoteProgrammingEventMask
            message = processEventMaskAttribute('0046', 'RemoteProgrammingEventMask', descMap, this.&decodeRemoteProgrammingEventMask)
            useDebugLog = true
            break
        case '0047': // RFIDProgrammingEventMask
            message = processEventMaskAttribute('0047', 'RFIDProgrammingEventMask', descMap, this.&decodeRFIDProgrammingEventMask)
            useDebugLog = true
            break
        case '0080': // Nuki non-standard attribute (spec=0x40 AlarmMask)
        case '0081': // Nuki non-standard attribute (spec=0x41 KeypadOperationEventMask)
        case '0082': // Nuki non-standard attribute (spec=0x42 RemoteOperationEventMask)
        case '0083': // Nuki non-standard attribute (spec=0x43 ManualOperationEventMask)
        case '0087': // Nuki non-standard attribute (spec=0x44 RFIDOperationEventMask)
        case '0088': // Nuki non-standard attribute (spec=0x45 KeypadProgrammingEventMask)
            message = "${prefix} UNKNOWN Nuki non-standard attribute 0x${descMap.attrId}: ${descMap.value}"
            break
        case 'FFFC': // FeatureMap
            Integer featureMap = Integer.parseInt(descMap.value, 16)
            String featuresText = decodeFeatureMap(featureMap)
            // FeatureMapRaw is stored in fingerprintData as '0101_FFFC'
            message = "${prefix}FeatureMap: ${featuresText} (0x${descMap.value})"
            break
        case 'FFFB': // AttributeList
            // AttributeList is stored in fingerprintData, no need to store separately
            message = "${prefix}AttributeList: ${descMap.value}"
            useDebugLog = true
            // device.updateDataValue('AttributeList', ...) - removed, now in fingerprintData
            break
        case 'FFFD': // ClusterRevision
            Integer revision = Integer.parseInt(descMap.value, 16)
            message = "${prefix}ClusterRevision: ${revision}"
            break
        case 'FFF8': // GeneratedCommandList (events supported) - stored in fingerprintData only
            message = "${prefix}GeneratedCommandList: ${descMap.value}"
            useDebugLog = true
            // Data is in fingerprintData['0101_FFF8'], no duplicate storage needed
            break
        case 'FFF9': // AcceptedCommandList - stored in fingerprintData only
            message = "${prefix}AcceptedCommandList: ${descMap.value}"
            useDebugLog = true
            // Data is in fingerprintData['0101_FFF9'], no duplicate storage needed
            break
        default:
            // Check for command responses
            if (descMap.cmdId == '25' || descMap.value?.contains('credentialExists')) {
                processGetCredentialStatusResponse(descMap)
            } else if (descMap.cmdId == '28' || descMap.value?.contains('userName')) {
                processGetUserResponse(descMap)
            } else {
                logWarn "processUnprocessed: unexpected attrId:${descMap.attrId}"
            }
    }
    
    // Conditional logging after the switch
    if (message != null) {
        if (isInfoMode) {
            logInfo message
        } else {
            if (useDebugLog) {
                logDebug message
            } else {
                logInfo message
            }
        }
    }
}

void processGetCredentialStatusResponse(Map descMap) {
    logDebug "processGetCredentialStatusResponse: descMap=${descMap}"
    
    // Response fields: credentialExists, userIndex, creatorFabricIndex, lastModifiedFabricIndex, nextCredentialIndex
    // For now, just log the raw response to see the format
    logInfo "GetCredentialStatus Response: ${descMap}"
    
    // TODO: Parse TLV response structure once we see the actual format
    // Expected structure: {credentialExists: bool, userIndex: uint16, ...}
}

void processGetUserResponse(Map descMap) {
    logDebug "processGetUserResponse: descMap=${descMap}"
    
    // Response fields: userIndex, userName, userUniqueID, userStatus, userType, credentialRule, credentials, creatorFabricIndex, lastModifiedFabricIndex
    // For now, just log the raw response to see the format
    logInfo "GetUser Response: ${descMap}"
    
    // TODO: Parse TLV response structure once we see the actual format
    // Expected structure: {userIndex: uint16, userName: string, userStatus: enum8, userType: enum8, ...}
}

void processDoorLockEvent(Map description) {
    // Parse the event data from the description value
    String inputString = description.value
    
    // Extract evtId directly using regex
    def evtIdMatch = inputString =~ /evtId:(\w+)/
    if (!evtIdMatch) {
        logWarn "processDoorLockEvent: could not find evtId in ${inputString}"
        return
    }
    String evtId = evtIdMatch[0][1]
    logDebug "processDoorLockEvent: evtId=${evtId}"
    
    switch (evtId) {
        case '0000': // DoorLockAlarm (0x00)
            processDoorLockAlarmEvent(description)
            break
        case '0001': // DoorStateChange (0x01)
            processDoorStateChangeEvent(description)
            break
        case '0002': // LockOperation (0x02)
            processLockOperationEvent(description)
            break
        case '0003': // LockOperationError (0x03)
            processLockOperationErrorEvent(description)
            break
        case '0004': // LockUserChange (0x04)
            processLockUserChangeEvent(description)
            break
        default:
            logWarn "processDoorLockEvent: unknown evtId=${evtId}"
    }
}

void processDoorLockAlarmEvent(Map description) {
    // Event fields: alarmCode
    Map values = parseEventValues(description)
    Integer alarmCode = values[0]?.value ? Integer.parseInt(values[0].value, 16) : null
    
    String alarmText = DoorLockClusterAlarmCode[alarmCode] ?: "Unknown (${alarmCode})"
    String descriptionText = "${device.displayName} ALARM: ${alarmText}"
    
    logWarn "${descriptionText}"
    sendEvent(name: 'lockAlarm', value: alarmText, descriptionText: descriptionText, isStateChange: true)
}

void processDoorStateChangeEvent(Map description) {
    // Event fields: doorState
    Map values = parseEventValues(description)
    Integer doorState = values[0]?.value ? Integer.parseInt(values[0].value, 16) : null
    
    String doorStateText = DoorLockClusterDoorState[doorState] ?: "Unknown (${doorState})"
    String descriptionText = "${device.displayName} door is ${doorStateText}"
    
    logInfo "${descriptionText}"
    sendEvent(name: 'doorState', value: doorStateText, descriptionText: descriptionText)
}

void processLockOperationEvent(Map description) {
    // Event fields: lockOperationType, operationSource, userIndex, fabricIndex, sourceNode, credentials
    Map values = parseEventValues(description)
    
    Integer lockOpType = values[0]?.value ? Integer.parseInt(values[0].value, 16) : null
    Integer opSource = values[1]?.value ? Integer.parseInt(values[1].value, 16) : null
    Integer userIndex = values[2]?.value != 'null' ? Integer.parseInt(values[2].value, 16) : null
    
    String operation = DoorLockClusterLockOperationType[lockOpType] ?: "Unknown (${lockOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"
    
    String descriptionText = "${operation} by ${source}"
    if (userIndex != null) {
        descriptionText += " (User ${userIndex})"
    }
    
    logDebug "${descriptionText}"
    sendEvent(name: 'lastLockOperation', value: operation, descriptionText: descriptionText, isStateChange: true)
    sendEvent(name: 'lastOperationSource', value: source, descriptionText: descriptionText, isStateChange: true)
}

void processLockOperationErrorEvent(Map description) {
    // Event fields: lockOperationType, operationSource, operationError, userIndex, fabricIndex, sourceNode, credentials
    logDebug "processLockOperationErrorEvent: description=${description}"
    Map values = parseEventValues(description)
    logDebug "processLockOperationErrorEvent: parsed values=${values}"
    
    Integer lockOpType = values[0]?.value ? Integer.parseInt(values[0].value, 16) : null
    Integer opSource = values[1]?.value ? Integer.parseInt(values[1].value, 16) : null
    Integer opError = values[2]?.value ? Integer.parseInt(values[2].value, 16) : null
    Integer userIndex = values[3]?.value != 'null' ? Integer.parseInt(values[3].value, 16) : null
    
    String operation = DoorLockClusterLockOperationType[lockOpType] ?: "Unknown (${lockOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"
    String error = DoorLockClusterOperationError[opError] ?: "Unknown (${opError})"
    
    String descriptionText = "${device.displayName} ${operation} FAILED: ${error} (source: ${source}"
    if (userIndex != null) {
        descriptionText += ", User ${userIndex}"
    }
    descriptionText += ")"
    
    logWarn "*** ${descriptionText} ***"
    sendEvent(name: 'lastLockOperationError', value: error, descriptionText: descriptionText, isStateChange: true)
}

void processLockUserChangeEvent(Map description) {
    // Event fields: lockDataType, dataOperationType, operationSource, userIndex, fabricIndex, sourceNode, dataIndex
    //  [endpoint:01, cluster:0101, evtId:0004, timestamp:DC6D037279, priority:01, clusterInt:257, evtInt:4, 
    //         values:[0:[type:04, isContextSpecific:true, value:02], 
    //                 1:[type:04, isContextSpecific:true, value:01], 
    //                 2:[type:04, isContextSpecific:true, value:07], 
    //                 3:[type:04, isContextSpecific:true, value:0A], 
    //                 4:[type:04, isContextSpecific:true, value:03], 
    //                 5:[type:06, isContextSpecific:true, value:0001B669], 
    //                 6:[type:04, isContextSpecific:true, value:0A]]]
    Map values = parseEventValues(description)
    
    Integer lockDataType = values[0]?.value ? Integer.parseInt(values[0].value, 16) : null
    Integer dataOpType = values[1]?.value ? Integer.parseInt(values[1].value, 16) : null
    Integer opSource = values[2]?.value ? Integer.parseInt(values[2].value, 16) : null
    Integer userIndex = values[3]?.value != 'null' ? Integer.parseInt(values[3].value, 16) : null
    
    String dataType = DoorLockClusterLockDataType[lockDataType] ?: "Unknown (${lockDataType})"
    String operation = DoorLockClusterDataOperationType[dataOpType] ?: "Unknown (${dataOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"
    
    String descriptionText = "${device.displayName} ${dataType} ${operation}"
    if (userIndex != null) {
        descriptionText += " for User ${userIndex}"
    }
    descriptionText += " (source: ${source})"
    
    logInfo "${descriptionText}"
    sendEvent(name: 'lastUserChange', value: "${operation} ${dataType}", descriptionText: descriptionText, isStateChange: true)
}

Map parseEventValues(Map description) {
    // Extract the values from the description.value string
    // Format: values:[0:[type:04, isContextSpecific:true, value:00], 1:[type:04, value:07], ...]
    String valueString = description.value
    
    // Find the start of the values section
    int valuesStart = valueString.indexOf('values:[')
    if (valuesStart == -1) {
        logWarn "parseEventValues: could not find 'values:[' in ${valueString}"
        return [:]
    }
    
    // Extract everything after 'values:[' - we'll parse the indexed values directly
    String valuesSection = valueString.substring(valuesStart + 7) // Skip 'values:'
    logDebug "parseEventValues: parsing from: ${valuesSection.take(200)}..."
    
    // Parse each indexed value: 0:[...], 1:[...], etc.
    Map values = [:]
    try {
        // Match patterns like: 0:[type:04, isContextSpecific:true, value:00]
        // Using non-greedy match for the content between brackets
        def indexMatch = valuesSection =~ /(\d+):\[([^\]]+)\]/
        indexMatch.each { match ->
            Integer index = match[1] as Integer
            String content = match[2]
            
            // Extract the value field from content
            def valueMatch = content =~ /value:([\w]+|null)/
            if (valueMatch) {
                String value = valueMatch[0][1]
                values[index] = [value: value]
            }
        }
    } catch (Exception e) {
        logWarn "parseEventValues error: ${e.message}"
    }
    
    logDebug "parseEventValues result: ${values}"
    return values
}

void getInfo() {
    // Check if Door Lock cluster is supported
    if (!isClusterSupported('0101')) {
        logWarn "getInfo: Door Lock cluster (0x0101) is not supported by this device"
        logInfo "getInfo: ServerList contains: ${getServerList()}"
        return
    }
    logInfo "getInfo: reading all supported Door Lock attributes: ${getDoorLockAttributeList()}"
    
    // Set state flags for info mode
    if (state.states == null) { state.states = [:] }
    if (state.lastTx == null) { state.lastTx = [:] }
    state.states.isInfo = true
    state.lastTx.infoTime = now()
    
    // Schedule job to turn off info mode after 10 seconds
    runIn(10, 'clearInfoMode')
    
    String endpointHex = device.getDataValue('id') ?: '1'
    Integer endpoint = HexUtils.hexStringToInt(endpointHex)
    parent?.readAttribute(endpoint, 0x0101, -1)      // 0x00 Door Lock cluster - read all attributes
    // battery info is processed in parent driver !
    // parent?.readAttribute(endpoint, 0x002F, -1)       // 0x002F Power Source cluster - read all attributes
}

// Clear info mode flag (called by scheduled job)
void clearInfoMode() {
    if (state.states == null) { state.states = [:] }
    state.states.isInfo = false
    logDebug "clearInfoMode: info mode disabled"
}

// ============ Matter Door Lock Cluster Attributes Map ============
// Complete list of all Door Lock cluster (0x0101) attributes per Matter spec
@Field static final Map<Integer, String> DoorLockClusterAttributes = [
    // Mandatory and common attributes
    0x0000  : 'LockState',                                          // LockStateEnum, R V, M
    0x0001  : 'LockType',                                           // LockTypeEnum, R V, M
    0x0002  : 'ActuatorEnabled',                                    // bool, R V, M
    0x0003  : 'DoorState',                                          // DoorStateEnum, R V, DPS
    0x0004  : 'DoorOpenEvents',                                     // uint32, RW, DPS
    0x0005  : 'DoorClosedEvents',                                   // uint32, RW, DPS
    0x0006  : 'OpenPeriod',                                         // uint16, RW, DPS
    
    // User and credential management
    0x0010  : 'NumberOfLogRecordsSupported',                        // uint16, R V, O
    0x0011  : 'NumberOfTotalUsersSupported',                        // uint16, R V, USR
    0x0012  : 'NumberOfPINUsersSupported',                          // uint16, R V, PIN
    0x0013  : 'NumberOfRFIDUsersSupported',                         // uint16, R V, RID
    0x0014  : 'NumberOfWeekDaySchedulesSupportedPerUser',           // uint8, R V, WDSCH
    0x0015  : 'NumberOfYearDaySchedulesSupportedPerUser',           // uint8, R V, YDSCH
    0x0016  : 'NumberOfHolidaySchedulesSupported',                  // uint8, R V, HDSCH
    0x0017  : 'MaxPINCodeLength',                                   // uint8, R V, PIN
    0x0018  : 'MinPINCodeLength',                                   // uint8, R V, PIN
    0x0019  : 'MaxRFIDCodeLength',                                  // uint8, R V, RID
    0x001A  : 'MinRFIDCodeLength',                                  // uint8, R V, RID
    0x001B  : 'CredentialRulesSupport',                             // DlCredentialRuleMask, R V, USR
    0x001C  : 'NumberOfCredentialsSupportedPerUser',                // uint8, R V, USR
    
    // Lock configuration attributes
    0x0020  : 'EnableLogging',                                      // bool, RW, O
    0x0021  : 'Language',                                           // string, RW, O
    0x0022  : 'LEDSettings',                                        // uint8, RW, O
    0x0023  : 'AutoRelockTime',                                     // uint32, RW, O
    0x0024  : 'SoundVolume',                                        // uint8, RW, O
    0x0025  : 'OperatingMode',                                      // OperatingModeEnum, RW, M
    0x0026  : 'SupportedOperatingModes',                            // DlSupportedOperatingModes, R V, M
    0x0027  : 'DefaultConfigurationRegister',                       // DlDefaultConfigurationRegister, R V, O
    0x0028  : 'EnableLocalProgramming',                             // bool, RW, O
    0x0029  : 'EnableOneTouchLocking',                              // bool, RW, O
    0x002A  : 'EnableInsideStatusLED',                              // bool, RW, O
    0x002B  : 'EnablePrivacyModeButton',                            // bool, RW, O
    0x002C  : 'LocalProgrammingFeatures',                           // DlLocalProgrammingFeatures, RW, O
    
    // Security and access control
    0x0030  : 'WrongCodeEntryLimit',                                // uint8, RW, O
    0x0031  : 'UserCodeTemporaryDisableTime',                       // uint8, RW, O
    0x0032  : 'SendPINOverTheAir',                                  // bool, RW, O
    0x0033  : 'RequirePINforRemoteOperation',                       // bool, RW, O
    0x0034  : 'SecurityLevel',                                      // SecurityLevelEnum, RW, O (Deprecated)
    0x0035  : 'ExpiringUserTimeout',                                // uint16, RW, O
    
    // Event masks (Notification feature)
    0x0040  : 'AlarmMask',                                          // DlAlarmMask, RW, NOT
    0x0041  : 'KeypadOperationEventMask',                           // DlKeypadOperationEventMask, RW, NOT
    0x0042  : 'RemoteOperationEventMask',                           // DlRemoteOperationEventMask, RW, NOT
    0x0043  : 'ManualOperationEventMask',                           // DlManualOperationEventMask, RW, NOT
    0x0044  : 'RFIDOperationEventMask',                             // DlRFIDOperationEventMask, RW, NOT
    0x0045  : 'KeypadProgrammingEventMask',                         // DlKeypadProgrammingEventMask, RW, NOT
    0x0046  : 'RemoteProgrammingEventMask',                         // DlRemoteProgrammingEventMask, RW, NOT
    0x0047  : 'RFIDProgrammingEventMask',                           // DlRFIDProgrammingEventMask, RW, NOT
    
    // Standard cluster attributes
    0xFFFB  : 'AttributeList',                                      // list, R V, M
    0xFFFC  : 'FeatureMap',                                         // FeatureMap, R V, M
    0xFFFD  : 'ClusterRevision'                                     // uint16, R V, M
]

// 5.2.6.2. LockState Attribute (0x0000)
@Field static final Map<Integer, String> DoorLockClusterLockState = [
    0x00    : 'NotFullyLocked',
    0x01    : 'Locked',
    0x02    : 'Unlocked',
    0x03    : 'Unlatched'   // optional
]

// 5.2.6.3. LockType Attribute (0x0001)
@Field static final Map<String, String> DooorLockClusterLockType = [
    0x00    : 'deadbolt',   // Physical lock type is dead bolt
    0x01    : 'magnetic',   // Physical lock type is magnetic
    0x02    : 'other',      // Physical lock type is other
    0x03    : 'mortise',    // Physical lock type is mortise
    0x04    : 'rim',        // Physical lock type is rim
    0x05    : 'latchbolt',  // Physical lock type is latch bolt
    0x06    : 'cylindricalLock',// Physical lock type is cylindrical lock
    0x07    : 'tubularLock',    // Physical lock type is tubular lock
    0x08    : 'interconnectedLock', // Physical lock type is interconnected lock
    0x09    : 'deadLatch',  // Physical lock type is dead latch
    0x0A    : 'doorFurniture', // Physical lock type is door furniture
    0x0B    : 'eurocylinder'   // Physical lock type is eurocylinder
]

/*
The ActuatorEnabled attribute indicates if the lock is currently able to (Enabled) or not able to (Disabled)
process remote Lock, Unlock, or Unlock with Timeout commands.
This attribute has the following possible values:
Boolean Value Summary
0 Disabled
1 Enabled
*/

@Field static final Map<Integer, String> DoorLockClusterSupportedOperatingModes = [
    0x00    : 'Normal',             // (mandatory)
    0x01    : 'Vacation',
    0x02    : 'Privacy',
    0x03    : 'NoRemoteLockUnlock', // (mandatory)
    0x04    : 'Passage'
]

@Field static final Map<Integer, String> DoorLockClusterOperatingModeEnum = [
    0x00    : 'Normal',
    0x01    : 'Vacation',
    0x02    : 'Privacy',
    0x03    : 'NoRemoteLockUnlock',
    0x04    : 'Passage'
]

// Door Lock Event Enums
@Field static final Map<Integer, String> DoorLockClusterAlarmCode = [
    0x00    : 'LockJammed',
    0x01    : 'LockFactoryReset',
    0x03    : 'LockRadioPowerCycled',
    0x04    : 'WrongCodeEntryLimit',
    0x05    : 'FrontEsceutcheonRemoved',
    0x06    : 'DoorForcedOpen',
    0x07    : 'DoorAjar',
    0x08    : 'ForcedUser'
]

@Field static final Map<Integer, String> DoorLockClusterDoorState = [
    0x00    : 'Open',
    0x01    : 'Closed',
    0x02    : 'Jammed',
    0x03    : 'ForcedOpen',
    0x04    : 'UnspecifiedError',
    0x05    : 'Ajar'
]

@Field static final Map<Integer, String> DoorLockClusterLockOperationType = [
    0x00    : 'Lock',
    0x01    : 'Unlock',
    0x02    : 'NonAccessUserEvent',
    0x03    : 'ForcedUserEvent',
    0x04    : 'Unlatch'
]

@Field static final Map<Integer, String> DoorLockClusterOperationSource = [
    0x00    : 'Unspecified',
    0x01    : 'Manual',
    0x02    : 'ProprietaryRemote',
    0x03    : 'Keypad',
    0x04    : 'Auto',
    0x05    : 'Button',
    0x06    : 'Schedule',
    0x07    : 'Remote',
    0x08    : 'RFID',
    0x09    : 'Biometric'
]

@Field static final Map<Integer, String> DoorLockClusterOperationError = [
    0x00    : 'Unspecified',
    0x01    : 'InvalidCredential',
    0x02    : 'DisabledUserDenied',
    0x03    : 'Restricted',
    0x04    : 'InsufficientBattery'
]

@Field static final Map<Integer, String> DoorLockClusterLockDataType = [
    0x00    : 'Unspecified',
    0x01    : 'ProgrammingCode',
    0x02    : 'UserIndex',
    0x03    : 'WeekDaySchedule',
    0x04    : 'YearDaySchedule',
    0x05    : 'HolidaySchedule',
    0x06    : 'PIN',
    0x07    : 'RFID',
    0x08    : 'Fingerprint',
    0x09    : 'FingerVein',
    0x0A    : 'Face'
]

@Field static final Map<Integer, String> DoorLockClusterDataOperationType = [
    0x00    : 'Add',
    0x01    : 'Clear',
    0x02    : 'Modify'
]

// Helper method to safely parse hex string to Integer
Integer safeParseHex(String hexValue) {
    try {
        return Integer.parseInt(hexValue, 16)
    } catch (NumberFormatException e) {
        logWarn "safeParseHex: failed to parse '${hexValue}', returning 0"
        return 0
    }
}

// Helper method to decode CredentialRulesSupport bitmap
String decodeCredentialRules(Integer rules) {
    List<String> supported = []
    if (rules & 0x01) { supported.add('Single') }
    if (rules & 0x02) { supported.add('Dual') }
    if (rules & 0x04) { supported.add('Triple') }
    return supported.isEmpty() ? 'None' : supported.join(', ')
}

// Helper method to decode FeatureMap bitmap
// Official Matter Door Lock Cluster 1.3 FeatureMap
// Bit 0 (0x0001): PIN Credential support
// Bit 1 (0x0002): RFID Credential support
// Bit 2 (0x0004): Fingerprint Credential support
// Bit 3 (0x0008): Logging support
// Bit 4 (0x0010): Week Day Access Schedules support
// Bit 5 (0x0020): Door Position Sensor support
// Bit 6 (0x0040): Face Credential support
// Bit 7 (0x0080): Credential Over The Air (COTA) support
// Bit 8 (0x0100): User Management support
// Bit 9 (0x0200): Notification support
// Bit 10 (0x0400): Year Day Access Schedules support
// Bit 11 (0x0800): Holiday Schedules support
// Bit 12 (0x1000): Unbolt support
String decodeFeatureMap(Integer featureMap) {
    if (featureMap == 0) { return 'None (Mandatory features only)' }
    List<String> features = []
    
    if (featureMap & 0x0001) { features.add('PIN') }                     // Bit 0
    if (featureMap & 0x0002) { features.add('RFID') }                    // Bit 1
    if (featureMap & 0x0004) { features.add('Fingerprint') }             // Bit 2
    if (featureMap & 0x0008) { features.add('Logging') }                 // Bit 3
    if (featureMap & 0x0010) { features.add('WeekDaySchedules') }        // Bit 4
    if (featureMap & 0x0020) { features.add('DoorPositionSensor') }      // Bit 5
    if (featureMap & 0x0040) { features.add('FaceCredential') }          // Bit 6
    if (featureMap & 0x0080) { features.add('COTA') }                    // Bit 7
    if (featureMap & 0x0100) { features.add('UserManagement') }          // Bit 8
    if (featureMap & 0x0200) { features.add('Notification') }            // Bit 9
    if (featureMap & 0x0400) { features.add('YearDaySchedules') }        // Bit 10
    if (featureMap & 0x0800) { features.add('HolidaySchedules') }        // Bit 11
    if (featureMap & 0x1000) { features.add('Unbolt') }                  // Bit 12
    
    return features.join(', ')
}

// Helper method to decode KeypadOperationEventMask bitmap (DlKeypadOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidPIN
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidCode
// Bit 6 (0x40): UnlockInvalidSchedule
// Bit 7 (0x80): NonAccessUserOpEvent
String decodeKeypadOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidPIN') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidCode') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    if (mask & 0x80) { enabled.add('NonAccessUserOpEvent') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode KeypadProgrammingEventMask bitmap (DlKeypadProgrammingEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ProgrammingPINChanged
// Bit 2 (0x04): PINAdded
// Bit 3 (0x08): PINCleared
// Bit 4 (0x10): PINChanged
// Bit 6 (0x40): OUT OF SPEC - possibly Nuki proprietary extension
String decodeKeypadProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ProgrammingPINChanged') }
    if (mask & 0x04) { enabled.add('PINAdded') }
    if (mask & 0x08) { enabled.add('PINCleared') }
    if (mask & 0x10) { enabled.add('PINChanged') }
    if (mask & 0x20) { enabled.add('Reserved(0x20)') }
    if (mask & 0x40) { enabled.add('Unknown/Proprietary(0x40)') }  // Nuki specific?
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode RemoteOperationEventMask bitmap (DlRemoteOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidCode
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidCode
// Bit 6 (0x40): UnlockInvalidSchedule
String decodeRemoteOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidCode') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidCode') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode ManualOperationEventMask bitmap (DlManualOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ThumbturnLock
// Bit 2 (0x04): ThumbturnUnlock
// Bit 3 (0x08): OneTouchLock
// Bit 4 (0x10): KeyLock
// Bit 5 (0x20): KeyUnlock
// Bit 6 (0x40): AutoLock
// Bit 7 (0x80): ScheduleLock
// Bit 8 (0x100): ScheduleUnlock
// Bit 9 (0x200): ManualLock
// Bit 10 (0x400): ManualUnlock
String decodeManualOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ThumbturnLock') }
    if (mask & 0x04) { enabled.add('ThumbturnUnlock') }
    if (mask & 0x08) { enabled.add('OneTouchLock') }
    if (mask & 0x10) { enabled.add('KeyLock') }
    if (mask & 0x20) { enabled.add('KeyUnlock') }
    if (mask & 0x40) { enabled.add('AutoLock') }
    if (mask & 0x80) { enabled.add('ScheduleLock') }
    if (mask & 0x100) { enabled.add('ScheduleUnlock') }
    if (mask & 0x200) { enabled.add('ManualLock') }
    if (mask & 0x400) { enabled.add('ManualUnlock') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode RFIDOperationEventMask bitmap (DlRFIDOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidRFID
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidRFID
// Bit 6 (0x40): UnlockInvalidSchedule
String decodeRFIDOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidRFID') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidRFID') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// AlarmMask (0x0080) decoder
// Bit 0 (0x01): LockJammed
// Bit 1 (0x02): LockFactoryReset
// Bit 2 (0x04): LockRadioPowerCycled
// Bit 3 (0x08): WrongCodeEntryLimit
// Bit 4 (0x10): FrontEscutcheonRemoved
// Bit 5 (0x20): DoorForcedOpen
// Bit 6 (0x40): DoorAjar
// Bit 7 (0x80): ForcedUser
String decodeAlarmMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('LockJammed') }
    if (mask & 0x02) { enabled.add('LockFactoryReset') }
    if (mask & 0x04) { enabled.add('LockRadioPowerCycled') }
    if (mask & 0x08) { enabled.add('WrongCodeEntryLimit') }
    if (mask & 0x10) { enabled.add('FrontEscutcheonRemoved') }
    if (mask & 0x20) { enabled.add('DoorForcedOpen') }
    if (mask & 0x40) { enabled.add('DoorAjar') }
    if (mask & 0x80) { enabled.add('ForcedUser') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// RemoteProgrammingEventMask (0x0046) decoder - per Matter specification
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ProgrammingPINChanged
// Bit 2 (0x04): PINAdded
// Bit 3 (0x08): PINCleared
// Bit 4 (0x10): PINChanged
// Bit 5 (0x20): PINCodeDuplicate
// Bit 6 (0x40): Reserved
// Bit 7 (0x80): Reserved
String decodeRemoteProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ProgrammingPINChanged') }
    if (mask & 0x04) { enabled.add('PINAdded') }
    if (mask & 0x08) { enabled.add('PINCleared') }
    if (mask & 0x10) { enabled.add('PINChanged') }
    if (mask & 0x20) { enabled.add('PINCodeDuplicate') }
    if (mask & 0x40) { enabled.add('Reserved(0x40)') }
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// RFIDProgrammingEventMask (0x0047) decoder - per Matter specification
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): RFIDCodeAdded
// Bit 2 (0x04): RFIDCodeCleared
// Bit 3 (0x08): RFIDCodeDuplicate
// Bit 4 (0x10): RFIDCodeInvalid
// Bit 5 (0x20): RFIDCodeChanged
// Bit 6 (0x40): Reserved
// Bit 7 (0x80): Reserved
String decodeRFIDProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('RFIDCodeAdded') }
    if (mask & 0x04) { enabled.add('RFIDCodeCleared') }
    if (mask & 0x08) { enabled.add('RFIDCodeDuplicate') }
    if (mask & 0x10) { enabled.add('RFIDCodeInvalid') }
    if (mask & 0x20) { enabled.add('RFIDCodeChanged') }
    if (mask & 0x40) { enabled.add('Reserved(0x40)') }
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// ============ Lock Command Helper Methods ============

/**
 * Get the device number (endpoint) from device data
 * @return device number as Integer or null if invalid
 */
private Integer getDeviceNumber() {
    String id = device.getDataValue('id')
    if (!id) {
        logWarn "Device ID not found in data values"
        return null
    }
    
    Integer deviceNumber = HexUtils.hexStringToInt(id)
    if (deviceNumber == null || deviceNumber <= 0 || deviceNumber > 255) {
        logWarn "Invalid device number: ${deviceNumber} (from id: ${id})"
        return null
    }
    
    return deviceNumber
}

/**
 * Convert ASCII PIN string to hex bytes
 * @param s ASCII string (e.g., "123456")
 * @return hex string (e.g., "313233343536")
 */
private static String asciiToHex(final String s) {
    if (s == null) return ''
    byte[] bytes = s.getBytes('US-ASCII')
    return bytes.collect { String.format('%02X', it) }.join()
}

@Field static final String DRIVER = 'Matter Advanced Bridge'
@Field static final String COMPONENT = 'Matter Generic Component Door Lock'
@Field static final String WIKI   = 'Get help on GitHub Wiki page:'
@Field static final String COMM_LINK =   "https://community.hubitat.com/t/release-matter-advanced-bridge-limited-device-support/135252/1"
@Field static final String GITHUB_LINK = "https://github.com/kkossev/Hubitat---Matter-Advanced-Bridge/wiki/Matter-Advanced-Bridge-%E2%80%90-Door-Locks"
// credits @jtp10181
String fmtHelpInfo(String str) {
	String info = "${DRIVER} v${parent?.version()}<br> ${COMPONENT} v${matterComponentLockVersion}"
	String prefLink = "<a href='${GITHUB_LINK}' target='_blank'>${WIKI}<br><div style='font-size: 70%;'>${info}</div></a>"
    String topStyle = "style='font-size: 18px; padding: 1px 12px; border: 2px solid green; border-radius: 6px; color: green;'"
    String topLink = "<a ${topStyle} href='${COMM_LINK}' target='_blank'>${str}<br><div style='font-size: 14px;'>${info}</div></a>"

	return "<div style='font-size: 160%; font-style: bold; padding: 2px 0px; text-align: center;'>${prefLink}</div>" +
		"<div style='text-align: center; position: absolute; top: 46px; right: 60px; padding: 0px;'><ul class='nav'><li>${topLink}</ul></li></div>"
}

// --------- common matter libraries included below --------

#include kkossev.matterHealthStatusLib
