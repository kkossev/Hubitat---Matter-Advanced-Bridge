/* groovylint-disable CompileStatic, DuplicateNumberLiteral, DuplicateStringLiteral, ImplicitClosureParameter, LineLength, MethodSize */
library(
    base: 'driver',
    author: 'Krassimir Kossev',
    category: 'matter',
    description: 'Matter State Machines',
    name: 'matterStateMachinesLib',
    namespace: 'kkossev',
    importUrl: 'https://raw.githubusercontent.com/kkossev/Hubitat---Matter-Advanced-Bridge/development/Libraries/Matter_State_Machines.groovy',
    version: '1.2.1',
    documentationLink: ''
)
/*
  *  Matter State Machines Library
  *
  *  https://community.hubitat.com/t/dynamic-capabilities-commands-and-attributes-for-drivers/98342
  *  https://community.hubitat.com/t/project-zemismart-m1-matter-bridge-for-tuya-zigbee-devices-matter/127009
  *
  *  Licensed Virtual the Apache License, Version 2.0 (the "License"); you may not use this file except
  *  in compliance with the License. You may obtain a copy of the License at:
  *
  *      http://www.apache.org/licenses/LICENSE-2.0
  *
  *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
  *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
  *  for the specific language governing permissions and limitations under the License.
  *
  * ver. 1.0.0  2024-03-16 kkossev  - first release version
  * ver. 1.0.1  2024-07-31 kkossev  - skipped General Diagnostics cluster 0x0033 discovery - Aqara M3 returns error reading attribute 0x0000
  * ver. 1.0.2  2024-09-29 kkossev  - HE platform 2.3.9.186 optimizations
  * ver. 1.0.3  2024-09-29 kkossev  - bugfix: nullpointer exception in discoverAllStateMachine(); secured all . operations with ?.
  * ver. 1.0.4  2026-01-06 GPT-5.2  - added discoveryTimeoutScale
  * ver. 1.0.5  2026-01-08 GPT-5.2  - skip discovery for disabled child devices to eliminate timeouts
  * ver. 1.1.0  2026-01-17 GPT-5.2  - fixed empty attribute list issue in discoverGlobalElementsStateMachine; added fingerprint copy in discoverAllStateMachine; added discovering all FFF8 FFF9 FFFB FFFC attributes in discoverGlobalElementsStateMachine; added finalizeDeviceType() call
  * ver. 1.1.1  2026-01-17 GPT-5.2  - restored DISCOVER_ALL_STATE_BRIDGE_GENERAL_DIAGNOSTICS
  * ver. 1.1.2  2026-02-21 kkossev  - potential bug fix in discovering global elements (including FeatureMap); added 0xFFFA
  * ver. 1.2.0  2026-07-25 kkossev + Claude Opus 5 - (dev. branch) bug fixes; ping the bridge before starting the discovery;
  * ver. 1.2.1  2026-08-13 kkossev + Claude Opus 5 - (dev. branch) bug fix: readAttributeSafe() validated every cluster against the Descriptor's AttributeList, refusing valid attributes of any other cluster;
  *
*/

import groovy.transform.Field

/* groovylint-disable-next-line ImplicitReturnStatement */
@Field static final String matterStateMachinesLib = '1.2.1'
@Field static final String matterStateMachinesLibStamp   = '2026/08/13 6:20 PM'

// no metadata section for matterStateMachinesLib
@Field static final String  START   = 'START'
@Field static final String  STOP    = 'STOP'
//                          UNKNOWN = 'UNKNOWN'
@Field static final String  RUNNING = 'RUNNING'
@Field static final String  SUCCESS = 'SUCCESS'
@Field static final String  ERROR   = 'ERROR'

@Field static final Integer STATE_MACHINE_PERIOD = 330      // milliseconds
@Field static final Integer STATE_MACHINE_MAX_RETRIES = 50

void initializeStateMachineVars() {
    if (state['states'] == null) { state['states'] = [:] }
    if (!(state['stateMachines'] instanceof Map)) { state['stateMachines'] = [:] }
    if (state['stateMachines']['readSingeAttrState'] == null) { state['stateMachines']['readSingeAttrState'] = 0 }
    if (state['stateMachines']['readSingeAttrRetry'] == null) { state['stateMachines']['readSingeAttrRetry'] = 0 }
    if (state['stateMachines']['discoverGlobalElementsState'] == null) { state['stateMachines']['discoverGlobalElementsState'] = STATE_DISCOVER_GLOBAL_ELEMENTS_IDLE }
    if (state['stateMachines']['discoverGlobalElementsRetry'] == null) { state['stateMachines']['discoverGlobalElementsRetry'] = 0 }
    if (state['stateMachines']['discoverGlobalElementsResult'] == null) { state['stateMachines']['discoverGlobalElementsResult'] = UNKNOWN }
    if (state['stateMachines']['discoverAllState'] == null) { state['stateMachines']['discoverAllState'] = DISCOVER_ALL_STATE_IDLE }
    if (state['stateMachines']['discoverAllRetry'] == null) { state['stateMachines']['discoverAllRetry'] = 0 }
    if (state['stateMachines']['discoverAllResult'] == null) { state['stateMachines']['discoverAllResult'] = UNKNOWN }
    if (state['stateMachines']['discoverAllPingAttempt'] == null) { state['stateMachines']['discoverAllPingAttempt'] = 0 }
}

void readSingleAttrStateMachine(Map data = null) {
    initializeStateMachineVars()

    if (data != null) {
        if (data['action'] == START) {
            state['stateMachines']['readSingeAttrState']  = 1
            state['stateMachines']['readSingeAttrRetry']  = 0
            state['stateMachines']['readSingeAttrResult'] = UNKNOWN
            data['action'] = RUNNING
        }
    }
    logTrace "readSingleAttrStateMachine: data:${data}, state['stateMachines'] = ${state['stateMachines']}"

    Integer st =    state['stateMachines']['readSingeAttrState']
    Integer retry = state['stateMachines']['readSingeAttrRetry']
    Integer maxRetries = STATE_MACHINE_MAX_RETRIES * getDiscoveryTimeoutScale()
    String fingerprintName = getFingerprintName(data.endpoint)
    String attributeName = getAttributeName([cluster: HexUtils.integerToHexString(data.cluster, 2), attrId: HexUtils.integerToHexString(data.attribute, 2)])
    logTrace "readSingleAttrStateMachine: st:${st} retry:${retry} data:${data}"
    switch (st) {
        case 0:
            logDebug "readSingleAttrStateMachine: st:${st} - idle"
            unschedule('readSingleAttrStateMachine')
            break
        case 1: // start - first check if the endpoint and the cluster are in the fingerprint
            //logDebug "readSingleAttrStateMachine: st:${st} - checking whether attribute ${data.attribute} is in the fingerprint ${fingerprintName}"
            if (state[fingerprintName] == null) {
                logWarn "readAttributeSafe(): state[${fingerprintName}] is null !"
                logWarn 'run steps A1 and A2 !'
                state['stateMachines']['readSingeAttrResult'] = ERROR
                data['action'] = ERROR
                st = 99
                break
            }
            logTrace "readSingleAttrStateMachine: st:${st} - found fingerprint ${fingerprintName}"
            // check whether the cluster is in the fingerprint ServerList
            List<String> serverList = state[fingerprintName]['ServerList']
            if (serverList == null) {
                logWarn "readAttributeSafe(): state[${fingerprintName}]['ServerList'] is null !"
                logWarn 'run steps A1 and A2 !'
                state['stateMachines']['readSingeAttrResult'] = ERROR
                data['action'] = ERROR
                st = 99
                break
            }
            logTrace "readSingleAttrStateMachine: st:${st} - found serverList ${serverList}"
            // convert the serverList to a list of Integers
            List<Integer> serverListInt = serverList?.collect { HexUtils.hexStringToInt(it) }
            logTrace "readSingleAttrStateMachine: st:${st} - found serverListInt ${serverListInt}"
            // check whether the cluster is in the fingerprint serverListInt
            if (!serverListInt?.contains(data.cluster)) {
                logWarn "readAttributeSafe(): state[${fingerprintName}]['ServerList'] does not contain cluster ${data.cluster} (0x${HexUtils.integerToHexString(data.cluster, 2)}) !"
                logWarn "valid clusters are: ${serverList}"
                state['stateMachines']['readSingeAttrResult'] = ERROR
                data['action'] = ERROR
                st = 99
                break
            }
            // so far, so good, now check whether the attribute is in the attributeList.
            // getStateClusterName() stores the Descriptor (001D) attribute list under the plain key
            // 'AttributeList' and every other cluster under 'NNNN_FFFB' - so the key must be chosen the
            // same way requestMatterClusterAttributesValues() chooses it. Reading the plain key for every
            // cluster validated e.g. 0039:0005 against the Descriptor's own list and refused it.
            String attrListKey = (data.cluster == 0x001D) ? 'AttributeList' : "${HexUtils.integerToHexString(data.cluster, 2)}_FFFB".toString()
            List<String>  attributeList = state[fingerprintName][attrListKey]
            if (attributeList == null) {
                logWarn "readAttributeSafe(): state[${fingerprintName}]['${attrListKey}'] is null !"
                logWarn "run steps A1 and A2 ! (or use 'readAttribute' to read it without validation)"
                state['stateMachines']['readSingeAttrResult'] = ERROR
                data['action'] = ERROR
                st = 99
                break
            }
            logTrace "readSingleAttrStateMachine: st:${st} - found attributeList ${attributeList}"
            // convert the attributeList to a list of Integers
            List<Integer> attributeListInt = attributeList?.collect { HexUtils.hexStringToInt(it) }
            logTrace "readSingleAttrStateMachine: st:${st} - found attributeListInt ${attributeListInt}"
            // check whether the attribute is in the fingerprint attributeListInt
            if (!attributeListInt?.contains(data.attribute)) {
                logWarn "readAttributeSafe(): state[${fingerprintName}]['${attrListKey}'] does not contain attribute ${data.attribute} (0x${HexUtils.integerToHexString(data.attribute, 2)}) !"
                logWarn "valid attributes are: ${attributeList}"
                state['stateMachines']['readSingeAttrResult'] = ERROR
                data['action'] = ERROR
                st = 99
                break
            }
            List<Integer> toBeConfirmedList = [data.endpoint, data.cluster, data.attribute]
            state['stateMachines']['toBeConfirmed'] = toBeConfirmedList
            state['stateMachines']['Confirmation'] = false
            List<Map<String, String>> attributePaths = [matter.attributePath(data.endpoint, data.cluster, data.attribute)]
            sendToDevice(matter.readAttributes(attributePaths))
            st = 2; retry = 0
            break
        case 2: // waiting for the attribute value
            if (state['stateMachines']['Confirmation'] == true) {
                logTrace "readSingleAttrStateMachine: st:${st} - received ${attributeName} reading confirmation!"
                state['stateMachines']['readSingeAttrResult'] = SUCCESS
                st = 99
            }
            else {
                logTrace "readSingleAttrStateMachine: st:${st} - waiting for the attribute value (retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    logWarn "readSingleAttrStateMachine: st:${st} - timeout waiting for the attribute value (retry=${retry})!"
                    state['stateMachines']['readSingeAttrResult'] = ERROR
                    st = 99
                }
            }
            break
        case 99:
            logDebug "readSingleAttrStateMachine: st:${st} - THE END"
            st = 0
            break
        default :    // error
            st = 0
            break
    }
    if (st != 0) {
        state['stateMachines']['readSingeAttrState'] = st
        state['stateMachines']['readSingeAttrRetry'] = retry
        if (data != null) {
            data['action'] = RUNNING
        }
        runInMillis(STATE_MACHINE_PERIOD, readSingleAttrStateMachine, [overwrite: true, data: data])
    }
}

// Helper method to check if child device for this endpoint exists and is disabled
private boolean isEndpointDisabled(Integer endpoint) {
    ChildDeviceWrapper childDevice = findChildByEndpoint(endpoint)
    if (childDevice == null) {
        // Device doesn't exist yet - not disabled, allow discovery
        return false
    }
    // Return true if device exists and is disabled
    return (childDevice?.disabled == true)
}

@Field static final Integer STATE_DISCOVER_GLOBAL_ELEMENTS_IDLE                       = 0
@Field static final Integer STATE_DISCOVER_GLOBAL_ELEMENTS_INIT                       = 1
@Field static final Integer STATE_DISCOVER_GLOBAL_ELEMENTS_ATTRIBUTE_LIST             = 2
@Field static final Integer STATE_DISCOVER_GLOBAL_ELEMENTS_ATTRIBUTE_LIST_WAIT        = 3
@Field static final Integer STATE_DISCOVER_GLOBAL_ELEMENTS_GLOBAL_ELEMENTS_WAIT       = 5

@Field static final Integer STATE_DISCOVER_GLOBAL_ELEMENTS_ERROR                      = 98
@Field static final Integer STATE_DISCOVER_GLOBAL_ELEMENTS_END                        = 99

/**
 * This state machine checks and discoveres the GLOBAL ELEMENTS of a specific endpoint and cluster.
 *
 * Must be called this way : discoverGlobalElementsStateMachine([action: START, endpoint: Integer, cluster: Integer])
 * where:
 *      - action: START
 *      - endpoint: the endpoint to be discovered
 *      - cluster: the cluster to be discovered
 *      - debug: true/false
 *
 * The following keys are updated when the state machine is running:
 *      state['stateMachines']['discoverGlobalElementsState']  - the current internal state (see the constants above)
 *      state['stateMachines']['discoverGlobalElementsRetry']  - the current number of retries (0..STATE_MACHINE_MAX_RETRIES)
 *      state['stateMachines']['discoverGlobalElementsResult'] - the result of the state machine execution (UNKNOWN, RUNNING, SUCCESS, ERROR)
 *
 * Uses AND FILLS IN the common for all state machines state['stateMachines']['toBeConfirmed']  - [endpoint, cluster, 0xFFFB] and state['stateMachines']['Confirmation'] !
 *
 * The calling function must check the state['stateMachines']['discoverGlobalElementsResult'] to determine the result of the state machine execution.
 */

/**
 *  (Re)issues the value reads for every attribute the cluster's FFFB AttributeList reported, and arms
 *  the confirmation. Returns the number of chunks sent, or 0 when the AttributeList is missing/empty.
 *
 *  chunkSize exists because some bridges silently ignore a large multi-path read on a bridged endpoint.
 *  The Aqara M3 answers a 9-path 0x001D read on endpoint 0x2E but sends NOTHING for the 19-path 0x0039
 *  read on that same endpoint, while happily answering a 20-path read on endpoint 0. So the wait state
 *  can re-issue the identical read in small chunks instead of failing the endpoint.
 */
private Integer sendGlobalElementsValueReads(final Map data, final Integer chunkSize) {
    String fingerprintName = getFingerprintName(data.endpoint)
    String stateClusterName = getStateClusterName([cluster: HexUtils.integerToHexString(data.cluster, 2), attrId: 'FFFB'])
    List storedList = (state[fingerprintName] != null) ? state[fingerprintName][stateClusterName] as List : null
    if (storedList == null || storedList.isEmpty()) { return 0 }
    List<Integer> attributeList = storedList.collect { HexUtils.hexStringToInt(it) }
    List<Map<String, String>> attributePaths = []
    attributeList.each { attrId -> attributePaths.add(matter.attributePath(data.endpoint, data.cluster, attrId)) }
    state['stateMachines']['Confirmation'] = false
    state['stateMachines']['toBeConfirmed'] = [data.endpoint, data.cluster, attributeList.last()]
    return sendChunkedAttributeReads(attributePaths, 500, chunkSize)
}

void discoverGlobalElementsStateMachine(Map data) {
    initializeStateMachineVars()
    if (data != null) {
        if (data['action'] == START) {
            state['stateMachines']['discoverGlobalElementsState']  = STATE_DISCOVER_GLOBAL_ELEMENTS_INIT
            state['stateMachines']['discoverGlobalElementsRetry']  = 0
            state['stateMachines']['discoverGlobalElementsResult'] = RUNNING
            data['action'] = RUNNING    // something different than START or STOP - TODO !
        }
    }
    if (data.debug) { logDebug "discoverGlobalElementsStateMachine: data:${data}, state['stateMachines'] = ${state['stateMachines']}" }

    Integer st =    state['stateMachines']['discoverGlobalElementsState']
    Integer retry = state['stateMachines']['discoverGlobalElementsRetry']
    Integer maxRetries = STATE_MACHINE_MAX_RETRIES * getDiscoveryTimeoutScale()
    //String fingerprintName = getFingerprintName(data.endpoint)
    //String attributeName = getAttributeName([cluster: HexUtils.integerToHexString(data.cluster, 2), attrId: HexUtils.integerToHexString(data.attribute, 2)])
    if (data.debug) { logDebug "discoverGlobalElementsStateMachine: st:${st} retry:${retry} data:${data}" }
    switch (st) {
        case STATE_DISCOVER_GLOBAL_ELEMENTS_IDLE :  // should not happen !
            logWarn "discoverGlobalElementsStateMachine: st:${st} - idle -> unscheduling!"
            state['stateMachines']['discoverGlobalElementsResult'] = ERROR
            unschedule('discoverGlobalElementsStateMachine')
            break
        case STATE_DISCOVER_GLOBAL_ELEMENTS_INIT :
            if (data.debug) { logDebug "discoverGlobalElementsStateMachine: st:${st} endpoint ${data.endpoint} attribute ${data.attribute}- starting ..." }
            st = STATE_DISCOVER_GLOBAL_ELEMENTS_ATTRIBUTE_LIST
        // continue with the next state
        case STATE_DISCOVER_GLOBAL_ELEMENTS_ATTRIBUTE_LIST :
            state['stateMachines']['toBeConfirmed'] = [data.endpoint, data.cluster, 0xFFFB]
            state['stateMachines']['Confirmation'] = false
            readAttribute(data.endpoint, data.cluster, 0xFFFB)
            retry = 0; st = STATE_DISCOVER_GLOBAL_ELEMENTS_ATTRIBUTE_LIST_WAIT
            break
        case STATE_DISCOVER_GLOBAL_ELEMENTS_ATTRIBUTE_LIST_WAIT:
            if (state['stateMachines']['Confirmation'] == true) {
                if (data.debug) { logDebug "discoverGlobalElementsStateMachine: st:${st} - received reading confirmation!" }
                // here we have bridgeDescriptor/fingerprintNN : {AttributeList=[00, 01, 02, 03, FFF8, FFF9, FFFB, FFFC, FFFD]}
                // read all the attributes from the ['AttributeList']
                // chunked - a cluster with 40+ attributes does not fit in a single Read Request (PDU / Thread MTU).
                // Passing null lets sendChunkedAttributeReads() apply effectiveReadChunkSize(): once a bridge has
                // proved it ignores a full-size batch, every later endpoint starts small straight away, so only
                // the first endpoint ever pays the timeout.
                if (sendGlobalElementsValueReads(data, null) == 0) {
                    logWarn "discoverGlobalElementsStateMachine: st:${st} - attributeList is missing or empty, skipping to end"
                    st = STATE_DISCOVER_GLOBAL_ELEMENTS_END
                    break
                }
                retry = 0; st = STATE_DISCOVER_GLOBAL_ELEMENTS_GLOBAL_ELEMENTS_WAIT
            }
            else {
                logTrace "discoverGlobalElementsStateMachine: st:${st} - waiting for the attribute value (retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    logWarn "discoverGlobalElementsStateMachine: st:${st} - timeout waiting for the attribute value (retry=${retry})!"
                    st = STATE_DISCOVER_GLOBAL_ELEMENTS_ERROR
                }
            }
            break
        case STATE_DISCOVER_GLOBAL_ELEMENTS_GLOBAL_ELEMENTS_WAIT:
            if (state['stateMachines']['Confirmation'] == true) {
                if (data.debug) { logDebug "discoverGlobalElementsStateMachine: st:${st} - received reading confirmation!" }
                st = STATE_DISCOVER_GLOBAL_ELEMENTS_END
            }
            else {
                logTrace "discoverGlobalElementsStateMachine: st:${st} - waiting for the attribute value (retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    // No response at all to the full-size batch. Before failing the endpoint, re-issue the
                    // identical read in small chunks - see sendGlobalElementsValueReads(). The flag is sticky
                    // (state.states, so it also survives into later discovery runs, refresh() and
                    // componentRefresh()) and the remaining endpoints skip the timeout entirely.
                    if (latchSmallReadChunks() == true) {
                        Integer sentChunks = sendGlobalElementsValueReads(data, SMALL_READ_CHUNK_SIZE)
                        if (sentChunks > 0) {
                            logWarn "discoverGlobalElementsStateMachine: st:${st} - no response to the full attribute read of cluster 0x${HexUtils.integerToHexString(data.cluster, 2)} on endpoint 0x${HexUtils.integerToHexString(data.endpoint, 1)}; retrying in ${sentChunks} chunks of ${SMALL_READ_CHUNK_SIZE}"
                            retry = 0
                            break
                        }
                    }
                    logWarn "discoverGlobalElementsStateMachine: st:${st} - timeout waiting for the attribute value (retry=${retry})!"
                    st = STATE_DISCOVER_GLOBAL_ELEMENTS_ERROR
                }
            }
            break
        case STATE_DISCOVER_GLOBAL_ELEMENTS_ERROR : // 98 - error
            logWarn "discoverGlobalElementsStateMachine: st:${st} - error"
            sendInfoEvent('ERROR during the Matter Bridge and Devices discovery (STATE_DISCOVER_GLOBAL_ELEMENTS)')
            state.states['isInfo'] = false
            st = 0
            break
        case STATE_DISCOVER_GLOBAL_ELEMENTS_END : // 99 - end
            state.states['isInfo'] = false
            state['stateMachines']['discoverGlobalElementsResult'] = SUCCESS
            if (data.debug) { logDebug "discoverGlobalElementsStateMachine: st:${st} - THE END" }
            st = 0
            break
        default :    // error
            state.states['isInfo'] = false
            state['stateMachines']['discoverGlobalElementsResult'] = ERROR
            st = 0
            break
    }
    if (st != 0) {
        state['stateMachines']['discoverGlobalElementsState'] = st
        state['stateMachines']['discoverGlobalElementsRetry'] = retry
        if (data != null) {
            data['action'] = RUNNING
        }
        runInMillis(STATE_MACHINE_PERIOD, discoverGlobalElementsStateMachine, [overwrite: true, data: data])
    }
    else {
        state.states['isInfo'] = false
    }
}

/*
 ********************************************* discoverAllStateMachine  *********************************************
 */

@Field static final Integer DISCOVER_ALL_STATE_IDLE                                     = 0
@Field static final Integer DISCOVER_ALL_STATE_INIT                                     = 1

@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_GLOBAL_ELEMENTS                    = 101
@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_GLOBAL_ELEMENTS_WAIT               = 102

// the bridge is pinged first - the discovery is started only if the bridge responds
@Field static final Integer DISCOVER_ALL_STATE_PING_BRIDGE                               = 110
@Field static final Integer DISCOVER_ALL_STATE_PING_BRIDGE_WAIT                          = 111

@Field static final Integer DISCOVER_ALL_PING_MAX_ATTEMPTS = 3     // total bridge ping attempts before aborting the discovery
@Field static final Integer DISCOVER_ALL_PING_MAX_TICKS    = 15    // ~5 seconds per attempt at STATE_MACHINE_PERIOD = 330 ms

@Field static final Integer DISCOVER_ALL_STATE_DESCIPTOR_ATTRIBUTE_LIST                 = 2
@Field static final Integer DISCOVER_ALL_STATE_DESCIPTOR_ATTRIBUTE_LIST_WAIT            = 3
@Field static final Integer DISCOVER_ALL_STATE_DESCIPTOR_GLOBAL_ELEMENTS                = 4
@Field static final Integer DISCOVER_ALL_STATE_DESCIPTOR_GLOBAL_ELEMENTS_WAIT           = 5
@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_LIST              = 6
@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_LIST_WAIT         = 7
@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_VALUES            = 8
@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_VALUES_WAIT       = 9

@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_GENERAL_DIAGNOSTICS               = 14
@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_GENERAL_DIAGNOSTICS_WAIT          = 15
@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_POWER_SOURCE                      = 16
@Field static final Integer DISCOVER_ALL_STATE_BRIDGE_POWER_SOURCE_WAIT                 = 17

@Field static final Integer DISCOVER_ALL_STATE_GET_PARTS_LIST_START                     = 20
@Field static final Integer DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_STATE         = 21
@Field static final Integer DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_WAIT_STATE    = 22
@Field static final Integer DISCOVER_ALL_STATE_GET_BRIDGED_DEVICE_BASIC_INFO_STATE      = 23
@Field static final Integer DISCOVER_ALL_STATE_GET_BRIDGED_DEVICE_BASIC_INFO_WAIT_STATE = 24
@Field static final Integer DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_START                 = 25
@Field static final Integer DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE           = 26
// 27 was DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_WAIT - dead since nothing ever assigned it; removed 2026-08-13
@Field static final Integer DISCOVER_ALL_STATE_COPY_FINGERPRINT_TO_CHILDREN             = 28
@Field static final Integer DISCOVER_ALL_STATE_CLUSTER_DATA_WAIT                        = 29
@Field static final Integer DISCOVER_ALL_STATE_SUBSCRIBE_KNOWN_CLUSTERS                 = 30

@Field static final Integer DISCOVER_ALL_STATE_DESCIPTOR_CLUSTER                        = 70
@Field static final Integer DISCOVER_ALL_STATE_DESCIPTOR_CLUSTER_WAIT                   = 71

@Field static final Integer DISCOVER_ALL_STATE_NEXT_STATE                               = 80
@Field static final Integer DISCOVER_ALL_STATE_ERROR                                    = 98
@Field static final Integer DISCOVER_ALL_STATE_END                                      = 99

/****************************************** discoverAllStateMachine ******************************************
 *
 * This is the main state machine for discovering the Matter Bridge and the bridged devices.
 *
 * @param data (optional) A map containing additional data to control the state machine execution.
 *             The following keys are supported:
    *             - action: START, STOP, RUNNING
    *             - endpoint: the endpoint to be discovered (0 for the bridge)
    *             - cluster: the cluster to be discovered
    *             - attribute: the attribute to be discovered
 */
void discoverAllStateMachine(Map data = null) {
    initializeStateMachineVars()
    state['states']['isDiscovery'] = true

    if (data != null) {
        if (data['action'] == START) {
            if (data['goToState'] == null) {
                state['stateMachines']['discoverAllState']  = DISCOVER_ALL_STATE_INIT
            }
            else {
                state['stateMachines']['discoverAllState']  = data['goToState']
            }
            state['stateMachines']['discoverAllRetry']  = 0
            state['stateMachines']['discoverAllResult'] = UNKNOWN
            state['stateMachines']['discoverAllPingAttempt'] = 0
            state['stateMachines']['errorText'] = 'none'
            data['action'] = RUNNING
            logInfo '_DiscoverAll(): started!'
        }
    }
    logTrace "discoverAllStateMachine: data:${data}, state['stateMachines'] = ${state['stateMachines']}"

    Integer st =    state['stateMachines']['discoverAllState']
    Integer retry = state['stateMachines']['discoverAllRetry']
    Integer maxRetries = STATE_MACHINE_MAX_RETRIES * getDiscoveryTimeoutScale()
    Integer stateMachinePeriod = STATE_MACHINE_PERIOD              // can be changed, depending on the expected execution time of the different states
    logTrace "discoverAllStateMachine: st:${st} retry:${retry} data:${data}"
    switch (st) {
        case DISCOVER_ALL_STATE_IDLE :
            logWarn "discoverAllStateMachine: st:${st} - idle -> unscheduling!"
            unschedule('discoverAllStateMachine')
            break
        case DISCOVER_ALL_STATE_PING_BRIDGE :
            // ping the bridge BEFORE the DISCOVER_ALL_STATE_INIT state, because INIT calls initializeVars(fullInit=true),
            // which clears all the states and resets the preferences to their default values!
            Integer pingAttempt = safeToInt(state['stateMachines']['discoverAllPingAttempt'], 0) + 1
            state['stateMachines']['discoverAllPingAttempt'] = pingAttempt
            sendInfoEvent("Checking whether the Matter Bridge responds (attempt ${pingAttempt} of ${DISCOVER_ALL_PING_MAX_ATTEMPTS}) ...")
            // The hub's own networkStatus usually knows the answer already. Warn only - it is NOT used to
            // abort here, because a stale networkStatus must never be able to block a legitimate discovery.
            if (isNetworkOffline()) {
                logWarn "discoverAllStateMachine: st:${st} - the hub reports networkStatus 'offline' for this bridge - the discovery will most probably fail!"
            }
            state['states']['isInfo'] = false       // the ping reply must not be swallowed by the Info collector
            state['stateMachines']['pingStartTime'] = new Date().getTime()
            // here we fill in 'toBeConfirmed' and 'Confirmation', because the readAttribute() is called directly !
            state['stateMachines']['toBeConfirmed'] = [0, 0x0028, 0x0000];  state['stateMachines']['Confirmation'] = false
            readAttribute(0, 0x0028, 0x0000)        // Basic Information cluster 0x0028 : DataModelRevision (the same read as pingCmd())
            retry = 0; st = DISCOVER_ALL_STATE_PING_BRIDGE_WAIT
            break
        case DISCOVER_ALL_STATE_PING_BRIDGE_WAIT :
            if (state['stateMachines']['Confirmation'] == true) {
                Long pingRtt = new Date().getTime() - ((state['stateMachines']['pingStartTime'] ?: new Date().getTime()) as Long)
                logDebug "discoverAllStateMachine: st:${st} - the Matter Bridge responded in ${pingRtt} ms"
                sendInfoEvent("Matter Bridge responded in ${pingRtt} ms - starting the discovery ...")
                state['stateMachines']['discoverAllPingAttempt'] = 0
                retry = 0; st = safeToInt(data?.afterPingState, DISCOVER_ALL_STATE_INIT)
            }
            else {
                logTrace "discoverAllStateMachine: st:${st} - waiting for the Matter Bridge ping response (retry=${retry})"
                retry++
                if (retry > DISCOVER_ALL_PING_MAX_TICKS) {
                    Integer pingAttemptsDone = safeToInt(state['stateMachines']['discoverAllPingAttempt'], 0)
                    if (pingAttemptsDone < DISCOVER_ALL_PING_MAX_ATTEMPTS) {
                        logWarn "discoverAllStateMachine: st:${st} - no response from the Matter Bridge (attempt ${pingAttemptsDone}), retrying ..."
                        retry = 0; st = DISCOVER_ALL_STATE_PING_BRIDGE
                    }
                    else {
                        logWarn "discoverAllStateMachine: st:${st} - the Matter Bridge did not respond after ${pingAttemptsDone} attempts - discovery aborted!"
                        state['stateMachines']['discoverAllPingAttempt'] = 0
                        state['stateMachines']['errorText'] = "the Matter Bridge did not respond to ${DISCOVER_ALL_PING_MAX_ATTEMPTS} ping attempts - discovery aborted, nothing was changed. Check that the bridge is powered on and reachable, then try again.".toString()
                        st = DISCOVER_ALL_STATE_ERROR
                    }
                }
            }
            break
        case DISCOVER_ALL_STATE_INIT: // start
            sendInfoEvent('Starting Matter Bridge and Devices discovery ...<br><br><br>')
            if (!(state.bridgeDescriptor instanceof Map)) { state.bridgeDescriptor = [:] }
            state.states['isInfo'] = true
            state['stateMachines']['discoverAllResult'] = RUNNING
            boolean oldLogEnable = settings?.logEnable
            initializeVars(fullInit = true)            // added 02/09/2024
            if (_DEBUG == true) { device?.updateSetting('logEnable', oldLogEnable) }
            sendInfoEvent('Removing all current subscriptions ...')
            clearSubscriptionsState()                  // clear the subscriptions state
            st = DISCOVER_ALL_STATE_BRIDGE_GLOBAL_ELEMENTS
            // break is skipped intentionally - continue with the next state
        case DISCOVER_ALL_STATE_BRIDGE_GLOBAL_ELEMENTS :
            sendInfoEvent('Discovering the Matter Device...')
            discoverGlobalElementsStateMachine([action: START, endpoint: 0, cluster: 0x001D, debug: false])
            stateMachinePeriod = STATE_MACHINE_PERIOD * 2
            retry = 0; st = DISCOVER_ALL_STATE_BRIDGE_GLOBAL_ELEMENTS_WAIT
            break
        case DISCOVER_ALL_STATE_BRIDGE_GLOBAL_ELEMENTS_WAIT:
            if (state['stateMachines']['discoverGlobalElementsResult']  == SUCCESS) {
                logDebug "discoverAllStateMachine: st:${st} - received discoverGlobalElementsResult confirmation!"
                st = DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_LIST
            }
            else {
                logTrace "discoverAllStateMachine: st:${st} - waiting for the attribute value (retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    logWarn "discoverAllStateMachine: st:${st} - timeout waiting for the attribute value (retry=${retry})!"
                    state['stateMachines']['errorText'] = 'ERROR during the Matter Bridge and Devices discovery (state BRIDGE_GLOBAL_ELEMENTS_WAIT)'
                    st = DISCOVER_ALL_STATE_ERROR
                }
            }
            break
        case DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_LIST :
            readAttribute(0, 0x0028, 0xFFFB)        // Basic Info cluster 0x0028
            // here we fill in 'toBeConfirmed' and 'Confirmation', because the readAttribute() is called directly !
            state['stateMachines']['toBeConfirmed'] = [0, 0x0028, 0xFFFB];  state['stateMachines']['Confirmation'] = false
            retry = 0; st = DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_LIST_WAIT
            break
        case DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_LIST_WAIT :
            if (state['stateMachines']['Confirmation'] == true) {
                logTrace "discoverAllStateMachine: st:${st} - received reading confirmation!"
                st = DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_VALUES
            }
            else {
                logTrace "discoverAllStateMachine: st:${st} - waiting for the attribute value (retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    logWarn "discoverAllStateMachine: st:${st} - timeout waiting for the attribute value (retry=${retry})!"
                    state['stateMachines']['errorText'] = 'state BRIDGE_BASIC_INFO_ATTR_LIST_WAIT timeout !'
                    st = DISCOVER_ALL_STATE_ERROR
                }
            }
            break
        case DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_VALUES :
            // here we have bridgeDescriptor :  0028_FFFB=[00, 01, 02, 03, 04, 05, 06, 07, 08, 09, 0A, 0B, 0C, 0D, 0E, 0F, 10, 11, 12, 13, FFF8, FFF9, FFFB, FFFC, FFFD]
            // read all the attributes from the bridgeDescriptor['0028_FFFB']
            List<Map<String, String>> attributePaths = []
            List<Integer> attributeList = state.bridgeDescriptor['0028_FFFB']?.collect { HexUtils.hexStringToInt(it) }
            attributeList?.each { attrId ->
                attributePaths?.add(matter.attributePath(0, 0x0028, attrId))
            }
            state.states['isInfo'] = true
            state.states['cluster'] = '0028'
            state.tmp = null
            state['stateMachines']['Confirmation'] = false
            state['stateMachines']['toBeConfirmed'] = [0, 0x0028, attributeList?.last()]
            // here we fill in 'toBeConfirmed' and 'Confirmation', because the read is issued directly !
            // chunked, for the same PDU / Thread MTU reason as everywhere else
            sendChunkedAttributeReads(attributePaths)
            retry = 0; st = DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_VALUES_WAIT
            break
        case DISCOVER_ALL_STATE_BRIDGE_BASIC_INFO_ATTR_VALUES_WAIT :
            if (state['stateMachines']['Confirmation'] == true) {
                logTrace "discoverAllStateMachine: st:${st} - received bridgeDescriptor Basic Info reading confirmation!"
                logRequestedClusterAttrResult([cluster:0x28, endpoint:0])
                // Minimal/safe discovery: if bridge exposes General Diagnostics (0x0033), read only AttributeList (0xFFFB)
                // to populate state.bridgeDescriptor['0033_FFFB'] without reading all attributes (some devices error on 0x0000).
                st = DISCOVER_ALL_STATE_BRIDGE_GENERAL_DIAGNOSTICS
            }
            else {
                logTrace "discoverAllStateMachine: st:${st} - waiting for the attribute value (retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    logWarn "discoverAllStateMachine: st:${st} - timeout waiting for the attribute value (retry=${retry})!"
                    sendInfoEvent('state BRIDGE_BASIC_INFO_ATTR_VALUES_WAIT timeout !')
                    st = DISCOVER_ALL_STATE_ERROR
                }
            }
            break
        case DISCOVER_ALL_STATE_BRIDGE_GENERAL_DIAGNOSTICS :
            // Check if the General Diagnostics cluster 0x0033 is in the bridge ServerList
            List<String> serverList = state.bridgeDescriptor['ServerList']
            boolean hasGeneralDiagnostics = serverList?.any { String c ->
                try {
                    return HexUtils.hexStringToInt(c) == 0x0033
                } catch (ignored) {
                    return false
                }
            } ?: false

            logDebug "discoverAllStateMachine: DISCOVER_ALL_STATE_BRIDGE_GENERAL_DIAGNOSTICS - serverList:${serverList} hasGeneralDiagnostics=${hasGeneralDiagnostics}"
            if (hasGeneralDiagnostics) {
                logDebug "discoverAllStateMachine: st:${st} - reading General Diagnostics AttributeList (0x0033/0xFFFB)"
                state.states['isInfo'] = true
                state.tmp = null
                state.states['cluster'] = '0033'
                // Read ONLY AttributeList for 0x0033; parseGlobalElements will store it as state.bridgeDescriptor['0033_FFFB'].
                state['stateMachines']['toBeConfirmed'] = [0, 0x0033, 0xFFFB]
                state['stateMachines']['Confirmation'] = false
                readAttribute(0, 0x0033, 0xFFFB)
                retry = 0
                st = DISCOVER_ALL_STATE_BRIDGE_GENERAL_DIAGNOSTICS_WAIT
            }
            else {
                logWarn "discoverAllStateMachine: st:${st} - General Diagnostics cluster 0x0033 is not in the ServerList"
                st = DISCOVER_ALL_STATE_BRIDGE_POWER_SOURCE
            }
            break
        case DISCOVER_ALL_STATE_BRIDGE_GENERAL_DIAGNOSTICS_WAIT :
            if (state['stateMachines']['Confirmation'] == true) {
                logDebug "discoverAllStateMachine: st:${st} - received General Diagnostics AttributeList confirmation"
                logRequestedClusterAttrResult([cluster: 0x0033, endpoint: 0])
                st = DISCOVER_ALL_STATE_BRIDGE_POWER_SOURCE
            }
            else {
                logTrace "discoverAllStateMachine: st:${st} - waiting for the attribute value (retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    logWarn "discoverAllStateMachine: st:${st} - timeout waiting for the attribute value (retry=${retry})!"
                    state['stateMachines']['errorText'] = 'state BRIDGE_GENERAL_DIAGNOSTICS_WAIT timeout !'
                    st = DISCOVER_ALL_STATE_ERROR
                }
            }
            break

        // The root node (endpoint 0) may expose its own PowerSource cluster - IKEA Thread devices report
        // their battery there instead of on the application endpoint. Optional: never abort the discovery.
        case DISCOVER_ALL_STATE_BRIDGE_POWER_SOURCE :
            List<String> rootServerList = state.bridgeDescriptor['ServerList']
            boolean hasPowerSource = rootServerList?.any { String c ->
                try {
                    return HexUtils.hexStringToInt(c) == 0x002F
                } catch (ignored) {
                    return false
                }
            } ?: false

            logDebug "discoverAllStateMachine: DISCOVER_ALL_STATE_BRIDGE_POWER_SOURCE - serverList:${rootServerList} hasPowerSource=${hasPowerSource}"
            if (hasPowerSource) {
                logDebug "discoverAllStateMachine: st:${st} - reading root node PowerSource AttributeList (0x002F/0xFFFB)"
                state.states['isInfo'] = true
                state.tmp = null
                state.states['cluster'] = '002F'
                // Read ONLY AttributeList for 0x002F; parseGlobalElements will store it as state.bridgeDescriptor['002F_FFFB'].
                state['stateMachines']['toBeConfirmed'] = [0, 0x002F, 0xFFFB]
                state['stateMachines']['Confirmation'] = false
                readAttribute(0, 0x002F, 0xFFFB)
                retry = 0
                st = DISCOVER_ALL_STATE_BRIDGE_POWER_SOURCE_WAIT
            }
            else {
                logDebug "discoverAllStateMachine: st:${st} - PowerSource cluster 0x002F is not in the root node ServerList"
                st = DISCOVER_ALL_STATE_GET_PARTS_LIST_START
            }
            break
        case DISCOVER_ALL_STATE_BRIDGE_POWER_SOURCE_WAIT :
            if (state['stateMachines']['Confirmation'] == true) {
                logDebug "discoverAllStateMachine: st:${st} - received root node PowerSource AttributeList confirmation"
                logRequestedClusterAttrResult([cluster: 0x002F, endpoint: 0])
                st = DISCOVER_ALL_STATE_GET_PARTS_LIST_START
            }
            else {
                logTrace "discoverAllStateMachine: st:${st} - waiting for the attribute value (retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    // an optional cluster read must not abort the whole discovery - carry on without it
                    logWarn "discoverAllStateMachine: st:${st} - timeout reading the root node PowerSource AttributeList; continuing without it"
                    st = DISCOVER_ALL_STATE_GET_PARTS_LIST_START
                }
            }
            break

        case DISCOVER_ALL_STATE_GET_PARTS_LIST_START :
            logDebug "discoverAllStateMachine: st:${st} - Starting Bridged Devices discovery ...<br><br><br><br><br><br><br><br><br>"
            sendInfoEvent('(A1) Matter Bridge discovery completed')
            sendInfoEvent('(A2) Starting Bridged Devices discovery')
            logDebug "discoverAllStateMachine: st:${st} - Getting the PartList ... state.bridgeDescriptor['PartsList'] = ${state.bridgeDescriptor['PartsList']}"
            Integer partsListCount = state.bridgeDescriptor['PartsList']?.size() ?: 0
            if (partsListCount == 0) {
                logWarn "discoverAllStateMachine: st:${st} - PartsList is empty !"
                state['stateMachines']['errorText'] = 'state GET_PARTS_LIST_START - PartsList is empty !'
                st = DISCOVER_ALL_STATE_ERROR
                break
            }
            state['stateMachines']['discoverAllPartsListIndex'] = 0
            st = DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_STATE
            stateMachinePeriod = 100       // go quickly ....
            break
        case DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_STATE :
            Integer partsListCount = state.bridgeDescriptor['PartsList']?.size() ?: 0
            Integer partsListIndex = state['stateMachines']['discoverAllPartsListIndex']
            if (partsListIndex >= partsListCount) {
                logDebug "discoverAllStateMachine: st:${st} - all parts discovered (total #${partsListCount}) !"
                st = DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_START    // we are done with the parts list !
                break
            }
            String partEndpoint = state.bridgeDescriptor['PartsList'][partsListIndex]
            Integer partEndpointInt = HexUtils.hexStringToInt(partEndpoint)
            
            // Check if this endpoint's child device is disabled - skip if so
            if (isEndpointDisabled(partEndpointInt)) {
                String fingerprintName = getFingerprintName(partEndpointInt)
                logDebug "discoverAllStateMachine: st:${st} - Skipping disabled device ${fingerprintName} at endpoint ${partEndpoint}"
                sendInfoEvent("Skipped disabled device endpoint ${partEndpoint}")
                // Skip to next device
                state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                stateMachinePeriod = 100  // Go quickly to next
                break  // Stay in same state to process next endpoint
            }
            
            logTrace "discoverAllStateMachine: st:${st} - partEndpoint = ${partEndpoint} partEndpointInt = ${partEndpointInt}"
            state.states['isInfo'] = true
            state.states['cluster'] = '001D'     // HexUtils.integerToHexString(partEndpointInt, 2)
            state.tmp = null
            // do not call 'toBeConfirmed' and 'Confirmation' here - it is filled in the discoverGlobalElementsStateMachine() !
            discoverGlobalElementsStateMachine([action: START, endpoint: partEndpointInt, cluster: 0x001D, debug: false])
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////
            stateMachinePeriod = STATE_MACHINE_PERIOD * 3
            retry = 0; st = DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_WAIT_STATE
            break
        case DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_WAIT_STATE :
            Integer partsListIndex = state['stateMachines']['discoverAllPartsListIndex']
            String partEndpoint = state.bridgeDescriptor['PartsList'][partsListIndex]
            Integer partEndpointInt = HexUtils.hexStringToInt(partEndpoint)
            String fingerprintName = getFingerprintName(partEndpointInt)
            if (state['stateMachines']['discoverGlobalElementsResult']  == SUCCESS) {
                logDebug "discoverAllStateMachine: st:${st} - ['PartsList'][$partEndpoint] confirmation!"
                logRequestedClusterAttrResult([cluster: 0x001D, endpoint: partEndpointInt])
                sendInfoEvent("Found bridged device part #${partsListIndex} ${fingerprintName}")
                // for each child device that has the BridgedDeviceBasicInformationCluster '39' in the ServerList ->  read the BridgedDeviceBasicInformationCluster attributes
                st = DISCOVER_ALL_STATE_GET_BRIDGED_DEVICE_BASIC_INFO_STATE
            }
            else {
                logTrace "discoverAllStateMachine: st:${st} - waiting for the attribute value retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    logWarn "discoverAllStateMachine: st:${st} - fingerprint${fingerprintName} timeout waiting for cluster 0x1D reading results !"
                    // st = DISCOVER_ALL_STATE_ERROR
                    // continue with the next device, even if there is an error
                    sendInfoEvent("<b>ERROR discovering bridged device #${partsListIndex} ${fingerprintName} - timeout waiting for cluster 0x1D reading results !</b>")
                    state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                    st = DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_STATE
                }
            }
            break

        case DISCOVER_ALL_STATE_GET_BRIDGED_DEVICE_BASIC_INFO_STATE :   // 0x0039 is NOT OBLIGATORY !
            // for each child device that has the BridgedDeviceBasicInformationCluster '39' in the ServerList ->  read the BridgedDeviceBasicInformationCluster attributes
            Integer partsListIndex = state['stateMachines']['discoverAllPartsListIndex']
            String partEndpoint = state.bridgeDescriptor['PartsList'][partsListIndex]
            Integer partEndpointInt = HexUtils.hexStringToInt(partEndpoint)
            String fingerprintName = getFingerprintName(partEndpointInt)
            logDebug "discoverAllStateMachine: st:${st} - Getting the BridgedDeviceBasicInformationCluster attributes for endpoint ${partEndpoint} ...<br><br><br>"
            if (state[fingerprintName]['ServerList']?.contains('0039')) {
                state.states['isInfo'] = true
                state.states['cluster'] = '0039'     // HexUtils.integerToHexString(partEndpointInt, 2)
                state.tmp = null
                // do not call 'toBeConfirmed' and 'Confirmation' here - it is filled in in the discoverGlobalElementsStateMachine() !
                discoverGlobalElementsStateMachine([action: START, endpoint: partEndpointInt, cluster: 0x0039, debug: false])
                stateMachinePeriod = STATE_MACHINE_PERIOD * 2
                retry = 0; st = DISCOVER_ALL_STATE_GET_BRIDGED_DEVICE_BASIC_INFO_WAIT_STATE
            }
            else {
                logDebug "discoverAllStateMachine: st:${st} - fingerprint ${fingerprintName} BridgedDeviceBasicInformationCluster '0039' is not in the ServerList ! (this is not obligatory)"
                state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                st = DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_STATE
                // check the next bridged device ...
            }
            break
        case DISCOVER_ALL_STATE_GET_BRIDGED_DEVICE_BASIC_INFO_WAIT_STATE :
            Integer partsListIndex = state['stateMachines']['discoverAllPartsListIndex'] ?: 0
            String partEndpoint = state.bridgeDescriptor['PartsList'][partsListIndex] ?: 0
            Integer partEndpointInt = HexUtils.hexStringToInt(partEndpoint)
            String fingerprintName = getFingerprintName(partEndpointInt)
            if (state['stateMachines']['discoverGlobalElementsResult']  == SUCCESS) {
                logDebug "discoverAllStateMachine: st:${st} - fingerprint ${fingerprintName} received BridgedDeviceBasicInformationCluster confirmation!"
                logRequestedClusterAttrResult([cluster: 0x0039, endpoint: partEndpointInt])
                state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                st = DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_STATE
            }
            else {
                logDebug "discoverAllStateMachine: st:${st} - waiting for the attribute value retry=${retry})"
                retry++
                if (retry > maxRetries) {
                    logWarn "discoverAllStateMachine: st:${st} - timeout waiting for the attribute value retry=${retry})!"
                    //st = DISCOVER_ALL_STATE_ERROR
                    // continue with the next device, even if there is an error
                    sendInfoEvent("<b>ERROR discovering bridged device #${partsListIndex} ${fingerprintName} - timeout waiting for cluster 0x39 reading results !</b>")
                    state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                    st = DISCOVER_ALL_STATE_GET_PARTS_LIST_NEXT_DEVICE_STATE
                }
            }
            break

        // ------------------------------- preparing for subscription to the known clusters atteributes -> filling in state[fingerprintName]['Subscribe']  -------------------------------
        case DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_START :
            sendInfoEvent('(A2) Bridged Devices discovery completed')
            // All endpoint fingerprints now populated - determine device type
            finalizeDeviceType()
            sendInfoEvent('(A3) Starting capabilities discovery')
            // next step is for each child device -  check the ServerList for useful clusters ..
            state['stateMachines']['discoverAllPartsListIndex'] = 0
            st = DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE
            stateMachinePeriod = 100       // go quickly ....
            break
        case DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE :
            Integer partsListIndex = state['stateMachines']['discoverAllPartsListIndex'] ?: 0
            Integer partsListCount = state.bridgeDescriptor['PartsList']?.size() ?: 0
            if (partsListIndex >= partsListCount) {
                logDebug "discoverAllStateMachine: st:${st} - all parts discovered (total #${partsListCount}) !"
                st = DISCOVER_ALL_STATE_SUBSCRIBE_KNOWN_CLUSTERS  // last step
                break
            }

            String partEndpoint = state.bridgeDescriptor['PartsList'][partsListIndex]
            Integer partEndpointInt = HexUtils.hexStringToInt(partEndpoint)
            
            // Check if this endpoint's child device is disabled - skip if so
            if (isEndpointDisabled(partEndpointInt)) {
                String fingerprintName = getFingerprintName(partEndpointInt)
                logDebug "discoverAllStateMachine: st:${st} - Skipping disabled device ${fingerprintName} at endpoint ${partEndpoint}"
                // Skip to next device
                state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                stateMachinePeriod = 100  // Go quickly to next
                break  // Stay in same state to process next endpoint
            }
            
            String fingerprintName = getFingerprintName(partEndpointInt)
            logDebug "discoverAllStateMachine: st:${st} - fingerprint ${fingerprintName} Getting the SupportedClusters for endpoint ${partEndpoint} ...<br><br><br>"
            if (fingerprintName == null || state[fingerprintName] == null || state[fingerprintName]['ServerList'] == null) {
                logWarn "discoverAllStateMachine: st:${st} - fingerprintName ${fingerprintName} ServerList is empty !"
                state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                st = DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE
                break
            }
            Integer supportedClustersCount = state[fingerprintName]['ServerList']?.size() ?: 0
            //Integer supportedClustersIndex = state['stateMachines']['discoverAllSupportedClustersIndex'] ?: 0 // not used!
            if (supportedClustersCount == 0) {
                logWarn "discoverAllStateMachine: st:${st} - fingerprintName ${fingerprintName} ServerList is empty !"
                state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                st = DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE
                break
            }
            List<Integer> supportedMatterClusters = SupportedMatterClusters*.key      // The spread-dot operator (*.) is used to invoke an action on all items of an aggregate object.
            List<Integer> serverListCluster = state[fingerprintName]['ServerList']?.collect { HexUtils.hexStringToInt(it) }
            logTrace "discoverAllStateMachine: st:${st} DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE- ServerListCluster = ${serverListCluster} (${state[fingerprintName]['ServerList']})"
            // find all elements in the supportedMatterClusters that are in the ServerList
            List<Integer> matchedClustersList = supportedMatterClusters?.findAll { serverListCluster?.contains(it) }       // empty list [] if nothing found
            logDebug "${fingerprintName} supported clusters : ${matchedClustersList}"
            /* groovylint-disable-next-line ConfusingTernary */
            Integer supportedCluster =  matchedClustersList != [] ?  matchedClustersList?.first() : 0
            if (supportedCluster != null && supportedCluster != 0) {
                logDebug "discoverAllStateMachine: st:${st} - ${fingerprintName} <b>found supportedCluster ${supportedCluster} in matchedClustersList ${matchedClustersList}</b> from the SupportedMatterClusters ${supportedMatterClusters} in the ServerList ${serverListCluster}"
                state[fingerprintName]['Subscribe'] = matchedClustersList
                // convert the figerprint data to a map needed for the createChildDevice() method
                logDebug "fingerPrintToData: fingerprintName:${fingerprintName}"
                Map deviceData = fingerprintToData(fingerprintName)
                logDebug "fingerPrintToData: deviceData:${deviceData}"
                boolean result = createChildDevices(deviceData)
                if (result == false) {
                    logWarn "discoverAllStateMachine: st:${st} - createChildDevice(${deviceData}) returned ${result}"
                    state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                    st = DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE
                    break
                }
                else {
                    logDebug "discoverAllStateMachine: st:${st} - createChildDevice(${deviceData}) returned ${result}"
                    sendInfoEvent("Created child device ${deviceData?.name} (${deviceData?.product_name})")
                }
                // Read cluster-specific global attributes for all matched clusters
                List<Map<String, String>> attributePaths = []
                Map<String, Boolean> expectedAttributes = [:]  // Track what we're waiting for
                
                matchedClustersList?.each { cluster ->
                    String clusterHex = HexUtils.integerToHexString(cluster, 2).padLeft(4, '0').toUpperCase()
                    // was: String clusterHex = HexUtils.integerToHexString(cluster, 2).toUpperCase()
                    String endpointHex = HexUtils.integerToHexString(partEndpointInt, 1).padLeft(2, '0').toUpperCase()
                    // Add attribute read requests
                    // the EventList oxFFFA is missed intentionally, seems it can not be read
                    attributePaths.add(matter.attributePath(partEndpointInt, cluster, 0xFFFB))    // AttributeList
                    attributePaths.add(matter.attributePath(partEndpointInt, cluster, 0xFFF8))    // GeneratedCommandList
                    attributePaths.add(matter.attributePath(partEndpointInt, cluster, 0xFFF9))    // AcceptedCommandList
                    attributePaths.add(matter.attributePath(partEndpointInt, cluster, 0xFFFC))    // FeatureMap
                    // Track expected responses. 
                    expectedAttributes["${endpointHex}_${clusterHex}_FFFB"] = false
                    expectedAttributes["${endpointHex}_${clusterHex}_FFF8"] = false
                    expectedAttributes["${endpointHex}_${clusterHex}_FFF9"] = false
                    expectedAttributes["${endpointHex}_${clusterHex}_FFFC"] = false
                }
                // Chunked - 4 paths per matched cluster is 24+ paths on a 6-cluster endpoint, well past the
                // point where some bridges stop answering at all (BUGS.md B24).
                Integer clusterDataChunks = sendChunkedAttributeReads(attributePaths)
                // Store expected attributes and endpoint for wait state
                state['stateMachines']['clusterDataExpected'] = expectedAttributes
                state['stateMachines']['clusterDataEndpoint'] = partEndpoint
                state['stateMachines']['clusterDataRetry'] = 0
                // Snapshot the chunk count of THIS read - state['stateMachines']['lastReadChunks'] is shared
                // with refresh() and could be overwritten while we are waiting (same hazard as B22).
                state['stateMachines']['clusterDataChunks'] = clusterDataChunks
                state['stateMachines']['clusterDataRetried'] = false
                logDebug "discoverAllStateMachine: st:${st} - waiting for ${expectedAttributes.size()} cluster attributes from endpoint ${partEndpoint} (${clusterDataChunks} chunk(s))"
                // Move to wait state instead of immediately copying
                stateMachinePeriod = STATE_MACHINE_PERIOD
                st = DISCOVER_ALL_STATE_CLUSTER_DATA_WAIT
                // 02/12/2024 - go next device !
            }
            else {
                logDebug "discoverAllStateMachine: st:${st} - fingerprintName ${fingerprintName} SupportedMatterClusters ${supportedMatterClusters} are not in the ServerList ${serverListCluster} !"
                state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                st = DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE
            }
            break

        case DISCOVER_ALL_STATE_CLUSTER_DATA_WAIT:
            Map<String, Boolean> expectedAttributes = state['stateMachines']['clusterDataExpected'] ?: [:]
            if (expectedAttributes.isEmpty()) {
                // No attributes to wait for, proceed immediately
                logDebug "discoverAllStateMachine: st:${st} - no cluster data expected, proceeding"
                st = DISCOVER_ALL_STATE_COPY_FINGERPRINT_TO_CHILDREN
                break
            }
            // Check if all expected attributes have been received
            Boolean allReceived = expectedAttributes.values().every { it == true }
            Integer receivedCount = expectedAttributes.values().count { it == true }
            Integer totalCount = expectedAttributes.size()
            if (allReceived) {
                logDebug "discoverAllStateMachine: st:${st} - all ${totalCount} cluster attributes received!"
                // Clear tracking data
                state['stateMachines']['clusterDataExpected'] = null
                state['stateMachines']['clusterDataEndpoint'] = null
                // Move to next device index now (was done prematurely before)
                Integer partsListIndex = state['stateMachines']['discoverAllPartsListIndex'] ?: 0
                state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                // Proceed to copy complete fingerprint
                retry = 0
                stateMachinePeriod = 100  // Quick transition
                st = DISCOVER_ALL_STATE_COPY_FINGERPRINT_TO_CHILDREN
            }
            else {
                // Still waiting for some attributes
                logTrace "discoverAllStateMachine: st:${st} - waiting for cluster data (${receivedCount}/${totalCount} received, retry=${retry})"
                retry++
                stateMachinePeriod = STATE_MACHINE_PERIOD
                // A chunked read is answered chunk by chunk, and each extra chunk costs 500 ms of send pacing
                // plus the device's reply time - budget ~3 ticks for each of them, as infoCollectStateMachine does.
                Integer chunkTicks = (safeNumberToInt(state['stateMachines']['clusterDataChunks'], 1) - 1) * 3
                if (retry > maxRetries + chunkTicks) {
                    List<String> missing = expectedAttributes.findAll { k, v -> v == false }.collect { it.key }
                    // Before giving up on the endpoint, re-issue ONLY the missing paths in small chunks. Unlike
                    // the single-attribute tripwire in discoverGlobalElementsStateMachine, expectedAttributes is
                    // a true per-path ledger, so this retry is exact - it asks for nothing that already arrived.
                    // Latching the quirk makes every later endpoint start small and skip the timeout entirely.
                    if (state['stateMachines']['clusterDataRetried'] != true) {
                        state['stateMachines']['clusterDataRetried'] = true
                        latchSmallReadChunks()
                        List<Map<String, String>> retryPaths = []
                        missing.each { String key ->
                            // keys are built above as "<endpointHex>_<clusterHex>_<attrHex>"
                            List<String> keyParts = key.tokenize('_')
                            if (keyParts.size() == 3) {
                                retryPaths.add(matter.attributePath(HexUtils.hexStringToInt(keyParts[0]), HexUtils.hexStringToInt(keyParts[1]), HexUtils.hexStringToInt(keyParts[2])))
                            }
                        }
                        Integer sentChunks = sendChunkedAttributeReads(retryPaths, 500, SMALL_READ_CHUNK_SIZE)
                        if (sentChunks > 0) {
                            logWarn "discoverAllStateMachine: st:${st} - no response for ${missing.size()} of ${totalCount} cluster attributes on endpoint ${state['stateMachines']['clusterDataEndpoint']}; retrying in ${sentChunks} chunk(s) of ${SMALL_READ_CHUNK_SIZE}"
                            state['stateMachines']['clusterDataChunks'] = sentChunks
                            retry = 0
                            break
                        }
                    }
                    // Timeout - proceed anyway with incomplete data
                    logWarn "discoverAllStateMachine: st:${st} - timeout waiting for cluster data! Missing: ${missing}"
                    // Clear tracking data
                    state['stateMachines']['clusterDataExpected'] = null
                    state['stateMachines']['clusterDataEndpoint'] = null
                    // Move to next device index
                    Integer partsListIndex = state['stateMachines']['discoverAllPartsListIndex'] ?: 0
                    state['stateMachines']['discoverAllPartsListIndex'] = partsListIndex + 1
                    // Proceed to copy (incomplete) fingerprint
                    retry = 0
                    st = DISCOVER_ALL_STATE_COPY_FINGERPRINT_TO_CHILDREN
                }
            }
            break

        case DISCOVER_ALL_STATE_COPY_FINGERPRINT_TO_CHILDREN :
            Integer partsListIndex = state['stateMachines']['discoverAllPartsListIndex'] ?: 0
            if (partsListIndex > 0) {
                String partEndpoint = state.bridgeDescriptor['PartsList'][partsListIndex - 1]
                Integer partEndpointInt = HexUtils.hexStringToInt(partEndpoint)
                String fingerprintName = getFingerprintName(partEndpointInt)
                // Normalize endpoint to 2 characters for DNI (e.g., "0001" -> "01")
                String normalizedEndpoint = HexUtils.integerToHexString(partEndpointInt, 1).toUpperCase()
                String dni = childDniForEndpoint(normalizedEndpoint)
                logDebug "discoverAllStateMachine: st:${st} - copying COMPLETE fingerprint ${fingerprintName} to child device ${dni}"
                copyEntireFingerprintToChild(fingerprintName, dni)
                // Log what was copied for verification
                Map fp = state[fingerprintName]
                List<String> clusterKeys = fp?.keySet()?.findAll { it.contains('_') }?.toList()
                logInfo "Copied complete fingerprint to ${fingerprintName}: ${clusterKeys?.size() ?: 0} cluster attributes"
            }
            stateMachinePeriod = 100  // Go quickly to next device
            st = DISCOVER_ALL_STATE_SUPPORTED_CLUSTERS_NEXT_DEVICE
            break

        case DISCOVER_ALL_STATE_SUBSCRIBE_KNOWN_CLUSTERS :
            sendInfoEvent('compiling the subscriptions list ...')
            fingerprintsToSubscriptionsList()
            sendInfoEvent('re-subscribing ...')
            reSubscribe()
            st = DISCOVER_ALL_STATE_NEXT_STATE
            break

        case DISCOVER_ALL_STATE_NEXT_STATE :
            logDebug "discoverAllStateMachine: st:${st} - DISCOVER_ALL_STATE_NEXT_STATE - anything else?"
            st = DISCOVER_ALL_STATE_END
            break

        case DISCOVER_ALL_STATE_ERROR : // 98 - error
            logDebug "discoverAllStateMachine: st:${st} - error"
            state.states['isInfo'] = false
            state['stateMachines']['discoverAllResult'] = ERROR
            schedulePeriodicJobs()      // an aborted discovery must not leave the periodic jobs unscheduled either
            sendInfoEvent("<b>ERROR during the Matter Bridge and Devices discovery : ${state['stateMachines']['errorText']}</b>")
            st = 0
            break
        case DISCOVER_ALL_STATE_END : // 99 - end
            state.states['isInfo'] = false
            logDebug "discoverAllStateMachine: st:${st} - THE END"
            // DISCOVER_ALL_STATE_INIT ran initializeVars(fullInit = true), whose bare unschedule() cancelled
            // the periodic jobs - restore them, otherwise the health check stays dead until the next save.
            schedulePeriodicJobs()
            sendInfoEvent('*** END of the Matter Bridge and Devices discovery ***')
            //sendInfoEvent('<b>Please wait for the re-subscribe process to complete...</b>')
            state['stateMachines']['discoverAllResult'] = SUCCESS
            st = 0
            break
        default :    // error
            state.states['isInfo'] = false
            st = 0
            break
    }
    if (st != 0) {
        state['stateMachines']['discoverAllState'] = st
        state['stateMachines']['discoverAllRetry'] = retry
        if (data != null) {
            data['action'] = RUNNING
        }
        runInMillis(stateMachinePeriod, discoverAllStateMachine, [overwrite: true, data: data])
    }
    else {
        state.states['isInfo'] = false
        state['states']['isDiscovery'] = false
    }
}
