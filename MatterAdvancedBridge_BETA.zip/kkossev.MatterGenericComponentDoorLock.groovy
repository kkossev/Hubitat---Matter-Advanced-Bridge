 /*
  *  'Matter Generic Component Door Lock' - component driver for Matter Advanced Bridge
  *
  *  https://community.hubitat.com/t/dynamic-capabilities-commands-and-attributes-for-drivers/98342
  *  https://community.hubitat.com/t/project-zemismart-m1-matter-bridge-for-tuya-zigbee-devices-matter/127009
  *
  *  Licensed Virtual the Apache License, Version 2.0 (the "License"); you may not use this file except
  *  in compliance with the License. You may obtain a copy of the License at:
  *
  *      http://www.apache.org/licenses/LICENSE-2.0
  *
  *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
  *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
  *  for the specific language governing permissions and limitations under the License.
  *
  * ver. 1.0.0  2024-04-05 dds82   - first version by Daniel Segall
  * ver. 1.1.0  2024-07-20 kkossev - added Battery capability; added Identify command; added warning state and log messages; added handling of unprocessed Door Lock events
  * ver. 1.1.1  2024-07-23 kkossev - added switch capability (for Apple Home integration workaround)
  * ver. 1.1.2  2024-08-12 kkossev - fixed importURL
  * ver. 1.2.0  2025-01-10 kkossev + Calude Sonnet 4.5 : Matter events handling rework; Door Lock working! :) added ping command and RTT attribute; removed switch capability
  * ver. 1.3.0  2025-01-14 kkossev - moved component methods from parent to component driver; major refactoring 
  * ver. 1.3.1  2025-01-22 kkossev + Claude Haiku 4.5 : Aqara U200 Door Lock support improvements (clearUser seems to be working!)
  * ver. 1.3.2  2025-01-25 kkossev + GPT-4.1 : newParse: true decoding; use matterCommonLib; capability 'LockCodes' is commented out temporarily: (lock codes still not working)
  * ver. 1.3.3  2025-02-06 kkossev   added events 'locking', 'unlocking' for better UI feedback; experimenting ...
  * ver. 1.3.4  2025-02-19 kkossev   moved common methods to matterCommonLib;
  * ver. 1.4.0  2026-05-25 kkossev   capability 'LockCodes' attempt (blind implementation) - first test version.
  * ver. 1.4.1  2026-05-27 kkossev   fixed EZ dashboards unhappy face; added unlockWithTimeout command; added UnboltDoor command; 
  *                                  DuplicateDoorLockEventFilter; added the needed data: Map required by the LCM; added overwriteCodes option; getInfo improvements; 
  *                                  added operation source 'Aliro' (UWB/Apple Watch); added auto discovery for new lock codes reported by the lock;
  * ver. 1.5.0  2026-07-25 kkossev  (dev.branch) callbackType:Invoke handling; bugs fixes;
  * 
  *                                  TODO: 
  *                                  TODO: 
  *                                  TODO: 
  *                                  TODO: add [physical] [digital] event type to events and logs
  *                                  TODO: analyze https://github.com/SmartThingsCommunity/SmartThingsEdgeDrivers/tree/main/drivers/SmartThings/matter-lock 
  *                                  TODO: analyze https://matter-survey.org/cluster/0x0101
  *                                  TODO: update gitHub documentation
  *                                  
  *   WORKING MATTER functions       :  identify(), lock(), unlock(), unlockWithTimeout (0x03), unboltDoor (0x27), matterSetCredentialPIN (0x22), matterClearCredential (0x26), 
  *                                  
  *
*/

import groovy.transform.Field
import groovy.transform.CompileStatic
import hubitat.helper.HexUtils
import hubitat.matter.DataType
import groovy.json.JsonOutput


@Field static final String matterComponentLockVersion = '1.5.0'
@Field static final String matterComponentLockStamp   = '2026/07/25 9:14 AM'

@Field static final Boolean _DEBUG_LOCK = false             // MAKE IT false for PRODUCTION !
@Field static final Boolean _DEFAULT_LOG_ENABLE = true     // disable on production

@Field static final Integer DELETE_TIMEOUT_SECONDS = 5      // time to wait for lock code deletion confirmation event before removing code from lockCodes attribute (to avoid ghost codes in case of failed deletion)
@Field static final Integer SET_CODE_TIMEOUT_SECONDS = 45   // time to wait for lock code set confirmation event before clearing 'setting' status in lockCodes attribute (to avoid stuck 'setting' status in case of failed set)
@Field static final Integer OVERWRITE_CLEAR_TIMEOUT_SECONDS = 6  // fallback: if no LockUserChange(Clear) arrives (slot was empty), proceed with Add after this many seconds
@Field static final Long SET_CREDENTIAL_CONFIRMATION_DEDUP_MS = 30000L
@Field static final Long CLEAR_CREDENTIAL_CONFIRMATION_DEDUP_MS = 30000L
@Field static final Integer GET_USER_SCAN_TIMEOUT_SECONDS = 10
@Field static final Integer GET_CREDENTIAL_STATUS_TIMEOUT_SECONDS = 10
@Field static final Integer SET_USER_TIMEOUT_SECONDS = 10
@Field static final Integer CLEAR_USER_TIMEOUT_SECONDS = 10
@Field static final Long CLEAR_USER_CONFIRMATION_DEDUP_MS = 30000L

metadata {
    definition(name: 'Matter Generic Component Door Lock', namespace: 'kkossev', author: 'Krassimir Kossev', importUrl: 'https://raw.githubusercontent.com/kkossev/Hubitat---Matter-Advanced-Bridge/development/Components/Matter_Generic_Component_Door_Lock') {
        capability 'Sensor'
        capability 'Actuator'
        capability 'Battery'
        capability 'Lock'       // lock - ENUM ["locked", "unlocked with timeout", "unlocked", "unknown"]
        capability 'LockCodes'  // lockCodes, codeChanged, codeLength, maxCodes | setCode(pos,pin,name), deleteCode(pos), getCodes(), setCodeLength(len)
        capability 'Refresh'

        command    'identify', [[name: 'Identify the lock device']]
        command    'getInfo', [[name: 'Check the live logs and the device data for additional information on this device']]
        command    'unlockWithTimeout', [[name: 'timeout*', type: 'NUMBER', description: 'Auto-relock timeout in seconds (1-65535)']]
        command    'unboltDoor', [[name: 'Unbolt door (latch retraction only, not available on all locks)']]
        command    'clearStatistics', [[name: 'Clear event statistics counters and duplicate-event cache']]
        /*
        //command    'unlockWithPIN', [[name: 'pin*', type: 'STRING', description: 'unlock with PIN (not available on all locks)']]
        
        // LockCodes custom commands with dynamic feature support indication
        command    'setCode', [[name: 'codePosition*', type: 'NUMBER', description: 'Code slot (1-based)'],
                               [name: 'pinCode*', type: 'STRING', description: 'PIN code (4-8 digits)'],
                               [name: 'name', type: 'STRING', description: "User name (optional)<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        command    'deleteCode', [[name: 'codePosition*', type: 'NUMBER', description: "Code slot to delete<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        command    'getCodes', [[name: "Retrieve all PIN codes<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        */
        // TODO - move these to state variables or device data ?
        // attribute 'lock', 'ENUM', ["locked", "unlocked with timeout", "unlocked", "unknown", "locking", "unlocking"]  // added 'locking' and 'unlocking' for better UI feedback during lock/unlock operations
        // lockType, actuatorEnabled, operatingMode, supportedOperatingModes are stored in state.lockAttr (not Hubitat attributes)
        
        // Event-related attributes
        // TODO: consider moving these to state variables or device data instead of attributes ?
        attribute 'lastLockOperation', 'STRING'
        attribute 'lastOperationSource', 'STRING'
        attribute 'lastLockOperationError', 'STRING'
        attribute 'lastUserChange', 'STRING'
        attribute 'lastCodeName', 'STRING'
        attribute 'lockAlarm', 'STRING'
        attribute 'doorState', 'STRING'
        
        // Infrastructure/health-check attributes
        attribute 'powerSourceStatus', 'ENUM', ['active', 'standby', 'unavailable']

        if (_DEBUG_LOCK) {
              command  'matterSetCredentialPIN' , [[name:'credentialIndex*', type: 'NUMBER', description: 'Credential Index (1-255)', defaultValue: '1'],
                                           [name:'pinCode*', type: 'STRING', description: 'PIN code (4-8 digits)', defaultValue: '1234'],
                                           [name:'userIndex', type: 'NUMBER', description: 'User Index (1-65534)', defaultValue: '1']]
              command 'matterClearCredential', [[name:'credentialType', type: 'NUMBER', description: 'Credential Type (1=PIN, 2=RFID, 3=Fingerprint, 4=FingerVein, 5=Face, 6-8=Aliro); leave both fields blank to clear all'],
                                     [name:'credentialIndex', type: 'NUMBER', description: 'Credential Index (1-65533); leave blank to clear all of the selected type']]

              command 'matterGetCredentialStatus', [[name:'credentialType*', type: 'NUMBER', description: 'Credential Type (0-8)', defaultValue: '1'],
                                                    [name:'credentialIndex*', type: 'NUMBER', description: 'Credential Index (1-65534)', defaultValue: '1']]
              command 'matterScanCredentials', [[name:'credentialType*', type: 'NUMBER', description: 'Credential Type to scan (0-8)', defaultValue: '1']]
              command 'matterGetUser', [[name:'userIndex*', type: 'NUMBER', description: 'User Index (1-65534)', defaultValue: '1']]
              command 'matterScanUsers', [[name:'Scan occupied Matter users by following NextUserIndex']]
              command 'matterClearUser', [[name:'userIndex*', type:'NUMBER', description:'Existing User Index (1-65533); clear-all is intentionally not supported', defaultValue:'1']]
              command 'matterSetUser', [[name:'userIndex*', type:'NUMBER', description:'User Index (1-65534)', defaultValue:'1'],
                                        [name:'userName', type:'STRING', description:'Optional user name (maximum 10 UTF-8 bytes)']]
              command 'matterModifyUser', [[name:'userIndex*', type:'NUMBER', description:'Existing User Index (1-65534)', defaultValue:'1'],
                                           [name:'userName*', type:'STRING', description:'New user name (maximum 10 UTF-8 bytes)']]
            command 'testInvoke', [[name: 'testInvoke', type: 'STRING', description: 'test', defaultValue : '']]    // for debug purposes only
            command 'testUnlockWithCode', [[name: 'pinCode', type: 'STRING', description: 'Simulate physical unlock with this PIN code', defaultValue: '1234']]
        }
    }
}

preferences {
    section {
	    input name: "helpInfo", type: "hidden", title: fmtHelpInfo("Community Link")
        input name: 'logEnable',
              type: 'bool',
              title: '<b>Enable debug logging</b>',
              required: false,
              defaultValue: _DEFAULT_LOG_ENABLE

        input name: 'txtEnable',
              type: 'bool',
              title: '<b>Enable descriptionText logging</b>',
              required: false,
              defaultValue: true
        //input name: 'optEncrypt', type: 'bool', title: '<b>Enable lockCode encryption</b>', description: '<i>Encrypt PIN codes stored in lockCodes attribute and codeChanged events</i>', defaultValue: false
        input name: 'advancedOptions', type: 'bool', title: '<b>Advanced Options</b>', description: '<i>These advanced options should be already automatically set in an optimal way for your device...</i>', defaultValue: false
        if (device && advancedOptions == true) {
            input name: 'ignoreCompatibilityChecks', type: 'bool', title: '<b>Ignore Compatibility Checks</b>', description: '<i>Allow executing commands that may not be supported by this lock</i>', defaultValue: false
            input name: 'overwriteCodes', type: 'bool', title: '<b>Overwrite existing codes</b>', description: '<i>When enabled, setCode() first deletes any existing credential at the slot before adding the new one. Required for slots registered by Apple Home or other controllers.</i>', defaultValue: false
        }

    }
}



// Hubitat platform 2.5.1.132+ transaction callbacks. The parent passes these Maps unchanged.
void parse(Map descMap) {
    switch (descMap?.callbackType) {
        case 'Invoke':
            handleDoorLockInvokeResponse(descMap)
            break
        case 'SubscriptionResult':
            logDebug "Matter transaction: received SubscriptionResult callback with subscriptionId:${descMap.subscriptionId}"
            break
        default:
            logDebug "parse(Map): ignored callback: ${descMap}"
            break
    }
}

// parse commands from parent
void parse(List<Map> parsedEvents) {
    //if (logEnable) { log.debug "${parsedEvents}" }
    parsedEvents.each { d ->
        /*if (d.name == 'lock') {
            if (device.currentValue('lock') != d.value) {
                if (d.descriptionText) { logInfo "${d.descriptionText}" }
                sendEvent(d)
            }
            else {
                logDebug "parse: ${parsedEvents} : ignored lock event '${d.value}' (no change)"
            }
        }
        else */if (d.name == 'rtt') {
            // Delegate to health status library
            parseRttEvent(d)
        }
        else if (d.name in  ['unprocessed', 'handleInChildDriver']) {
            handleLockMessage(d)
        }
        else {
            if (d.descriptionText) { logInfo "${d.descriptionText}" }
            sendEvent(d)
        }
    }
}

void handleDoorLockInvokeResponse(final Map descMap) {
    Integer invokeStatus = safeNumberToInt(descMap.status, null)
    Integer commandInt = safeNumberToInt(descMap.commandInt, null)
    String commandName = (commandInt != null) ? (DoorLockClusterCommands[commandInt] ?: 'UNKNOWN') : 'UNKNOWN'

    logDebug "handleDoorLockInvokeResponse: command=${commandName} (${commandInt}) status=${invokeStatus} data=${descMap.data} value=${descMap.value}"

    // The parent logs Interaction Model failures; the child also terminates matching local
    // pending operations immediately because no successful cluster response will follow.
    if (invokeStatus != 0) {
        handleDoorLockInvokeFailure(commandInt, invokeStatus)
        return
    }

    switch (commandInt) {
        case 0x1A: // SetUser (status-only success)
            processSetUserInvokeSuccess()
            break
        case 0x1C: // GetUserResponse
            processGetUserResponse(descMap)
            break
        case 0x1D: // ClearUser (status-only success)
            processClearUserInvokeSuccess()
            break
        case 0x23: // SetCredentialResponse
            processSetCredentialResponse(descMap)
            break
        case 0x25: // GetCredentialStatusResponse
            processGetCredentialStatusResponse(descMap)
            break
        case 0x26: // ClearCredential (status-only success)
            processClearCredentialInvokeSuccess()
            break
        default:
            // Commands such as LockDoor, UnlockDoor and UnboltDoor return
            // only the successful Invoke status. Attribute reports/events confirm device state.
            logDebug "handleDoorLockInvokeResponse: ${commandName} completed with no cluster response payload to process"
            break
    }
}

private void processClearCredentialInvokeSuccess() {
    if (state.isDeletingCode == true) {
        completePendingDeleteCode('ClearCredential Invoke response', true, null)
    } else {
        logDebug 'handleDoorLockInvokeResponse: ClearCredential completed with no pending deleteCode operation'
    }
}

private void handleDoorLockInvokeFailure(Integer commandInt, Integer invokeStatus) {
    String statusText = invokeStatus != null ? String.format('0x%02X', invokeStatus) : 'unknown'

    switch (commandInt) {
        case 0x1A: // SetUser request
            if (state.pendingSetUser instanceof Map) {
                finishMatterSetUser(false, "SetUser invoke failed with status ${statusText}")
            }
            break

        case 0x1B: // GetUser request
        case 0x1C: // Defensive: some platforms may identify the expected response command
            if (state.pendingClearUser instanceof Map && state.pendingClearUser.stage in ['awaitingPreflight', 'awaitingGetUser']) {
                String requestStage = state.pendingClearUser.stage == 'awaitingPreflight' ? 'preflight' : 'verification'
                finishMatterClearUser(false, "GetUser ${requestStage} invoke failed with status ${statusText}")
            } else if (state.pendingSetUser instanceof Map && state.pendingSetUser.stage in ['awaitingModifyPreflight', 'awaitingGetUser']) {
                String requestStage = state.pendingSetUser.stage == 'awaitingModifyPreflight' ? 'preflight' : 'verification'
                finishMatterSetUser(false, "GetUser ${requestStage} invoke failed with status ${statusText}")
            } else if (state.userScan?.active == true) {
                finishMatterUserScan("GetUser invoke failed with status ${statusText}", false)
            }
            break

        case 0x1D: // ClearUser request
            if (state.pendingClearUser instanceof Map) {
                finishMatterClearUser(false, "ClearUser invoke failed with status ${statusText}")
            }
            break

        case 0x24: // GetCredentialStatus request
        case 0x25: // Defensive: some platforms may identify the expected response command
            Map pending = state.pendingGetCredentialStatus instanceof Map ? state.pendingGetCredentialStatus as Map : null
            unschedule('matterGetCredentialStatusTimeout')
            state.remove('pendingGetCredentialStatus')
            if (pending != null) {
                Boolean scanMatches = state.credentialScan?.active == true &&
                    safeNumberToInt(state.credentialScan.credentialType, null) == safeNumberToInt(pending.credentialType, null) &&
                    safeNumberToInt(state.credentialScan.pendingCredentialIndex, null) == safeNumberToInt(pending.credentialIndex, null)
                if (scanMatches) {
                    finishMatterCredentialScan("${pending.credentialTypeName ?: 'credential'} #${pending.credentialIndex} failed with Invoke status ${statusText}", false)
                } else {
                    logWarn "matterGetCredentialStatus: ${pending.credentialTypeName ?: 'credential'} #${pending.credentialIndex} failed with Invoke status ${statusText}"
                }
            }
            break

        case 0x22: // SetCredential request
        case 0x23: // Defensive: expected response command
            Map pendingSet = state.pendingSetCredentialInvoke instanceof Map ? state.pendingSetCredentialInvoke as Map : null
            if (pendingSet != null) {
                String credentialKey = pendingSet.credentialKey != null ? "${pendingSet.credentialKey}" : null
                if (pendingSet.fromSetCode == true) {
                    clearSetCodeOperationState(credentialKey, true)
                    String descriptionText = "${device.displayName} setCode position ${credentialKey} failed with Matter Invoke status ${statusText}"
                    sendEvent(name: 'codeChanged', value: 'failed', descriptionText: descriptionText, isStateChange: true)
                    logWarn descriptionText
                } else {
                    state.remove('pendingSetCredentialInvoke')
                    logWarn "matterSetCredentialPIN: request failed with Matter Invoke status ${statusText}"
                }
            }
            break

        case 0x26: // ClearCredential request
            if (state.isDeletingCode == true) {
                Integer codePosition = safeToInt(state.lastDeleteCode?.codePosition)
                state.isDeletingCode = false
                unschedule('clearDeletingCodeFlagOnTimeout')
                state.remove('lastDeleteCode')
                state.remove('recentClearCredentialConfirmation')
                String descriptionText = "${device.displayName} deleteCode position ${codePosition} failed with Matter Invoke status ${statusText}"
                sendEvent(name: 'codeChanged', value: 'failed', descriptionText: descriptionText, isStateChange: true)
                logWarn descriptionText
            } else if (state.isOverwritingCode == true) {
                Integer codePosition = safeToInt(state.overwriteSlot)
                clearSetCodeOperationState("${codePosition}", true)
                String descriptionText = "${device.displayName} setCode overwrite at position ${codePosition} failed while clearing the old credential (Matter Invoke status ${statusText})"
                sendEvent(name: 'codeChanged', value: 'failed', descriptionText: descriptionText, isStateChange: true)
                logWarn descriptionText
            }
            break
    }
}

void handleLockMessage(Map description) {
    //logDebug "handleLockMessage: description = ${description}"
    Map descMap =[:]
    try {
        descMap = description.value as Map
    }
    catch (e) {
        logWarn "handleLockMessage: exception ${e} while parsing description.value = ${description.value}"
        return
    }
    logDebug "handleLockMessage: parsed descMap = ${descMap}"
    if (descMap.cluster != '0101') { logWarn "handleLockMessage: unexpected cluster:${descMap.cluster} (attrId:${descMap.attrId})"; return }

    // Check if this is an event (has evtId) or an attribute (has attrId)
    if (descMap.evtId != null) {
        if (isDuplicateDoorLockEvent(descMap)) {
            logDebug "handleLockMessage: filtered duplicated Door Lock event evtId=${descMap.evtId}, eventSerial=${descMap.eventSerial}"
            return
        }
        processDoorLockEvent(descMap)
        return
    }
    // else - process attribute report
    processDoorLockAttributeReport(descMap)
}

// Maps Door Lock cluster attrId → state.lockAttr key for automatic raw-integer storage.
// All values are stored as Integer via safeHexToInt(descMap.value).
// Excluded: 0000 LockState (lives in 'lock' attribute), 0021 Language (String, handled explicitly),
//           0042-0047 event masks (verbose), 0080-0088 Nuki non-standard,
//           FFFC/FFFB/FFFD/FFF8/FFF9 (already in fingerprintData).
@Field static final Map<String, String> LOCK_ATTR_STORE = [
    // Group A — core device characteristics
    '0001': 'lockType',                 '0002': 'actuatorEnabled',          '0003': 'doorState',
    '0011': 'numberOfTotalUsers',       '0012': 'numberOfPINUsers',
    '0017': 'maxPINCodeLength',         '0018': 'minPINCodeLength',
    '001B': 'credentialRulesSupport',   '001C': 'numberOfCredentialsPerUser',
    '0025': 'operatingMode',            '0026': 'supportedOperatingModes',
    '0030': 'wrongCodeEntryLimit',      '0031': 'userCodeTempDisableTime',
    '0033': 'requirePINforRemoteOp',
    // Group B — optional configuration
    '0004': 'doorOpenEvents',           '0005': 'doorClosedEvents',         '0006': 'openPeriod',
    '0010': 'numberOfLogRecords',       '0013': 'numberOfRFIDUsers',
    '0014': 'weekDaySchedulesPerUser',  '0015': 'yearDaySchedulesPerUser',  '0016': 'numberOfHolidaySchedules',
    '0019': 'maxRFIDCodeLength',        '001A': 'minRFIDCodeLength',
    '0020': 'enableLogging',
    '0022': 'ledSettings',              '0023': 'autoRelockTime',           '0024': 'soundVolume',
    '0027': 'defaultConfigRegister',
    '0028': 'enableLocalProgramming',   '0029': 'enableOneTouchLocking',
    '002A': 'enableInsideStatusLED',    '002B': 'enablePrivacyModeButton',  '002C': 'localProgrammingFeatures',
    '0032': 'sendPINoverTheAir',        '0034': 'securityLevel',            '0035': 'expiringUserTimeout',
]

void processDoorLockAttributeReport(Map descMap) {
    if (state.lockAttr == null) { state.lockAttr = [:] }
    String eventValue = descMap.value
    String descriptionText = "${device.displayName} ${descMap.cluster}:${descMap.attrId} value:${eventValue}"
    
    // Declare variables for conditional logging
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${descMap.attrId}] " : ""
    String message = null
    boolean useDebugLog = false  // Flag to use logDebug instead of logInfo when isInfoMode is false
    
    switch (descMap.attrId) {
        case '0000': // LockState
            // LockState is typically handled by parent driver
            // But log it here for debugging if it arrives
            String lockStateText = DoorLockClusterLockState[safeHexToInt(descMap.value)] ?: "Unknown (${descMap.value})"
            message = "${prefix}LockState: ${lockStateText} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0001': // LockType
            eventValue = DoorLockClusterLockType[safeHexToInt(descMap.value)]
            message = "${prefix}lockType: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0002': // ActuatorEnabled
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}ActuatorEnabled: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0003': // DoorState
            Integer doorStateValue = safeHexToInt(descMap.value)
            eventValue = DoorLockClusterDoorState[doorStateValue] ?: "Unknown/OutOfSpec"
            if (doorStateValue > 0x05) {
                message = "${prefix}DoorState: ${eventValue} (raw:0x${descMap.value} - value out of spec 0x00-0x05)"
            } else {
                descriptionText = "${device.displayName} DoorState: ${eventValue} (raw:${descMap.value})"
                //sendEvent(name: 'doorState', value: eventValue, descriptionText: descriptionText)
                message = "${prefix}DoorState: ${eventValue} (raw:${descMap.value})"
            }
            useDebugLog = true
            break
        case '0004': // DoorOpenEvents
            Integer doorOpenEvents = safeHexToInt(descMap.value)
            message = "${prefix}DoorOpenEvents: ${doorOpenEvents}"
            break
        case '0005': // DoorClosedEvents
            Integer doorClosedEvents = safeHexToInt(descMap.value)
            message = "${prefix}DoorClosedEvents: ${doorClosedEvents}"
            break
        case '0006': // OpenPeriod
            Integer openPeriod = safeHexToInt(descMap.value)
            message = "${prefix}OpenPeriod: ${openPeriod} minutes"
            break
        case '0010': // NumberOfLogRecordsSupported
            message = processNumericAttribute('NumberOfLogRecordsSupported', descMap)
            break
        case '0011': // NumberOfTotalUsersSupported
            message = processNumericAttribute('NumberOfTotalUsersSupported', descMap)
            sendEvent(name: 'maxCodes', value: safeHexToInt(descMap.value), descriptionText: "${device.displayName} supports up to ${safeHexToInt(descMap.value)} total users")
            break
        case '0012': // NumberOfPINUsersSupported
            message = processNumericAttribute('NumberOfPINUsersSupported', descMap)
            break
        case '0013': // NumberOfRFIDUsersSupported
            message = processNumericAttribute('NumberOfRFIDUsersSupported', descMap)
            break
        case '0014': // NumberOfWeekDaySchedulesSupportedPerUser
            message = processNumericAttribute('NumberOfWeekDaySchedulesSupportedPerUser', descMap)
            break
        case '0015': // NumberOfYearDaySchedulesSupportedPerUser
            message = processNumericAttribute('NumberOfYearDaySchedulesSupportedPerUser', descMap)
            break
        case '0016': // NumberOfHolidaySchedulesSupported
            message = processNumericAttribute('NumberOfHolidaySchedulesSupported', descMap)
            break
        case '0017': // MaxPINCodeLength
            Integer maxPinLength = safeHexToInt(descMap.value)
            descriptionText = "${device.displayName} maximum PIN code length is ${maxPinLength}"
            sendEvent(name: 'codeLength', value: maxPinLength, type: 'physical', descriptionText: descriptionText)
            message = "${prefix}MaxPINCodeLength: ${maxPinLength}"
            break
        case '0018': // MinPINCodeLength
            Integer minPinLength = safeHexToInt(descMap.value)
            message = "${prefix}MinPINCodeLength: ${minPinLength}"
            break
        case '0019': // MaxRFIDCodeLength
            message = processNumericAttribute('MaxRFIDCodeLength', descMap)
            break
        case '001A': // MinRFIDCodeLength
            message = processNumericAttribute('MinRFIDCodeLength', descMap)
            break
        case '001B': // CredentialRulesSupport
            Integer credRules = safeHexToInt(descMap.value)
            String credRulesText = decodeCredentialRules(credRules)
            message = "${prefix}CredentialRulesSupport: ${credRulesText} (0x${descMap.value})"
            break
        case '001C': // NumberOfCredentialsSupportedPerUser
            message = processNumericAttribute('NumberOfCredentialsSupportedPerUser', descMap)
            break
        case '0020': // EnableLogging
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableLogging: ${eventValue} (raw:${descMap.value})"
            break
        case '0021': // Language
            String language = descMap.value instanceof List ? descMap.value.join('') : descMap.value
            state.lockAttr['language'] = language
            message = "${prefix}Language: ${language}"
            break
        case '0022': // LEDSettings
            Integer ledSettings = safeHexToInt(descMap.value)
            message = "${prefix}LEDSettings: 0x${descMap.value}"
            break
        case '0023': // AutoRelockTime
            Integer autoRelockTime = safeHexToInt(descMap.value)
            message = "${prefix}AutoRelockTime: ${autoRelockTime} seconds"
            break
        case '0024': // SoundVolume
            Integer soundVolume = safeHexToInt(descMap.value)
            message = "${prefix}SoundVolume: ${soundVolume}"
            break
        case '0025' : // OperatingMode
            // OperatingMode: 00 (raw:00)
            eventValue = DoorLockClusterOperatingModeEnum[safeHexToInt(descMap.value)]
            message = "${prefix}OperatingMode: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0026' : // SupportedOperatingModes
            // SupportedOperatingModes: FFF6 (raw:FFF6)
            Integer intValue = safeHexToInt(descMap.value)
            List<String> supportedModes = []
            // Iterate through each bit position and check if the corresponding bit in eventValue is set to 0
            DoorLockClusterSupportedOperatingModes.each { bitPosition, modeName ->
                if ((intValue & (1 << bitPosition)) == 0) { supportedModes.add(modeName) }
            }
            String supportedModesString = supportedModes.join(', ')
            state.lockAttr['supportedOperatingModes'] = supportedModesString    // decoded string kept for display (raw bitmap stored by generic block below)
            message = "${prefix}SupportedOperatingModes: ${supportedModesString} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0027': // DefaultConfigurationRegister
            message = "${prefix}DefaultConfigurationRegister: 0x${descMap.value}"
            break
        case '0028': // EnableLocalProgramming
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableLocalProgramming: ${eventValue} (raw:${descMap.value})"
            break
        case '0029': // EnableOneTouchLocking
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableOneTouchLocking: ${eventValue} (raw:${descMap.value})"
            break
        case '002A': // EnableInsideStatusLED
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableInsideStatusLED: ${eventValue} (raw:${descMap.value})"
            break
        case '002B': // EnablePrivacyModeButton
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnablePrivacyModeButton: ${eventValue} (raw:${descMap.value})"
            break
        case '002C': // LocalProgrammingFeatures
            message = "${prefix}LocalProgrammingFeatures: 0x${descMap.value}"
            break
        case '0030': // WrongCodeEntryLimit
            Integer wrongCodeLimit = safeHexToInt(descMap.value)
            message = "${prefix}WrongCodeEntryLimit: ${wrongCodeLimit}"
            break
        case '0031': // UserCodeTemporaryDisableTime
            Integer disableTime = safeHexToInt(descMap.value)
            message = "${prefix}UserCodeTemporaryDisableTime: ${disableTime} seconds"
            break
        case '0032': // SendPINOverTheAir
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}SendPINoverTheAir: ${eventValue} (raw:${descMap.value})"
            break
        case '0033': // RequirePINforRemoteOperation
            eventValue = descMap.value == '01' ? 'required' : 'not required'
            message = "${prefix}RequirePINforRemoteOperation: ${eventValue} (raw:${descMap.value})"
            break
        case '0034': // SecurityLevel (Deprecated)
            Integer securityLevel = safeHexToInt(descMap.value)
            String securityLevelName = ['Unspecified', 'Low', 'Medium', 'High'][securityLevel] ?: "Unknown(${securityLevel})"
            message = "${prefix}SecurityLevel: ${securityLevelName} (deprecated, raw:${descMap.value})"
            break
        case '0035': // ExpiringUserTimeout
            Integer expiringUserTimeout = safeHexToInt(descMap.value)
            message = "${prefix}ExpiringUserTimeout: ${expiringUserTimeout} minutes"
            break
        case '0042': // RemoteOperationEventMask
            message = processEventMaskAttribute('0042', 'RemoteOperationEventMask', descMap, this.&decodeRemoteOperationEventMask)
            useDebugLog = true
            break
        case '0043': // ManualOperationEventMask
            message = processEventMaskAttribute('0043', 'ManualOperationEventMask', descMap, this.&decodeManualOperationEventMask)
            useDebugLog = true
            break
        case '0044': // RFIDOperationEventMask
            message = processEventMaskAttribute('0044', 'RFIDOperationEventMask', descMap, this.&decodeRFIDOperationEventMask)
            useDebugLog = true
            break
        case '0045': // KeypadProgrammingEventMask
            message = processEventMaskAttribute('0045', 'KeypadProgrammingEventMask', descMap, this.&decodeKeypadProgrammingEventMask)
            // NOTE: Nuki disables PINCleared (0x08) and PINChanged (0x10) events
            // This means PIN deletion/modification events won't be received automatically
            useDebugLog = true
            break
        case '0046': // RemoteProgrammingEventMask
            message = processEventMaskAttribute('0046', 'RemoteProgrammingEventMask', descMap, this.&decodeRemoteProgrammingEventMask)
            useDebugLog = true
            break
        case '0047': // RFIDProgrammingEventMask
            message = processEventMaskAttribute('0047', 'RFIDProgrammingEventMask', descMap, this.&decodeRFIDProgrammingEventMask)
            useDebugLog = true
            break
        case '0080': // Nuki non-standard attribute (spec=0x40 AlarmMask)
        case '0081': // Nuki non-standard attribute (spec=0x41 KeypadOperationEventMask)
        case '0082': // Nuki non-standard attribute (spec=0x42 RemoteOperationEventMask)
        case '0083': // Nuki non-standard attribute (spec=0x43 ManualOperationEventMask)
        case '0087': // Nuki non-standard attribute (spec=0x44 RFIDOperationEventMask)
        case '0088': // Nuki non-standard attribute (spec=0x45 KeypadProgrammingEventMask)
            message = "${prefix} UNKNOWN Nuki non-standard attribute 0x${descMap.attrId}: ${descMap.value}"
            break
        case 'FFFC': // FeatureMap
            Integer featureMap = safeHexToInt(descMap.value)
            String featuresText = decodeFeatureMap(featureMap)
            // FeatureMapRaw is stored in fingerprintData as '0101_FFFC'
            message = "${prefix}FeatureMap: ${featuresText} (0x${descMap.value})"
            break
        case 'FFFB': // AttributeList
            // AttributeList is stored in fingerprintData, no need to store separately
            List fffbList = descMap.value instanceof List ? descMap.value : [descMap.value]
            String fffbNames = fffbList.collect { String h -> DoorLockClusterAttributes[safeHexToInt(h)] ?: '?' }.join(', ')
            message = "${prefix}AttributeList: ${fffbList} ${fffbNames}"
            useDebugLog = true
            break
        case 'FFFD': // ClusterRevision
            Integer revision = safeHexToInt(descMap.value)
            message = "${prefix}ClusterRevision: ${revision}"
            break
        case 'FFF8': // GeneratedCommandList - stored in fingerprintData only
            List fff8List = descMap.value instanceof List ? descMap.value : [descMap.value]
            String fff8Names = fff8List.collect { String h -> DoorLockClusterCommands[safeHexToInt(h)] ?: '?' }.join(', ')
            message = "${prefix}GeneratedCommandList:  ${fff8List}  ${fff8Names}"
            useDebugLog = true
            // Data is in fingerprintData['0101_FFF8'], no duplicate storage needed
            break
        case 'FFF9': // AcceptedCommandList - stored in fingerprintData only
            List fff9List = descMap.value instanceof List ? descMap.value : [descMap.value]
            String fff9Names = fff9List.collect { String h -> DoorLockClusterCommands[safeHexToInt(h)] ?: '?' }.join(', ')
            message = "${prefix}AcceptedCommandList:  ${fff9List}  ${fff9Names}"
            useDebugLog = true
            // Data is in fingerprintData['0101_FFF9'], no duplicate storage needed
            break
        default:
            // Check for command responses
            Map responseValues = (descMap.value instanceof Map) ? (descMap.value as Map) : [:]
            if (descMap.cmdId == '25' || descMap.commandInt == 0x25 || responseValues.containsKey('credentialExists')) {
                processGetCredentialStatusResponse(descMap)
            } else if (descMap.cmdId == '1C' || descMap.commandInt == 0x1C || responseValues.containsKey('userName')) {
                processGetUserResponse(descMap)
            } else {
                logWarn "handleLockMessage: unexpected attrId:${descMap.attrId}"
            }
            break
    }
    
    // Store raw integer for every attribute listed in LOCK_ATTR_STORE before
    // info-mode buffering can return while waiting for the remaining reports.
    // Language (0021) is handled explicitly above; all mapped values are numeric.
    String lockAttrKey = LOCK_ATTR_STORE[descMap.attrId]
    if (lockAttrKey != null) {
        state.lockAttr[lockAttrKey] = safeHexToInt(descMap.value)
    }

    // Conditional logging after the switch
    if (message != null) {
        if (isInfoMode) {
            // Accumulate into buffer; flush when all expected attrs have arrived
            state.states.infoBuffer = (state.states?.infoBuffer ?: []) + [message]
            List<String> remaining = state.states?.infoExpectedAttrs ?: []
            remaining.remove(descMap.attrId)
            state.states.infoExpectedAttrs = remaining
            if (!remaining.isEmpty()) { return }  // still waiting for more attrs
            flushInfoBuffer()   // all expected attrs received
            return
        } else {
            if (useDebugLog) {
                logDebug message
            } else {
                logInfo message
            }
        }
    }
}


// -------------------------------- Hubitat commands wrappers ----------------------------------
//
// Hubitat Attributes  : lockCodes
//                       codeChanged - ENUM ["added", "changed", "deleted", "failed"]
//                       codeLength
//                       maxCodes 
// Hubitat Commands    : setCode(pos,pin,name), deleteCode(pos), getCodes(), setCodeLength(len)

// Hubitat wrap for setUser
void setCode(codePosition, pinCode, name = null) {
    if (state.pendingClearUser instanceof Map) {
        logWarn "setCode: ClearUser is active for user ${state.pendingClearUser.userIndex}; request ignored"
        return
    }
    if (!supportsLockCodes()) {
        logWarn "setCode: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }

    if (state.isSettingCode == true) {
        logDebug "setCode: Previous setCode operation is still in progress, command setCode(${codePosition}, ${pinCode}, ${name}) ignored."
        return
    }

    // Hubitat Lock Code Manager app will call setCode with codePosition, pinCode and name, and expects to see the result in the device attributes.
    // setCode() will be called up to 10 times, 4 second apart!
    // we need to prevent calling setCode again until the job is done!
    // The timeout is cancelled when SetCredentialResponse or LockUserChange confirms the operation.
    state.isSettingCode = true
    ensureLockCodeStateMaps()
    state.remove('recentSetCredentialConfirmation')
    // Keep the requested PIN/name keyed by credential slot until a response or event confirms it.
    state.pendingSetByCredential["${codePosition}"] = [requestedAt: now(), pinCode: pinCode, name: name]

    runIn(SET_CODE_TIMEOUT_SECONDS, "clearSettingCodeFlagOnTimeout", [overwrite: true])     // 45 seconds !

    // a non-standard codeChanged value - just for better logging and debugging
    String descriptionText = "${device.displayName} setCode: setting code ${codePosition} to ${pinCode} for lock code name ${name}"
    sendEvent(name: 'codeChanged', value: "setting", descriptionText: descriptionText, isStateChange: true)
    logInfo descriptionText

    if (settings?.overwriteCodes) {
        state.isOverwritingCode = true
        state.overwriteSlot = codePosition
        logDebug "setCode: overwriteCodes=true — clearing existing credential at slot ${codePosition} before adding"
        matterClearCredential(1, codePosition)
        runIn(OVERWRITE_CLEAR_TIMEOUT_SECONDS, 'proceedWithOverwriteAdd', [overwrite: true])  // fallback if slot was empty (no Clear event)
    } else {
        matterSetCredentialPIN(codePosition, pinCode)
    }
    // lockCodes and codeChanged are updated from SetCredentialResponse, with LockUserChange as fallback.
}   


/**
 * Delete a PIN code (LockCodes capability)
 * @param codePosition Position/slot number (1-based)
 */
void deleteCode(codePosition) {
    logInfo "deleteCode: codePosition=${codePosition}"
    if (state.pendingClearUser instanceof Map) {
        logWarn "deleteCode: ClearUser is active for user ${state.pendingClearUser.userIndex}; request ignored"
        return
    }
    if (!supportsLockCodes()) {
        String msg = "${device.displayName} deleteCode: code position ${codePosition} failed - lock does not support PIN credential management"
        logInfo "deleteCode: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'codeChanged', value: 'failed', descriptionText: msg, isStateChange: true)
        return
    }
    
    state.isDeletingCode = true
    state.remove('recentClearCredentialConfirmation')
    state.lastDeleteCode = [codePosition: codePosition, timestamp: now()]
    runIn(DELETE_TIMEOUT_SECONDS, 'clearDeletingCodeFlagOnTimeout', [overwrite: true])

    String descriptionText = "${device.displayName} deleteCode: deleting code at position ${codePosition}"
    logInfo descriptionText
    sendEvent(name: 'codeChanged', value: 'deleting', descriptionText: descriptionText, isStateChange: true)

    matterClearCredential(1, codePosition)
    // The successful Invoke callback normally confirms this immediately. LockUserChange remains
    // a fallback for platforms without callbacks, and the timeout handles locks that emit neither.
}


/**
 * Get all PIN codes (LockCodes capability)
 * Called by HE Lock Code Manager app on 'Request lock codes from all existing devices'
 */
void getCodes() {
    if (!supportsLockCodes()) {
        logWarn "getCodes: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }
    // Re-send the current lockCodes attribute with isStateChange:true so Hubitat Lock Code Manager
    // receives and processes the codes we already have stored locally.
    // Full Matter-based querying (GetUser loop) is not yet implemented.
    String currentCodes = device.currentValue('lockCodes') ?: '{}'
    logInfo "getCodes: re-sending current lockCodes: ${currentCodes}"
    sendEvent(name: 'lockCodes', value: currentCodes, descriptionText: "${device.displayName} getCodes: re-sending current lock codes", isStateChange: true)
}

// Command to set the maximum PIN code length for this lock (per Hubitat LockCodes capability)
// NOTE: Matter locks have FIXED PIN length constraints (MaxPINCodeLength/MinPINCodeLength are read-only)
// This command only updates the Hubitat codeLength attribute for compatibility
void setCodeLength(BigDecimal length) {
    if (!length) {
        logWarn "setCodeLength: PIN code length is required"
        return
    }
    Integer codeLength = length.toInteger()
    if (codeLength < 4 || codeLength > 8) {
        logWarn "setCodeLength: PIN code length must be 4-8 digits, got '${length}'"
        return
    }
    
    logInfo "setCodeLength: updating Hubitat codeLength attribute to ${codeLength} (Matter locks have fixed PIN length constraints)"
    
    // Update codeLength attribute with digital event type for Hubitat compatibility
    sendEvent(name: 'codeLength', value: codeLength, type: 'digital', descriptionText: "${device.displayName} code length set to ${codeLength}")
}

// -------- Hubitat code wrappers helpers ---------

// Fallback: fires if no LockUserChange(Clear) was received (slot was empty or lock ignored the Clear)
void proceedWithOverwriteAdd() {
    if (state.isOverwritingCode != true) { return }  // already handled by the LockUserChange(Clear) event
    state.isOverwritingCode = false
    // Use state.overwriteSlot as authoritative source — avoids stale/wrong entries from entrySet() iteration order
    Integer slot = safeToInt(state.overwriteSlot)
    String slotKey = "${slot}"
    Map pendingEntry = slot > 0 ? state.pendingSetByCredential?.get(slotKey) : null
    if (slot > 0 && pendingEntry != null) {
        logDebug "proceedWithOverwriteAdd: no Clear event received (slot ${slot} was empty) — proceeding with Add"
        matterSetCredentialPIN(slot as BigDecimal, pendingEntry.pinCode)
    } else {
        logWarn "proceedWithOverwriteAdd: no pending data for slot ${slot} — aborting overwrite"
        clearSetCodeOperationState(slotKey, true)
        sendEvent(name: 'codeChanged', value: 'failed', descriptionText: "${device.displayName} setCode overwrite: no pending data for slot ${slot}", isStateChange: true)
    }
}

void clearSettingCodeFlagOnTimeout() {
    state.isSettingCode = false
    state.isOverwritingCode = false
    unschedule('proceedWithOverwriteAdd')
    state.pendingSetByCredential = [:]   // clear stale entries so they don't interfere with the next setCode operation
    state.remove('pendingSetCredentialInvoke')
    state.remove('overwriteSlot')
    logDebug "clearSettingCodeFlagOnTimeout: isSettingCode flag cleared (timed out after ${SET_CODE_TIMEOUT_SECONDS} seconds)"
    String descriptionText = "${device.displayName} setCode operation timed out without confirmation from lock (no codeChanged event received)"
    sendEvent(name: 'codeChanged', value: "failed", descriptionText: descriptionText, isStateChange: true)
    logWarn descriptionText
}

void clearDeletingCodeFlagOnTimeout() {
    if (state.isDeletingCode != true) { return }
    completePendingDeleteCode('timeout fallback', false, null)
}

private void completePendingDeleteCode(String source, Boolean confirmed, String eventDescription) {
    if (state.isDeletingCode != true) { return }

    Integer codePosition = safeToInt(state.lastDeleteCode?.codePosition)
    String credentialKey = codePosition != null ? "${codePosition}" : null
    Map existingEntry = credentialKey != null ? (getLockCodes()[credentialKey] ?: [:]) : [:]
    ensureLockCodeStateMaps()
    Map existingMeta = credentialKey != null && state.codeMetaByCredential[credentialKey] instanceof Map ?
        new HashMap(state.codeMetaByCredential[credentialKey] as Map) : [:]
    Integer userIndex = safeToInt(existingMeta.userIndex, null)

    state.isDeletingCode = false
    unschedule('clearDeletingCodeFlagOnTimeout')
    state.remove('lastDeleteCode')

    if (codePosition != null) {
        removeLockCode(codePosition)
        removeCredentialMeta(credentialKey)
    }

    Map codeData = credentialKey != null ? [(credentialKey): existingEntry] : [:]
    def eventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(codeData)) : codeData
    String descriptionText = eventDescription ?: (confirmed ?
        "${device.displayName} deleteCode position ${codePosition} confirmed by ${source}" :
        "${device.displayName} deleteCode: no confirmation received from lock (position ${codePosition}) — assuming deleted")
    logLockCodeEventPayload('codeChanged', 'deleted', codeData)
    sendEvent(name: 'codeChanged', value: 'deleted', data: eventData, descriptionText: descriptionText, isStateChange: true)

    state.recentClearCredentialConfirmation = [
        credentialKey: credentialKey,
        userIndex: userIndex,
        confirmedAt: now(),
        source: source
    ]
    if (confirmed) {
        logInfo "deleteCode: position ${codePosition} confirmed by ${source}"
    } else {
        logWarn descriptionText
    }
}

// ------- Matter command implementations -------

void identify() {
    List<String> serverList = getFingerprintData()?.get('ServerList') ?: []
    if (!serverList.contains('0003')) {
        logWarn "Identify command not supported: Cluster 0003 not present in ServerList"
        return
    }
    logInfo "identifying ..."
    parent?.componentIdentify(device)
}

// 5.2.10.1. LockDoor Command (0x00)
// This command causes the lock device to lock the door. This command includes an optional code for the lock. The door lock MAY require a PIN depending on the value of the RequirePINForRemoteOperation attribute.
void lock() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    //sendEvent(name: 'lock', value: 'locking', descriptionText: "${device.displayName} is locking...", type: 'digital')
    logInfo "locking..."
    parent?.componentLog(device, 'debug', 'locking...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x00, 2000)
    parent?.sendToDevice(cmd)
}

// 5.2.10.2. UnlockDoor Command (0x01)
// This command causes the lock device to unlock the door. This command includes an optional code for the lock. The door lock MAY require a code depending on the value of the RequirePINForRemoteOperation attribute.
void unlock() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    //sendEvent(name: 'lock', value: 'unlocking', descriptionText: "${device.displayName} is unlocking...", type: 'digital')
    logInfo "unlocking..."
    parent?.componentLog(device, 'debug', 'unlocking...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x01, 2000)
    parent?.sendToDevice(cmd)
}

// 5.2.10.3. UnlockWithTimeout Command (0x03)
// This command causes the lock device to unlock the door, then automatically relock after the given timeout.
void unlockWithTimeout(BigDecimal timeoutSeconds) {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    Integer timeout = timeoutSeconds?.intValue()
    if (timeout == null || timeout < 1 || timeout > 65535) {
        logWarn "unlockWithTimeout: timeout must be 1..65535 seconds, got '${timeoutSeconds}'"
        return
    }
    if (!isDoorLockCommandSupported('0003') && settings?.ignoreCompatibilityChecks != true) {
        logWarn 'unlockWithTimeout: This lock does not support UnlockWithTimeout (0x0003 not in AcceptedCommandList). Enable \'Ignore Compatibility Checks\' to force.'
        return
    }
    String timeoutHexLE = zigbee.swapOctets(HexUtils.integerToHexString(timeout, 2))
    String tlv = '15' + '25' + '00' + timeoutHexLE + '18'
    state.lastCmdIsTimeout = true
    logInfo "unlocking with timeout ${timeout} seconds..."
    parent?.componentLog(device, 'debug', "unlocking with timeout ${timeout}s...")
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x03, 2000, tlv)
    parent?.sendToDevice(cmd)
}

// 5.2.10.4. UnboltDoor Command (0x27)
// This command causes the lock device to retract the bolt (unlatch) without fully unlocking.
// Requires the UBOLT feature (FEATURE_UNBOLT bit in FeatureMap).
void unboltDoor() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    if (!isFeatureEnabled(FEATURE_UNBOLT) && settings?.ignoreCompatibilityChecks != true) {
        logWarn 'unboltDoor: This lock does not support the Unbolt feature (FEATURE_UNBOLT / bit 12 not set in FeatureMap). Enable \'Ignore Compatibility Checks\' to force.'
        return
    }
    logInfo 'unbolting...'
    parent?.componentLog(device, 'debug', 'unbolting...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x27, 2000)
    parent?.sendToDevice(cmd)
}


// 5.2.10.42 SetCredential Command (0x22)
// Implemented for PIN only (credentialType = 1)
//
// Usage examples:
//   matterSetCredentialPIN(1, "1234")           // set PIN in credential slot 1 (userIndex null)
//   matterSetCredentialPIN(1, "1234", 1)        // set PIN in credential slot 1 and associate to userIndex 1
//
// Notes:
// - credentialIndex is usually 1..NumberOfPINUsersSupported (often 1..10 for U200)
// - userIndex is often the same as credentialIndex for many locks (but not always)
// - operationType = 0 (Add)
// 
// WORKING !! :) 
//
void matterSetCredentialPIN(BigDecimal credentialIndexPar, String pinCode, BigDecimal userIndexPar = null) {
    if (state.pendingClearUser instanceof Map) {
        logWarn "matterSetCredentialPIN: ClearUser is active for user ${state.pendingClearUser.userIndex}; request ignored"
        return
    }
    if (!supportsLockCodes()) {
        logWarn "matterSetCredentialPIN: This lock <b>does not</b> support PIN/User management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Lock does not support PIN/User management", isStateChange: true)
        return
    }

    if (credentialIndexPar == null) {
        logWarn "matterSetCredentialPIN: credential index is required"
        return
    }
    Integer credentialIndex = credentialIndexPar.intValue()
    if (credentialIndex < 1 || credentialIndex > 255) {
        logWarn "matterSetCredentialPIN: credential index must be 1..255, got '${credentialIndex}'"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Invalid credential index ${credentialIndex}", isStateChange: true)
        return
    }

    if (!pinCode) {
        logWarn "matterSetCredentialPIN: pinCode is required"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Missing pinCode", isStateChange: true)
        return
    }

    // Basic sanity (you can relax this if your lock supports other lengths)
    if (pinCode.size() < 4 || pinCode.size() > 8) {
        logWarn "matterSetCredentialPIN: pinCode length must be 4..8 digits, got ${pinCode.size()}"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Invalid PIN length", isStateChange: true)
        return
    }

    Integer userIndex = (userIndexPar != null) ? userIndexPar.intValue() : null
    if (userIndex != null && (userIndex < 1 || userIndex > 65534)) {
        logWarn "matterSetCredentialPIN: userIndex must be 1..65534 (or null), got '${userIndex}'"
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "Invalid userIndex ${userIndex}", isStateChange: true)
        return
    }

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) {
        sendEvent(name: 'codeChanged', value: "failed", descriptionText: "deviceNumber is null", isStateChange: true)
        return
    }

    // ---- Build TLV ----
    // operationType enum8 (tag 0): Add=0
    String opTypeHex = "00" // "00" for Add, "01" for Clear, "02" for Modify

    // credential struct (tag 1)
    //   tag0: credentialType enum8 = 1 (PIN)
    //   tag1: credentialIndex uint16 LE
    String credTypeHex = "01"
    String credIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(credentialIndex, 2))  // 1 -> 0100

    // credentialData octet string (tag 2): bytes of PIN ASCII/UTF-8
    byte[] pinBytes = pinCode.getBytes('UTF-8')
    int pinLen = pinBytes.length
    String pinHex = pinBytes.collect { String.format('%02X', it) }.join()

    // Encode credentialData as ByteString1/2 (octet string), context tag 2
    // Context(1-byte) control for ByteString1 is 0x30, for ByteString2 is 0x31 (matches your UTF8 0x2C/0x2D logic)

    // credentialData octet string (tag 2) encoded as OctetString2
    // 0x31 = context-specific octet string with 2-byte length
    String lenHexLE = zigbee.swapOctets(HexUtils.integerToHexString(pinLen, 2))
    String credentialDataTlv = "31" + "02" + lenHexLE + pinHex

    // userIndex nullable uint16 (tag 3)
    String userIndexTlv
    if (userIndex == null) {
        // NULL: control 0x34 (context + null), tag 3
        userIndexTlv = "34" + "03"
    } else {
        String userIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userIndex, 2))
        // uint16: control 0x25 (context + uint16), tag 3
        userIndexTlv = "25" + "03" + userIndexHexLE
    }

    // userStatus nullable enum8 (tag 4)
    // SmartThings sends OCCUPIED_ENABLED, not NULL
    String userStatusTlv = "24" + "04" + "01"

    // userType nullable enum8 (tag 5)
    // SmartThings sends UNRESTRICTED_USER, not NULL
    String userTypeTlv = "24" + "05" + "00"

    // Credential struct field (tag 1): control 0x35 (context + struct), tag 1
    // Follow the same working pattern as matterClearCredential(): NO extra inner "15" here.
    String credentialStructField =
            "35" + "01" +
                "24" + "00" + credTypeHex +
                "25" + "01" + credIndexHexLE +
            "18"

    // Full command struct
    String tlv =
            "15" +
                "24" + "00" + opTypeHex +   // tag0 operationType
                credentialStructField +      // tag1 credential struct
                credentialDataTlv +          // tag2 credentialData (octet string)
                userIndexTlv +               // tag3 userIndex (nullable)
                userStatusTlv +              // tag4 userStatus (nullable)
                userTypeTlv +                // tag5 userType (nullable)
            "18"

    // Use Hubitat invoke envelope (timed invoke)
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x0022, 2000, tlv)

    logDebug "matterSetCredentialPIN: credIndex=${credentialIndex}, userIndex=${userIndex}, pinLen=${pinLen}, credIndexHexLE=${credIndexHexLE}, tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "setting PIN credential slot ${credentialIndex}..." + (userIndex != null ? " (user ${userIndex})" : ""))

    ensureLockCodeStateMaps()
    String credentialKey = "${credentialIndex}"
    Boolean fromSetCode = state.isSettingCode == true && state.pendingSetByCredential?.containsKey(credentialKey)
    if (state.isSettingCode == true && !fromSetCode) {
        logWarn "matterSetCredentialPIN: another setCode operation is active; direct request for slot ${credentialIndex} ignored"
        return
    }
    state.pendingSetCredentialInvoke = [
        credentialKey: credentialKey,
        userIndex: userIndex,
        operationType: 0,
        sentAt: now(),
        fromSetCode: fromSetCode
    ]
    parent?.sendToDevice(cmd)

    // Hubitat platform 2.5.1.132+ exposes SetCredentialResponse 0x23 through callbackType:Invoke.
    // Older platforms continue to complete setCode from the later LockUserChange event.
} // matterSetCredentialPIN



// 5.2.10.44. ClearCredential Command (0x26)
// Clears a single credential, all credentials of one type, or all credentials of all types.
// Usage:
//   matterClearCredential()                  // Clear all credentials of all types
//   matterClearCredential(type)              // Clear all credentials of one type (type: CredentialTypeEnum)
//   matterClearCredential(type, index)       // Clear a single credential (type: CredentialTypeEnum, index: credential index)
//
// CredentialTypeEnum: 1=PIN, 2=RFID, 3=Fingerprint, 4=Face, etc. (ProgrammingPIN not allowed)
// For all credentials of a type: index = 0xFFFE
// For all credentials of all types: type = null, index = null
// For a single credential: type = credential type, index = credential index
//
// cmdFields: ID:0, Name:Credential, Type:CredentialStruct, Quality:desc, Conformance:Mandatory
//
// **** seems to work! :)
//
void matterClearCredential(BigDecimal credentialTypePar = null, BigDecimal credentialIndexPar = null) {
    if (state.pendingClearUser instanceof Map) {
        logWarn "matterClearCredential: ClearUser is active for user ${state.pendingClearUser.userIndex}; request ignored"
        return
    }
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn 'matterClearCredential: This lock does not support User management'
        return
    }
    List<String> acceptedCommands = getDoorLockAcceptedCommandList()
    if (settings?.ignoreCompatibilityChecks != true && !acceptedCommands.isEmpty() && !acceptedCommands.contains('0026')) {
        logWarn "matterClearCredential: command 0x26 is not present in this lock's AcceptedCommandList"
        return
    }

    Integer credentialType = credentialTypePar != null ? credentialTypePar.intValue() : null
    Integer credentialIndex = credentialIndexPar != null ? credentialIndexPar.intValue() : null
    if (credentialTypePar != null && credentialTypePar.compareTo(new BigDecimal(credentialType)) != 0) {
        logWarn "matterClearCredential: credential type must be a whole number, got '${credentialTypePar}'"
        return
    }
    if (credentialIndexPar != null && credentialIndexPar.compareTo(new BigDecimal(credentialIndex)) != 0) {
        logWarn "matterClearCredential: credential index must be a whole number, got '${credentialIndexPar}'"
        return
    }
    if (credentialType == 0) {
        logWarn 'matterClearCredential: ProgrammingPIN cannot be cleared'
        return
    }
    if (credentialType != null && (credentialType < 1 || credentialType > 8)) {
        logWarn "matterClearCredential: credential type must be 1-8, got '${credentialTypePar}'"
        return
    }
    if (credentialType == null && credentialIndex != null) {
        logWarn 'matterClearCredential: credential index cannot be supplied without a credential type'
        return
    }
    if (credentialIndex != null && (credentialIndex < 1 || credentialIndex > 65533)) {
        logWarn "matterClearCredential: credential index must be 1-65533, got '${credentialIndexPar}'"
        return
    }

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return

    String tlv
    String scopeText
    if (credentialType == null) {
        // Nullable mandatory Credential field = null: clear every credential except ProgrammingPIN.
        tlv = '15' + '34' + '00' + '18'
        scopeText = 'all credentials of all types'
    } else {
        // CredentialIndex 0xFFFE means every credential of the selected type.
        Integer encodedIndex = credentialIndex != null ? credentialIndex : 0xFFFE
        String typeHex = HexUtils.integerToHexString(credentialType, 1)
        String indexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(encodedIndex, 2))
        tlv =
            '15' +
                '35' + '00' +
                    '24' + '00' + typeHex +
                    '25' + '01' + indexHexLE +
                '18' +
            '18'
        String typeName = CredentialTypeEnum[credentialType] ?: "Unknown (${credentialType})"
        scopeText = credentialIndex != null
            ? "${typeName} credential #${credentialIndex}"
            : "all ${typeName} credentials"
    }

    String cmd = matter.invoke(deviceNumber, 0x0101, 0x0026, 2000, tlv)
    logInfo "matterClearCredential: clearing ${scopeText}"
    logDebug "matterClearCredential: type=${credentialType}, index=${credentialIndex}, tlv=${tlv}, cmd=${cmd}"
    parent?.sendToDevice(cmd)
}

// 5.2.10.34. SetUser Command (0x1A)
// Standalone diagnostic SetUser operations, verified with GetUser. They deliberately
// do not participate in Hubitat setCode/SetCredential processing.
void matterSetUser(BigDecimal userIndexPar, String userNamePar = null) {
    matterSetUserOperation(userIndexPar, userNamePar, 0)
}

// Modify only the supplied user name. GetUser is used first so the full existing
// record can be sent back; some locks (including the U200) mishandle null fields.
void matterModifyUser(BigDecimal userIndexPar, String userNamePar) {
    matterSetUserOperation(userIndexPar, userNamePar, 2)
}

private void matterSetUserOperation(BigDecimal userIndexPar, String userNamePar, Integer operationType) {
    String commandName = operationType == 2 ? 'matterModifyUser' : 'matterSetUser'
    String operationName = operationType == 2 ? 'Modify' : 'Add'
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "${commandName}: This lock does not support User management"
        return
    }

    List<String> acceptedCommands = getDoorLockAcceptedCommandList()
    if (settings?.ignoreCompatibilityChecks != true && !acceptedCommands.isEmpty() &&
        (!acceptedCommands.contains('001A') || !acceptedCommands.contains('001B'))) {
        List<String> missing = []
        if (!acceptedCommands.contains('001A')) { missing.add('SetUser 0x1A') }
        if (!acceptedCommands.contains('001B')) { missing.add('GetUser 0x1B') }
        logWarn "${commandName}: required command(s) not present in AcceptedCommandList: ${missing.join(', ')}"
        return
    }

    if (userIndexPar == null) {
        logWarn "${commandName}: User index is required"
        return
    }
    Integer userIndex = userIndexPar.intValue()
    if (userIndexPar.compareTo(new BigDecimal(userIndex)) != 0) {
        logWarn "${commandName}: User index must be a whole number, got '${userIndexPar}'"
        return
    }

    Integer maxUserIndex = safeNumberToInt(state.lockAttr?.numberOfTotalUsers, 65534)
    if (maxUserIndex == null || maxUserIndex < 1 || maxUserIndex > 65534) { maxUserIndex = 65534 }
    if (userIndex < 1 || userIndex > maxUserIndex) {
        logWarn "${commandName}: User index must be 1-${maxUserIndex}, got '${userIndexPar}'"
        return
    }

    String userName = userNamePar != null && !userNamePar.trim().isEmpty() ? userNamePar : null
    byte[] userNameBytes = userName != null ? userName.getBytes('UTF-8') : null
    if (operationType == 2 && userNameBytes == null) {
        logWarn "${commandName}: A non-blank user name is required for Modify"
        return
    }
    if (userNameBytes != null && userNameBytes.length > 10) {
        logWarn "${commandName}: User name must be at most 10 UTF-8 bytes, got ${userNameBytes.length}"
        return
    }

    Map existingPending = state.pendingSetUser instanceof Map ? state.pendingSetUser as Map : null
    if (existingPending != null) {
        Long startedAt = existingPending.startedAt != null ? existingPending.startedAt as Long : 0L
        if (startedAt > 0L && (now() - startedAt) <= (SET_USER_TIMEOUT_SECONDS * 2000L)) {
            logWarn "${commandName}: another SetUser operation is active for user ${existingPending.userIndex}"
            return
        }
        finishMatterSetUser(false, 'stale pending SetUser operation replaced')
    }

    String conflict = getMatterSetUserConflict()
    if (conflict != null) {
        logWarn "${commandName}: cannot start while ${conflict}"
        return
    }

    Long startedAt = now()
    state.remove('lastSetUserResult')
    Map pending = [
        userIndex: userIndex,
        userName: userName,
        operationType: operationType,
        operationName: operationName,
        startedAt: startedAt,
        stage: operationType == 2 ? 'awaitingModifyPreflight' : 'preparingInvoke'
    ]

    if (operationType == 2) {
        state.pendingSetUser = pending
        runIn(SET_USER_TIMEOUT_SECONDS, 'matterSetUserTimeout', [overwrite: true, data: [expectedUserIndex: userIndex]])
        logInfo "matterModifyUser: reading existing user ${userIndex} before modifying the name to '${userName}'"
        if (!sendMatterGetUserCommand(userIndex, 'matterModifyUser preflight')) {
            finishMatterSetUser(false, 'could not send preflight GetUser request')
        }
        return
    }

    pending.userUniqueID = null
    pending.userStatus = 1
    pending.userType = 0
    pending.credentialRule = 0
    state.pendingSetUser = pending
    sendMatterSetUserInvoke(pending)
}

private void sendMatterSetUserInvoke(Map pending) {
    Integer operationType = safeNumberToInt(pending.operationType, null)
    Integer userIndex = safeNumberToInt(pending.userIndex, null)
    String userName = pending.userName != null ? "${pending.userName}" : null
    byte[] userNameBytes = userName != null ? userName.getBytes('UTF-8') : null
    Long userUniqueID = responseLong(pending.userUniqueID)
    Integer userStatus = safeNumberToInt(pending.userStatus, null)
    Integer userType = safeNumberToInt(pending.userType, null)
    Integer credentialRule = safeNumberToInt(pending.credentialRule, null)
    String commandName = operationType == 2 ? 'matterModifyUser' : 'matterSetUser'
    String operationName = operationType == 2 ? 'Modify' : 'Add'

    if (!(operationType in [0, 2]) || userIndex == null || (userNameBytes != null && userNameBytes.length > 10) ||
        userStatus == null || userType == null || credentialRule == null) {
        finishMatterSetUser(false, 'pending SetUser record is incomplete or invalid')
        return
    }

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) {
        finishMatterSetUser(false, 'deviceNumber is unavailable')
        return
    }

    String userIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userIndex, 2))
    String userNameTlv = userNameBytes == null
        ? '3402'
        : '2C02' + HexUtils.integerToHexString(userNameBytes.length, 1) +
            userNameBytes.collect { byte item -> String.format('%02X', item & 0xFF) }.join()
    String userUniqueIdTlv = userUniqueID == null
        ? '3403'
        : '2603' + zigbee.swapOctets(String.format('%08X', userUniqueID & 0xFFFFFFFFL))

    // All seven fields are encoded. For Modify, values not being changed come from
    // the preflight GetUser response rather than relying on nullable-field handling.
    String tlv =
        '15' +
            '2400' + HexUtils.integerToHexString(operationType, 1) +
            '2501' + userIndexHexLE +
            userNameTlv +
            userUniqueIdTlv +
            '2404' + HexUtils.integerToHexString(userStatus, 1) +
            '2405' + HexUtils.integerToHexString(userType, 1) +
            '2406' + HexUtils.integerToHexString(credentialRule, 1) +
        '18'

    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001A, 2000, tlv)
    pending.stage = 'awaitingInvoke'
    pending.sentAt = now()
    state.pendingSetUser = pending
    runIn(SET_USER_TIMEOUT_SECONDS, 'matterSetUserTimeout', [overwrite: true, data: [expectedUserIndex: userIndex]])
    String operationVerb = operationType == 2 ? 'modifying' : 'adding'
    logInfo "${commandName}: ${operationVerb} user ${userIndex}${userName != null ? " (${userName})" : ''}"
    logDebug "${commandName}: operation=${operationName}, userIndex=${userIndex}, userNameBytes=${userNameBytes?.length ?: 0}, tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "${operationVerb} Matter user ${userIndex}...")
    parent?.sendToDevice(cmd)
}

private String getMatterSetUserConflict() {
    if (state.pendingClearUser instanceof Map) return "a ClearUser operation is active for user ${state.pendingClearUser.userIndex}"
    if (state.userScan?.active == true) return 'a user scan is active'
    if (state.credentialScan?.active == true) return 'a credential scan is active'
    if (state.isSettingCode == true || state.isOverwritingCode == true) return 'a setCode operation is active'
    if (state.isDeletingCode == true) return 'a deleteCode operation is active'
    if (state.pendingSetCredentialInvoke instanceof Map) return 'a SetCredential operation is active'
    if (state.pendingGetCredentialStatus instanceof Map) return 'a GetCredentialStatus operation is active'
    return null
}

private void processSetUserInvokeSuccess() {
    Map pending = state.pendingSetUser instanceof Map ? state.pendingSetUser as Map : null
    if (pending == null) {
        logWarn 'matterSetUser: successful Invoke callback has no pending SetUser operation'
        return
    }
    if (pending.stage != 'awaitingInvoke') {
        logDebug "matterSetUser: duplicate SetUser success ignored while stage=${pending.stage}"
        return
    }

    Integer userIndex = safeNumberToInt(pending.userIndex, null)
    if (userIndex == null) {
        finishMatterSetUser(false, 'pending SetUser state has no valid user index')
        return
    }

    pending.stage = 'awaitingGetUser'
    pending.verificationRequestedAt = now()
    state.pendingSetUser = pending
    runIn(SET_USER_TIMEOUT_SECONDS, 'matterSetUserTimeout', [overwrite: true, data: [expectedUserIndex: userIndex]])
    String commandName = safeNumberToInt(pending.operationType, null) == 2 ? 'matterModifyUser' : 'matterSetUser'
    logDebug "${commandName}: SetUser Invoke accepted; verifying user ${userIndex} with GetUser"
    if (!sendMatterGetUserCommand(userIndex, "${commandName} verification")) {
        finishMatterSetUser(false, 'could not send GetUser verification request')
    }
}

void matterSetUserTimeout(Map data) {
    Map pending = state.pendingSetUser instanceof Map ? state.pendingSetUser as Map : null
    if (pending == null) return
    Integer expectedUserIndex = safeNumberToInt(data?.expectedUserIndex, null)
    Integer pendingUserIndex = safeNumberToInt(pending.userIndex, null)
    if (expectedUserIndex != null && expectedUserIndex != pendingUserIndex) return
    finishMatterSetUser(false, "timeout while ${pending.stage ?: 'waiting for confirmation'}")
}

private void finishMatterSetUser(Boolean success, String reason, Map actualUser = null, List<String> mismatches = []) {
    Map pending = state.pendingSetUser instanceof Map ? new HashMap(state.pendingSetUser as Map) : [:]
    unschedule('matterSetUserTimeout')
    state.remove('pendingSetUser')

    Long startedAt = pending.startedAt != null ? pending.startedAt as Long : now()
    Map result = [
        success: success,
        reason: reason,
        userIndex: safeNumberToInt(pending.userIndex, null),
        userName: pending.userName,
        operationType: safeNumberToInt(pending.operationType, null),
        operationName: pending.operationName,
        startedAt: startedAt,
        finishedAt: now(),
        durationMs: Math.max(0L, now() - startedAt)
    ]
    if (actualUser != null) { result.actualUser = new HashMap(actualUser) }
    if (mismatches) { result.mismatches = new ArrayList(mismatches) }
    state.lastSetUserResult = result

    String commandName = result.operationType == 2 ? 'matterModifyUser' : 'matterSetUser'
    String message = "${commandName}: ${result.operationName ?: 'SetUser'} ${success ? 'verified' : 'failed'} for user ${result.userIndex ?: 'unknown'}: ${reason}"
    if (success) { logInfo message } else { logWarn message }
}

// 5.2.10.35. GetUser Command (0x1B)
// Retrieve one user. GetUserResponse does not include PIN or other credential secret data.
void matterGetUser(BigDecimal userIndexPar) {
    if (state.pendingClearUser instanceof Map) {
        logWarn "matterGetUser: ClearUser verification is active for user ${state.pendingClearUser.userIndex}; direct request ignored"
        return
    }
    if (state.pendingSetUser instanceof Map) {
        logWarn "matterGetUser: SetUser verification is active for user ${state.pendingSetUser.userIndex}; direct request ignored"
        return
    }
    if (state.userScan?.active == true) {
        logWarn "matterGetUser: user scan is active for user ${state.userScan.pendingUserIndex}; direct request ignored"
        return
    }
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "matterGetUser: This lock <b>does not</b> support User management (FeatureMap indicates no User support)"
        return
    }

    List<String> acceptedCommands = getDoorLockAcceptedCommandList()
    if (settings?.ignoreCompatibilityChecks != true && !acceptedCommands.isEmpty() && !acceptedCommands.contains('001B')) {
        logWarn "matterGetUser: GetUser command 0x1B is not present in this lock's AcceptedCommandList"
        return
    }

    if (userIndexPar == null) {
        logWarn 'matterGetUser: User index is required'
        return
    }
    Integer userIndex = userIndexPar.intValue()
    if (userIndexPar.compareTo(new BigDecimal(userIndex)) != 0) {
        logWarn "matterGetUser: User index must be a whole number, got '${userIndexPar}'"
        return
    }
    Integer maxUserIndex = safeNumberToInt(state.lockAttr?.numberOfTotalUsers, 65534)
    if (maxUserIndex == null || maxUserIndex < 1 || maxUserIndex > 65534) { maxUserIndex = 65534 }
    if (userIndex < 1 || userIndex > maxUserIndex) {
        logWarn "matterGetUser: User index must be 1-${maxUserIndex}, got '${userIndexPar}'"
        return
    }

    sendMatterGetUserCommand(userIndex, 'direct request')
}

private Boolean sendMatterGetUserCommand(Integer userIndex, String source) {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return false
    if (userIndex == null || userIndex < 1 || userIndex > 65534) return false

    List<Map<String, String>> cmdFields = []
    String userIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userIndex, 2))
    cmdFields.add(matter.cmdField(DataType.UINT16, 0x00, userIndexHexLE))

    // GetUser is not a timed command. GetUserResponse 0x1C is returned through callbackType:Invoke.
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001B, cmdFields)
    logDebug "matterGetUser: source=${source}, userIndex=${userIndex}, userIndexHexLE=${userIndexHexLE}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "querying user information for index ${userIndex} (${source})...")
    parent?.sendToDevice(cmd)
    return true
}

// Diagnostic occupied-user scan. Kept separate from getCodes() until live traversal is validated.
void matterScanUsers() {
    if (state.pendingClearUser instanceof Map) {
        logWarn "matterScanUsers: ClearUser verification is active for user ${state.pendingClearUser.userIndex}"
        return
    }
    if (state.pendingSetUser instanceof Map) {
        logWarn "matterScanUsers: SetUser verification is active for user ${state.pendingSetUser.userIndex}"
        return
    }
    if (state.userScan?.active == true) {
        Long lastRequestAt = state.userScan.lastRequestAt != null ? state.userScan.lastRequestAt as Long : 0L
        if (lastRequestAt > 0L && (now() - lastRequestAt) <= (GET_USER_SCAN_TIMEOUT_SECONDS * 2000L)) {
            logWarn "matterScanUsers: a scan is already active for user ${state.userScan.pendingUserIndex}"
            return
        }
        logWarn 'matterScanUsers: replacing stale scan state'
        unschedule('matterUserScanTimeout')
    }
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "matterScanUsers: This lock <b>does not</b> support User management"
        return
    }

    List<String> acceptedCommands = getDoorLockAcceptedCommandList()
    if (settings?.ignoreCompatibilityChecks != true && !acceptedCommands.isEmpty() && !acceptedCommands.contains('001B')) {
        logWarn "matterScanUsers: GetUser command 0x1B is not present in this lock's AcceptedCommandList"
        return
    }
    if (getDeviceNumber() == null) return

    Integer maxUserIndex = safeNumberToInt(state.lockAttr?.numberOfTotalUsers, 65534)
    if (maxUserIndex == null || maxUserIndex < 1 || maxUserIndex > 65534) { maxUserIndex = 65534 }
    state.userScan = [
        active: true,
        startedAt: now(),
        maxUserIndex: maxUserIndex,
        pendingUserIndex: null,
        visitedUserIndexes: [],
        requestCount: 0,
        occupiedUsers: 0,
        credentialCounts: [:],
        users: []
    ]
    logInfo "matterScanUsers: starting occupied-user scan (maximum user index ${maxUserIndex})"
    requestMatterUserScanIndex(1)
}

private void requestMatterUserScanIndex(Integer userIndex) {
    Map scan = state.userScan instanceof Map ? state.userScan as Map : null
    if (scan?.active != true) return

    Integer maxUserIndex = safeNumberToInt(scan.maxUserIndex, 65534)
    List<Integer> visited = scan.visitedUserIndexes instanceof List
        ? (scan.visitedUserIndexes as List).collect { Object value -> safeNumberToInt(value, null) }.findAll { it != null }
        : []
    if (userIndex == null || userIndex < 1 || userIndex > maxUserIndex) {
        finishMatterUserScan("invalid NextUserIndex ${userIndex}", false)
        return
    }
    if (visited.contains(userIndex)) {
        finishMatterUserScan("cycle detected at user ${userIndex}", false)
        return
    }

    scan.pendingUserIndex = userIndex
    scan.lastRequestAt = now()
    scan.requestCount = safeNumberToInt(scan.requestCount, 0) + 1
    state.userScan = scan
    runIn(GET_USER_SCAN_TIMEOUT_SECONDS, 'matterUserScanTimeout', [overwrite: true, data: [expectedUserIndex: userIndex]])
    logDebug "matterScanUsers: requesting user ${userIndex} (request ${scan.requestCount})"
    if (!sendMatterGetUserCommand(userIndex, 'user scan')) {
        finishMatterUserScan("could not send GetUser request for user ${userIndex}", false)
    }
}

void matterUserScanTimeout(Map data) {
    Map scan = state.userScan instanceof Map ? state.userScan as Map : null
    if (scan?.active != true) return

    Integer expectedUserIndex = safeNumberToInt(data?.expectedUserIndex, null)
    Integer pendingUserIndex = safeNumberToInt(scan.pendingUserIndex, null)
    if (expectedUserIndex != null && pendingUserIndex != expectedUserIndex) return
    finishMatterUserScan("timeout waiting for user ${pendingUserIndex}", false)
}

private void handleMatterUserScanResponse(Map userMeta) {
    Map scan = state.userScan instanceof Map ? state.userScan as Map : null
    if (scan?.active != true) return

    Integer userIndex = responseInt(userMeta.userIndex)
    Integer pendingUserIndex = safeNumberToInt(scan.pendingUserIndex, null)
    if (userIndex != pendingUserIndex) {
        logDebug "matterScanUsers: ignoring user ${userIndex} response while waiting for user ${pendingUserIndex}"
        return
    }

    unschedule('matterUserScanTimeout')
    List<Integer> visited = scan.visitedUserIndexes instanceof List
        ? (scan.visitedUserIndexes as List).collect { Object value -> safeNumberToInt(value, null) }.findAll { it != null }
        : []
    if (!visited.contains(userIndex)) { visited.add(userIndex) }
    scan.visitedUserIndexes = visited
    scan.pendingUserIndex = null

    Integer userStatus = responseInt(userMeta.userStatus)
    if (userStatus in [1, 3]) {
        scan.occupiedUsers = safeNumberToInt(scan.occupiedUsers, 0) + 1
    }
    Map<String, Integer> credentialCounts = scan.credentialCounts instanceof Map
        ? new HashMap(scan.credentialCounts as Map)
        : [:]
    List<Map> credentials = userMeta.credentials instanceof List ? userMeta.credentials as List<Map> : []
    credentials.each { Map credential ->
        String typeName = credential.credentialTypeName ?: 'Unknown'
        credentialCounts[typeName] = (credentialCounts[typeName] ?: 0) + 1
    }
    scan.credentialCounts = credentialCounts
    List<Map> users = scan.users instanceof List ? new ArrayList(scan.users as List) : []
    users.removeAll { Map existingUser -> responseInt(existingUser.userIndex) == userIndex }
    users.add(new HashMap(userMeta))
    scan.users = users
    state.userScan = scan

    Integer nextUserIndex = responseInt(userMeta.nextUserIndex)
    if (nextUserIndex == null) {
        finishMatterUserScan('complete', true)
        return
    }
    Integer maxUserIndex = safeNumberToInt(scan.maxUserIndex, 65534)
    if (nextUserIndex < 1 || nextUserIndex > maxUserIndex) {
        finishMatterUserScan("invalid NextUserIndex ${nextUserIndex}", false)
        return
    }
    if (visited.contains(nextUserIndex)) {
        finishMatterUserScan("cycle detected at user ${nextUserIndex}", false)
        return
    }
    if (visited.size() >= maxUserIndex) {
        finishMatterUserScan("response limit ${maxUserIndex} reached before terminal NextUserIndex", false)
        return
    }

    requestMatterUserScanIndex(nextUserIndex)
}

private void finishMatterUserScan(String reason, Boolean completed) {
    Map scan = state.userScan instanceof Map ? state.userScan as Map : [:]
    unschedule('matterUserScanTimeout')

    List<Integer> visited = scan.visitedUserIndexes instanceof List
        ? (scan.visitedUserIndexes as List).collect { Object value -> safeNumberToInt(value, null) }.findAll { it != null }
        : []
    Integer occupiedUsers = safeNumberToInt(scan.occupiedUsers, 0)
    Map<String, Integer> credentialCounts = scan.credentialCounts instanceof Map
        ? new HashMap(scan.credentialCounts as Map)
        : [:]
    List<Map> users = scan.users instanceof List ? new ArrayList(scan.users as List) : []

    Long startedAt = scan.startedAt != null ? scan.startedAt as Long : now()
    Long durationMs = Math.max(0L, now() - startedAt)
    state.userScan = [
        active: false,
        completed: completed,
        reason: reason,
        startedAt: startedAt,
        finishedAt: now(),
        durationMs: durationMs,
        visitedUserIndexes: visited,
        occupiedUsers: occupiedUsers,
        credentialCounts: credentialCounts,
        users: users
    ]

    String credentialSummary = credentialCounts.isEmpty()
        ? 'no credentials'
        : credentialCounts.keySet().sort().collect { String typeName -> "${typeName}=${credentialCounts[typeName]}" }.join(', ')
    String message = "matterScanUsers: ${completed ? 'completed' : 'stopped'} after ${visited.size()} responses (${occupiedUsers} occupied users; ${credentialSummary}; ${durationMs} ms)${reason == 'complete' ? '' : "; reason: ${reason}"}"
    String userDetails = formatMatterUserScanDetails(users)
    if (userDetails) { message += "<br><b>Matter users</b><br>${userDetails}" }
    if (completed) { logInfo message } else { logWarn message }
}

private String formatMatterUserScanDetails(List<Map> scannedUsers) {
    List<String> userLines = []
    List<Map> sortedUsers = scannedUsers ? new ArrayList(scannedUsers) : []
    sortedUsers.sort { Map left, Map right -> responseInt(left.userIndex) <=> responseInt(right.userIndex) }
    sortedUsers.each { Map userMeta ->
        Integer userIndex = responseInt(userMeta.userIndex)
        String userName = userMeta.userName ? htmlEscapeLogValue(userMeta.userName) : '<i>unnamed</i>'
        String statusName = htmlEscapeLogValue(userMeta.userStatusName ?: 'not reported')
        String typeName = htmlEscapeLogValue(userMeta.userTypeName ?: 'not reported')
        String ruleName = htmlEscapeLogValue(userMeta.credentialRuleName ?: 'not reported')
        String uniqueID = userMeta.userUniqueID != null ? htmlEscapeLogValue(userMeta.userUniqueID) : 'not reported'
        String creatorFabric = userMeta.creatorFabricIndex != null ? htmlEscapeLogValue(userMeta.creatorFabricIndex) : 'not reported'
        String modifiedFabric = userMeta.lastModifiedFabricIndex != null ? htmlEscapeLogValue(userMeta.lastModifiedFabricIndex) : 'not reported'
        List<Map> credentials = userMeta.credentials instanceof List ? userMeta.credentials as List<Map> : []
        String credentialText = credentials.isEmpty()
            ? 'none'
            : credentials.collect { Map credential ->
                String credentialType = htmlEscapeLogValue(credential.credentialTypeName ?: "type ${credential.credentialType}")
                String credentialIndex = htmlEscapeLogValue(credential.credentialIndex)
                return "${credentialType} #${credentialIndex}"
            }.join(', ')

        userLines.add(
            "<b>User ${userIndex}</b> &mdash; ${userName}" +
            "<br>&nbsp;&nbsp;Status: ${statusName} &middot; Type: ${typeName} &middot; Rule: ${ruleName}" +
            "<br>&nbsp;&nbsp;Credentials: ${credentialText} &middot; Unique ID: ${uniqueID}" +
            " &middot; Fabrics: creator ${creatorFabric}, modified ${modifiedFabric}"
        )
    }
    return userLines.join('<br>')
}

private String htmlEscapeLogValue(Object value) {
    if (value == null) return ''
    return "${value}"
        .replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
        .replace('"', '&quot;')
        .replace("'", '&#39;')
}

// 5.2.10.37. ClearUser Command (0x1D)
// Standalone diagnostic operation: preflight GetUser -> timed ClearUser -> GetUser verification.
// The 0xFFFE clear-all sentinel is deliberately rejected until full-database verification exists.
void matterClearUser(BigDecimal userIndexPar) {
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn 'matterClearUser: This lock does not support User management'
        return
    }

    List<String> acceptedCommands = getDoorLockAcceptedCommandList()
    if (settings?.ignoreCompatibilityChecks != true && !acceptedCommands.isEmpty() &&
        (!acceptedCommands.contains('001D') || !acceptedCommands.contains('001B'))) {
        List<String> missing = []
        if (!acceptedCommands.contains('001D')) { missing.add('ClearUser 0x1D') }
        if (!acceptedCommands.contains('001B')) { missing.add('GetUser 0x1B') }
        logWarn "matterClearUser: required command(s) not present in AcceptedCommandList: ${missing.join(', ')}"
        return
    }

    if (userIndexPar == null) {
        logWarn 'matterClearUser: User index is required'
        return
    }
    Integer userIndex = userIndexPar.intValue()
    if (userIndexPar.compareTo(new BigDecimal(userIndex)) != 0) {
        logWarn "matterClearUser: User index must be a whole number, got '${userIndexPar}'"
        return
    }
    if (userIndex == 0xFFFE) {
        logWarn 'matterClearUser: clear-all (UserIndex 65534 / 0xFFFE) is intentionally not supported by this verified standalone command'
        return
    }

    Integer maxUserIndex = safeNumberToInt(state.lockAttr?.numberOfTotalUsers, 65533)
    if (maxUserIndex == null || maxUserIndex < 1 || maxUserIndex > 65533) { maxUserIndex = 65533 }
    if (userIndex < 1 || userIndex > maxUserIndex) {
        logWarn "matterClearUser: User index must be 1-${maxUserIndex}, got '${userIndexPar}'"
        return
    }

    Map existingPending = state.pendingClearUser instanceof Map ? state.pendingClearUser as Map : null
    if (existingPending != null) {
        Long startedAt = existingPending.startedAt != null ? existingPending.startedAt as Long : 0L
        if (startedAt > 0L && (now() - startedAt) <= (CLEAR_USER_TIMEOUT_SECONDS * 2000L)) {
            logWarn "matterClearUser: another ClearUser operation is active for user ${existingPending.userIndex}"
            return
        }
        finishMatterClearUser(false, 'stale pending ClearUser operation replaced')
    }
    if (state.pendingSetUser instanceof Map) {
        logWarn "matterClearUser: cannot start while SetUser is active for user ${state.pendingSetUser.userIndex}"
        return
    }
    String conflict = getMatterSetUserConflict()
    if (conflict != null) {
        logWarn "matterClearUser: cannot start while ${conflict}"
        return
    }

    state.remove('lastClearUserResult')
    state.remove('recentClearUserConfirmation')
    state.pendingClearUser = [
        userIndex: userIndex,
        startedAt: now(),
        stage: 'awaitingPreflight'
    ]
    runIn(CLEAR_USER_TIMEOUT_SECONDS, 'matterClearUserTimeout', [overwrite: true, data: [expectedUserIndex: userIndex]])
    logInfo "matterClearUser: reading existing user ${userIndex} before clearing it"
    if (!sendMatterGetUserCommand(userIndex, 'matterClearUser preflight')) {
        finishMatterClearUser(false, 'could not send preflight GetUser request')
    }
}

private void handleMatterClearUserPreflightResponse(Map userMeta) {
    Map pending = state.pendingClearUser instanceof Map ? state.pendingClearUser as Map : null
    if (pending == null || pending.stage != 'awaitingPreflight') return

    Integer expectedIndex = safeNumberToInt(pending.userIndex, null)
    Integer actualIndex = responseInt(userMeta.userIndex)
    Integer userStatus = responseInt(userMeta.userStatus)
    if (actualIndex != expectedIndex) {
        finishMatterClearUser(false, "preflight GetUser returned UserIndex ${actualIndex}, expected ${expectedIndex}", userMeta)
        return
    }
    if (!(userStatus in [1, 3])) {
        finishMatterClearUser(false, "preflight GetUser found no occupied user at index ${expectedIndex}", userMeta)
        return
    }

    pending.preflightUser = new HashMap(userMeta)
    pending.preflightCompletedAt = now()
    state.pendingClearUser = pending
    sendMatterClearUserInvoke(pending)
}

private void sendMatterClearUserInvoke(Map pending) {
    Integer userIndex = safeNumberToInt(pending.userIndex, null)
    Integer deviceNumber = getDeviceNumber()
    if (userIndex == null || deviceNumber == null) {
        finishMatterClearUser(false, userIndex == null ? 'pending ClearUser state has no valid user index' : 'deviceNumber is unavailable')
        return
    }

    String userIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userIndex, 2))
    String tlv = '15' + '2500' + userIndexHexLE + '18'
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001D, 2000, tlv)
    pending.stage = 'awaitingInvoke'
    pending.sentAt = now()
    state.pendingClearUser = pending
    runIn(CLEAR_USER_TIMEOUT_SECONDS, 'matterClearUserTimeout', [overwrite: true, data: [expectedUserIndex: userIndex]])
    logInfo "matterClearUser: clearing user ${userIndex}"
    logDebug "matterClearUser: userIndex=${userIndex}, userIndexHexLE=${userIndexHexLE}, tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "clearing Matter user ${userIndex}...")
    parent?.sendToDevice(cmd)
}

private void processClearUserInvokeSuccess() {
    Map pending = state.pendingClearUser instanceof Map ? state.pendingClearUser as Map : null
    if (pending == null) {
        logWarn 'matterClearUser: successful Invoke callback has no pending ClearUser operation'
        return
    }
    if (pending.stage != 'awaitingInvoke') {
        logDebug "matterClearUser: duplicate ClearUser success ignored while stage=${pending.stage}"
        return
    }

    Integer userIndex = safeNumberToInt(pending.userIndex, null)
    if (userIndex == null) {
        finishMatterClearUser(false, 'pending ClearUser state has no valid user index')
        return
    }
    pending.stage = 'awaitingGetUser'
    pending.verificationRequestedAt = now()
    state.pendingClearUser = pending
    runIn(CLEAR_USER_TIMEOUT_SECONDS, 'matterClearUserTimeout', [overwrite: true, data: [expectedUserIndex: userIndex]])
    logDebug "matterClearUser: ClearUser Invoke accepted; verifying user ${userIndex} with GetUser"
    if (!sendMatterGetUserCommand(userIndex, 'matterClearUser verification')) {
        finishMatterClearUser(false, 'could not send GetUser verification request')
    }
}

void matterClearUserTimeout(Map data) {
    Map pending = state.pendingClearUser instanceof Map ? state.pendingClearUser as Map : null
    if (pending == null) return
    Integer expectedUserIndex = safeNumberToInt(data?.expectedUserIndex, null)
    Integer pendingUserIndex = safeNumberToInt(pending.userIndex, null)
    if (expectedUserIndex != null && expectedUserIndex != pendingUserIndex) return
    finishMatterClearUser(false, "timeout while ${pending.stage ?: 'waiting for confirmation'}")
}

private void finishMatterClearUser(Boolean success, String reason, Map actualUser = null, List<String> mismatches = []) {
    Map pending = state.pendingClearUser instanceof Map ? new HashMap(state.pendingClearUser as Map) : [:]
    unschedule('matterClearUserTimeout')
    state.remove('pendingClearUser')

    Long startedAt = pending.startedAt != null ? pending.startedAt as Long : now()
    Map result = [
        success: success,
        reason: reason,
        userIndex: safeNumberToInt(pending.userIndex, null),
        startedAt: startedAt,
        finishedAt: now(),
        durationMs: Math.max(0L, now() - startedAt)
    ]
    if (pending.preflightUser instanceof Map) { result.preflightUser = new HashMap(pending.preflightUser as Map) }
    if (actualUser != null) { result.actualUser = new HashMap(actualUser) }
    if (mismatches) { result.mismatches = new ArrayList(mismatches) }
    state.lastClearUserResult = result

    if (success) {
        Map preflightUser = result.preflightUser instanceof Map ? result.preflightUser as Map : [:]
        clearCachedUserAssociations(result.userIndex as Integer, preflightUser)
        state.recentClearUserConfirmation = [
            userIndex: result.userIndex,
            confirmedAt: now(),
            expiresAt: now() + CLEAR_USER_CONFIRMATION_DEDUP_MS
        ]
    }
    String message = "matterClearUser: ${success ? 'verified' : 'failed'} for user ${result.userIndex ?: 'unknown'}: ${reason}"
    if (success) { logInfo message } else { logWarn message }
}

private void clearCachedUserAssociations(Integer userIndex, Map preflightUser = [:]) {
    if (userIndex == null) return

    List<Map> deletedCredentials = []
    List preflightCredentials = preflightUser?.credentials instanceof List ? preflightUser.credentials as List : []
    preflightCredentials.each { Object rawCredential ->
        if (!(rawCredential instanceof Map)) return
        Map credential = rawCredential as Map
        Integer credentialType = responseInt(credential.credentialType)
        Integer credentialIndex = responseInt(credential.credentialIndex)
        if (credentialType == null || credentialIndex == null) return
        if (!deletedCredentials.any {
            responseInt(it.credentialType) == credentialType && responseInt(it.credentialIndex) == credentialIndex
        }) {
            deletedCredentials.add([
                credentialType: credentialType,
                credentialTypeName: credential.credentialTypeName ?: (CredentialTypeEnum[credentialType] ?: "Unknown (${credentialType})"),
                credentialIndex: credentialIndex
            ])
        }
    }
    Set<String> deletedMetadataKeys = deletedCredentials.collect { Map credential ->
        "${credential.credentialType}:${credential.credentialIndex}"
    } as Set<String>
    Set<String> deletedPinSlots = deletedCredentials.findAll { Map credential ->
        responseInt(credential.credentialType) == 1
    }.collect { Map credential ->
        "${credential.credentialIndex}"
    } as Set<String>

    Map users = state.userMetaByIndex instanceof Map ? new HashMap(state.userMetaByIndex as Map) : [:]
    users.remove("${userIndex}")
    state.userMetaByIndex = users

    Map credentialMetadata = state.credentialMetaByTypeAndIndex instanceof Map
        ? new HashMap(state.credentialMetaByTypeAndIndex as Map)
        : [:]
    credentialMetadata.keySet().toList().each { Object key ->
        Map entry = credentialMetadata[key] instanceof Map ? credentialMetadata[key] as Map : null
        if (deletedMetadataKeys.contains("${key}") || (entry != null && responseInt(entry.userIndex) == userIndex)) {
            credentialMetadata.remove(key)
        }
    }
    state.credentialMetaByTypeAndIndex = credentialMetadata

    ensureLockCodeStateMaps()
    Map codeMetadata = new HashMap(state.codeMetaByCredential as Map)
    codeMetadata.keySet().toList().each { Object key ->
        Map entry = codeMetadata[key] instanceof Map ? codeMetadata[key] as Map : null
        if (deletedPinSlots.contains("${key}") || (entry != null && responseInt(entry.userIndex) == userIndex)) {
            codeMetadata.remove(key)
        }
    }
    state.codeMetaByCredential = codeMetadata

    Map lockCodes = new HashMap(getLockCodes())
    List<String> removedPinSlots = []
    deletedPinSlots.each { String slot ->
        if (lockCodes.containsKey(slot)) {
            lockCodes.remove(slot)
            removedPinSlots.add(slot)
        }
    }
    if (removedPinSlots) { updateLockCodes(lockCodes) }

    String deletedCredentialText = deletedCredentials
        ? deletedCredentials.collect { Map credential -> "${credential.credentialTypeName}#${credential.credentialIndex}" }.join(', ')
        : 'none reported'
    logDebug "matterClearUser: cleared cached user ${userIndex}; deleted credentials=${deletedCredentialText}; removed lockCodes PIN slots=${removedPinSlots ?: 'none'}"
}




// 5.2.10.42. GetCredentialStatus Command (0x24)
// Queries one credential reference. Returned CredentialData is normalized to uppercase hex.
void matterGetCredentialStatus(BigDecimal credentialTypePar, BigDecimal credentialIndexPar) {
    if (state.pendingClearUser instanceof Map) {
        logWarn "matterGetCredentialStatus: ClearUser is active for user ${state.pendingClearUser.userIndex}; request ignored"
        return
    }
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn 'matterGetCredentialStatus: This lock does not support User management'
        return
    }

    List<String> acceptedCommands = getDoorLockAcceptedCommandList()
    if (settings?.ignoreCompatibilityChecks != true && !acceptedCommands.isEmpty() && !acceptedCommands.contains('0024')) {
        logWarn "matterGetCredentialStatus: command 0x24 is not present in this lock's AcceptedCommandList"
        return
    }
    if (credentialTypePar == null || credentialIndexPar == null) {
        logWarn 'matterGetCredentialStatus: credential type and index are required'
        return
    }

    Integer credentialType = credentialTypePar.intValue()
    Integer credentialIndex = credentialIndexPar.intValue()
    if (credentialTypePar.compareTo(new BigDecimal(credentialType)) != 0 || credentialType < 0 || credentialType > 8) {
        logWarn "matterGetCredentialStatus: credential type must be a whole number from 0 to 8, got '${credentialTypePar}'"
        return
    }
    if (credentialIndexPar.compareTo(new BigDecimal(credentialIndex)) != 0 || credentialIndex < 1 || credentialIndex > 65534) {
        logWarn "matterGetCredentialStatus: credential index must be a whole number from 1 to 65534, got '${credentialIndexPar}'"
        return
    }

    Map pending = state.pendingGetCredentialStatus instanceof Map ? state.pendingGetCredentialStatus as Map : null
    if (pending != null) {
        Long sentAt = pending.sentAt != null ? pending.sentAt as Long : 0L
        if (sentAt > 0L && (now() - sentAt) <= (GET_CREDENTIAL_STATUS_TIMEOUT_SECONDS * 2000L)) {
            logWarn "matterGetCredentialStatus: already waiting for ${pending.credentialTypeName ?: 'credential'} #${pending.credentialIndex}"
            return
        }
        logWarn 'matterGetCredentialStatus: replacing stale pending query state'
        unschedule('matterGetCredentialStatusTimeout')
    }

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return

    String typeHex = HexUtils.integerToHexString(credentialType, 1)
    String indexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(credentialIndex, 2))
    String tlv =
        '15' +
            '35' + '00' +
                '24' + '00' + typeHex +
                '25' + '01' + indexHexLE +
            '18' +
        '18'

    String typeName = CredentialTypeEnum[credentialType] ?: "Unknown (${credentialType})"
    state.pendingGetCredentialStatus = [
        credentialType: credentialType,
        credentialTypeName: typeName,
        credentialIndex: credentialIndex,
        sentAt: now()
    ]
    runIn(GET_CREDENTIAL_STATUS_TIMEOUT_SECONDS, 'matterGetCredentialStatusTimeout', [
        overwrite: true,
        data: [credentialType: credentialType, credentialIndex: credentialIndex]
    ])

    // Hubitat's raw-TLV overload requires the timed-invoke timeout argument.
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x0024, 2000, tlv)
    logDebug "matterGetCredentialStatus: type=${typeName} (${credentialType}), index=${credentialIndex}, tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "querying ${typeName} credential status for index ${credentialIndex}...")
    parent?.sendToDevice(cmd)
}

void matterGetCredentialStatusTimeout(Map data) {
    Map pending = state.pendingGetCredentialStatus instanceof Map ? state.pendingGetCredentialStatus as Map : null
    if (pending == null) return
    Integer expectedType = safeNumberToInt(data?.credentialType, null)
    Integer expectedIndex = safeNumberToInt(data?.credentialIndex, null)
    if (safeNumberToInt(pending.credentialType, null) != expectedType || safeNumberToInt(pending.credentialIndex, null) != expectedIndex) return

    state.remove('pendingGetCredentialStatus')
    Boolean scanMatches = state.credentialScan?.active == true &&
        safeNumberToInt(state.credentialScan.credentialType, null) == expectedType &&
        safeNumberToInt(state.credentialScan.pendingCredentialIndex, null) == expectedIndex
    if (scanMatches) {
        finishMatterCredentialScan("timeout waiting for ${pending.credentialTypeName ?: 'credential'} #${pending.credentialIndex}", false)
    } else {
        logWarn "matterGetCredentialStatus: timeout waiting for ${pending.credentialTypeName ?: 'credential'} #${pending.credentialIndex}"
    }
}


// Diagnostic credential scan. Starts at index 1 and follows NextCredentialIndex.
void matterScanCredentials(BigDecimal credentialTypePar) {
    if (state.pendingClearUser instanceof Map) {
        logWarn "matterScanCredentials: ClearUser is active for user ${state.pendingClearUser.userIndex}"
        return
    }
    if (state.pendingSetUser instanceof Map) {
        logWarn "matterScanCredentials: SetUser verification is active for user ${state.pendingSetUser.userIndex}"
        return
    }
    if (credentialTypePar == null) {
        logWarn 'matterScanCredentials: credential type is required'
        return
    }
    Integer credentialType = credentialTypePar.intValue()
    if (credentialTypePar.compareTo(new BigDecimal(credentialType)) != 0 || credentialType < 0 || credentialType > 8) {
        logWarn "matterScanCredentials: credential type must be a whole number from 0 to 8, got '${credentialTypePar}'"
        return
    }
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn 'matterScanCredentials: This lock does not support User management'
        return
    }
    List<String> acceptedCommands = getDoorLockAcceptedCommandList()
    if (settings?.ignoreCompatibilityChecks != true && !acceptedCommands.isEmpty() && !acceptedCommands.contains('0024')) {
        logWarn "matterScanCredentials: GetCredentialStatus command 0x24 is not present in this lock's AcceptedCommandList"
        return
    }
    if (getDeviceNumber() == null) return

    if (state.credentialScan?.active == true) {
        Long lastRequestAt = state.credentialScan.lastRequestAt != null ? state.credentialScan.lastRequestAt as Long : 0L
        if (lastRequestAt > 0L && (now() - lastRequestAt) <= (GET_CREDENTIAL_STATUS_TIMEOUT_SECONDS * 2000L)) {
            logWarn "matterScanCredentials: a scan is already active for ${state.credentialScan.credentialTypeName} #${state.credentialScan.pendingCredentialIndex}"
            return
        }
        logWarn 'matterScanCredentials: replacing stale scan state'
        unschedule('matterGetCredentialStatusTimeout')
        state.remove('pendingGetCredentialStatus')
    }

    Map pending = state.pendingGetCredentialStatus instanceof Map ? state.pendingGetCredentialStatus as Map : null
    if (pending != null) {
        Long sentAt = pending.sentAt != null ? pending.sentAt as Long : 0L
        if (sentAt > 0L && (now() - sentAt) <= (GET_CREDENTIAL_STATUS_TIMEOUT_SECONDS * 2000L)) {
            logWarn "matterScanCredentials: cannot start while waiting for ${pending.credentialTypeName ?: 'credential'} #${pending.credentialIndex}"
            return
        }
        unschedule('matterGetCredentialStatusTimeout')
        state.remove('pendingGetCredentialStatus')
    }

    String typeName = CredentialTypeEnum[credentialType] ?: "Unknown (${credentialType})"
    Integer maxResponses = credentialScanResponseLimit(credentialType)
    state.credentialScan = [
        active: true,
        startedAt: now(),
        credentialType: credentialType,
        credentialTypeName: typeName,
        maxResponses: maxResponses,
        pendingCredentialIndex: null,
        visitedCredentialIndexes: [],
        requestCount: 0,
        occupiedCredentials: 0,
        credentials: []
    ]
    logInfo "matterScanCredentials: starting ${typeName} credential scan (response limit ${maxResponses})"
    requestMatterCredentialScanIndex(1)
}

private Integer credentialScanResponseLimit(Integer credentialType) {
    Object configuredLimit
    switch (credentialType) {
        case 1: configuredLimit = state.lockAttr?.numberOfPINUsers; break
        case 2: configuredLimit = state.lockAttr?.numberOfRFIDUsers; break
        default: configuredLimit = state.lockAttr?.numberOfTotalUsers; break
    }
    Integer limit = safeNumberToInt(configuredLimit, 65534)
    return (limit != null && limit >= 1 && limit <= 65534) ? limit : 65534
}

private void requestMatterCredentialScanIndex(Integer credentialIndex) {
    Map scan = state.credentialScan instanceof Map ? state.credentialScan as Map : null
    if (scan?.active != true) return
    if (credentialIndex == null || credentialIndex < 1 || credentialIndex > 65534) {
        finishMatterCredentialScan("invalid NextCredentialIndex ${credentialIndex}", false)
        return
    }

    List<Integer> visited = scan.visitedCredentialIndexes instanceof List
        ? (scan.visitedCredentialIndexes as List).collect { Object value -> safeNumberToInt(value, null) }.findAll { it != null }
        : []
    if (visited.contains(credentialIndex)) {
        finishMatterCredentialScan("cycle detected at credential ${credentialIndex}", false)
        return
    }

    scan.pendingCredentialIndex = credentialIndex
    scan.lastRequestAt = now()
    scan.requestCount = safeNumberToInt(scan.requestCount, 0) + 1
    state.credentialScan = scan
    logDebug "matterScanCredentials: requesting ${scan.credentialTypeName} #${credentialIndex} (request ${scan.requestCount})"
    matterGetCredentialStatus(safeNumberToInt(scan.credentialType, 0) as BigDecimal, credentialIndex as BigDecimal)
}

private void handleMatterCredentialScanResponse(Map credentialMeta) {
    Map scan = state.credentialScan instanceof Map ? state.credentialScan as Map : null
    if (scan?.active != true) return

    Integer credentialType = responseInt(credentialMeta.credentialType)
    Integer credentialIndex = responseInt(credentialMeta.credentialIndex)
    Integer pendingType = safeNumberToInt(scan.credentialType, null)
    Integer pendingIndex = safeNumberToInt(scan.pendingCredentialIndex, null)
    if (credentialType != pendingType || credentialIndex != pendingIndex) {
        logDebug "matterScanCredentials: ignoring response for type ${credentialType} index ${credentialIndex} while waiting for type ${pendingType} index ${pendingIndex}"
        return
    }

    List<Integer> visited = scan.visitedCredentialIndexes instanceof List
        ? (scan.visitedCredentialIndexes as List).collect { Object value -> safeNumberToInt(value, null) }.findAll { it != null }
        : []
    if (!visited.contains(credentialIndex)) visited.add(credentialIndex)
    scan.visitedCredentialIndexes = visited
    if (credentialMeta.credentialExists == true) {
        scan.occupiedCredentials = safeNumberToInt(scan.occupiedCredentials, 0) + 1
    }
    List<Map> credentials = scan.credentials instanceof List ? new ArrayList(scan.credentials as List) : []
    credentials.removeAll { Map existing -> responseInt(existing.credentialIndex) == credentialIndex }
    credentials.add(new HashMap(credentialMeta))
    scan.credentials = credentials
    state.credentialScan = scan

    Integer nextCredentialIndex = responseInt(credentialMeta.nextCredentialIndex)
    if (nextCredentialIndex == null) {
        finishMatterCredentialScan('complete', true)
        return
    }
    if (nextCredentialIndex < 1 || nextCredentialIndex > 65534) {
        finishMatterCredentialScan("invalid NextCredentialIndex ${nextCredentialIndex}", false)
        return
    }
    if (visited.contains(nextCredentialIndex)) {
        finishMatterCredentialScan("cycle detected at credential ${nextCredentialIndex}", false)
        return
    }
    Integer maxResponses = safeNumberToInt(scan.maxResponses, 65534)
    if (visited.size() >= maxResponses) {
        finishMatterCredentialScan("response limit ${maxResponses} reached before terminal NextCredentialIndex", false)
        return
    }

    requestMatterCredentialScanIndex(nextCredentialIndex)
}

private void finishMatterCredentialScan(String reason, Boolean completed) {
    Map scan = state.credentialScan instanceof Map ? state.credentialScan as Map : [:]
    unschedule('matterGetCredentialStatusTimeout')
    state.remove('pendingGetCredentialStatus')

    List<Integer> visited = scan.visitedCredentialIndexes instanceof List
        ? (scan.visitedCredentialIndexes as List).collect { Object value -> safeNumberToInt(value, null) }.findAll { it != null }
        : []
    List<Map> credentials = scan.credentials instanceof List ? new ArrayList(scan.credentials as List) : []
    Integer occupiedCredentials = safeNumberToInt(scan.occupiedCredentials, 0)
    Long startedAt = scan.startedAt != null ? scan.startedAt as Long : now()
    Long durationMs = Math.max(0L, now() - startedAt)
    String typeName = scan.credentialTypeName ?: 'Credential'

    state.credentialScan = [
        active: false,
        completed: completed,
        reason: reason,
        startedAt: startedAt,
        finishedAt: now(),
        durationMs: durationMs,
        credentialType: scan.credentialType,
        credentialTypeName: typeName,
        visitedCredentialIndexes: visited,
        occupiedCredentials: occupiedCredentials,
        credentials: credentials
    ]

    String message = "matterScanCredentials: ${completed ? 'completed' : 'stopped'} after ${visited.size()} responses (${occupiedCredentials} occupied ${typeName} credentials; ${durationMs} ms)${reason == 'complete' ? '' : "; reason: ${reason}"}"
    String details = formatMatterCredentialScanDetails(credentials)
    if (details) message += "<br><b>${htmlEscapeLogValue(typeName)} credentials</b><br>${details}"
    if (completed) logInfo message else logWarn message
}

private String formatMatterCredentialScanDetails(List<Map> scannedCredentials) {
    List<Map> sorted = scannedCredentials ? new ArrayList(scannedCredentials) : []
    sorted.sort { Map left, Map right -> responseInt(left.credentialIndex) <=> responseInt(right.credentialIndex) }
    return sorted.collect { Map credential ->
        Integer index = responseInt(credential.credentialIndex)
        String status = credential.credentialExists == true ? '<b>occupied</b>' : 'available'
        String user = credential.userIndex != null ? "User ${htmlEscapeLogValue(credential.userIndex)}" : 'User not reported'
        String fabrics = "creator ${htmlEscapeLogValue(credential.creatorFabricIndex ?: 'not reported')}, modified ${htmlEscapeLogValue(credential.lastModifiedFabricIndex ?: 'not reported')}"
        String next = credential.nextCredentialIndex != null ? htmlEscapeLogValue(credential.nextCredentialIndex) : 'none'
        String data = credential.credentialDataPresent == true
            ? "${htmlEscapeLogValue(credential.credentialData)} (${htmlEscapeLogValue(credential.credentialDataLength != null ? credential.credentialDataLength : 'unknown')} bytes)"
            : 'not returned'
        "<b>${htmlEscapeLogValue(credential.credentialTypeName)} #${index}</b> &mdash; ${status}<br>&nbsp;&nbsp;${user} &middot; Fabrics: ${fabrics} &middot; Next: ${next} &middot; Data: ${data}"
    }.join('<br>')
}
// Helper function to check if setCodeLength is supported by this lock
Boolean isSetCodeLengthEnabled() {
    // TODO: Check FeatureMap or device capabilities to determine support
    return false
}

/**
 * Check if a specific Matter Door Lock feature is enabled on this lock
 * @param featureBit The feature bit to check (use FEATURE_* constants)
 * @return true if the feature is enabled, false otherwise
 */
Boolean isFeatureEnabled(Integer featureBit) {
    // Bypass feature checks if ignoreCompatibilityChecks is enabled
    if (settings?.ignoreCompatibilityChecks == true) {
        //logDebug "isFeatureEnabled: ignoreCompatibilityChecks enabled - bypassing feature check for 0x${Integer.toHexString(featureBit).toUpperCase()}"
        return true
    }
    
    // Get FeatureMap from fingerprintData
    Map fingerprint = getFingerprintData()
    def featureMapRaw = fingerprint?.get('0101_FFFC')

    if (featureMapRaw == null) {
        logWarn "isFeatureEnabled: FeatureMap not available in fingerprintData - features unknown"
        return false
    }

    // Parse FeatureMap value - stored as uppercase hex string (e.g. "0D93") by newParseCompatibilityPatch.
    // safeHexToInt handles both hex strings and raw integers defensively.
    Integer featureMap = safeHexToInt(featureMapRaw)
    
    // Check if the specific feature bit is set
    boolean enabled = (featureMap & featureBit) != 0
    
    //logDebug "isFeatureEnabled: FeatureMap=0x${Integer.toHexString(featureMap).toUpperCase()}, checking bit 0x${Integer.toHexString(featureBit).toUpperCase()}: ${enabled}"
    
    return enabled
}

/**
 * Check if this lock supports PIN credential management (LockCodes capability)
 * @return true if PIN credentials and user management are supported
 */
Boolean supportsLockCodes() {
    // Bypass feature checks if ignoreCompatibilityChecks is enabled
    if (settings?.ignoreCompatibilityChecks == true) {
        //logDebug "supportsLockCodes: ignoreCompatibilityChecks enabled - bypassing PIN/User feature checks"
        return true
    }
    
    return isFeatureEnabled(FEATURE_PIN_CREDENTIAL) && isFeatureEnabled(FEATURE_USER_MANAGEMENT)
}

/**
 * Helper method for dynamic command parameter display
 * Returns a string indicating whether this device supports PIN code management
 * Used in command metadata to show feature support status to users
 */
String isCodeAllowed() {
    if (false/*supportsLockCodes()*/) {
        return "Your device ${device?.displayName} SUPPORTS PIN code management"
    } else {
        Map fingerprint = getFingerprintData()
        String featureMapHex = fingerprint?.get('0101_FFFC') ?: '??'
        return "Your device ${device?.displayName} <b>does NOT</b> support PIN code management (FeatureMap=0x${featureMapHex})"
    }
}

// ========== LockCodes Capability Methods ==========
// Note: These methods are part of the LockCodes capability which is always declared
// However, not all Matter locks support PIN management. Each method checks feature support.


// ========== End LockCodes Capability Methods ==========


// Read FeatureMap attribute to see which features are supported
// TODO - move to the main driver
void readFeatureMap() {
    parent?.componentLog(device, 'debug', 'reading FeatureMap attribute...')
    String endpoint = device.getDataValue('id') ?: '1'
    String cluster = '257'  // 0x0101 Door Lock cluster
    String attribute = '65532'  // 0xFFFC FeatureMap
    parent?.readAttribute([endpoint, cluster, attribute])
}


// Helper method to generate info string with feature support status
String generateInfoString() {
    Map fingerprint = getFingerprintData()
    String featureMapHex = fingerprint?.get('0101_FFFC') ?: '??'
    // Check actual hardware FeatureMap bits directly — not subject to ignoreCompatibilityChecks bypass,
    // since this method reports what the hardware actually supports, not what is overridden.
    Integer featureMap   = safeHexToInt(featureMapHex)
    Boolean pinEnabled   = (featureMap & FEATURE_PIN_CREDENTIAL)  != 0
    Boolean userEnabled  = (featureMap & FEATURE_USER_MANAGEMENT) != 0
    Boolean isEnabled    = pinEnabled && userEnabled
    //log.trace "generateInfoString: FeatureMap=0x${featureMapHex}, PIN_CREDENTIAL=${pinEnabled}, USER_MANAGEMENT=${userEnabled}, isEnabled=${isEnabled}"
    String featureInfo = isEnabled ?
        "Your lock ${device.displayName} supports PIN codes/users management (FeatureMap=0x${featureMapHex})" :
        "Your lock ${device.displayName} <b>does NOT</b> support PIN codes/users management (FeatureMap=0x${featureMapHex})"
    return "${featureInfo}"
}

// Called when the device is first created
void installed() {
    log.info "${device.displayName} driver installed"
    // Seed attributes with safe defaults so dashboards and automations
    // never see null before the first Matter report arrives.
    sendEvent(name: 'lock',              value: 'unknown',      descriptionText: "${device.displayName} lock initialized to unknown")
    sendEvent(name: 'lockCodes',         value: '{}',           descriptionText: "${device.displayName} lockCodes initialized")
    sendEvent(name: 'codeLength',        value: 4,              descriptionText: "${device.displayName} codeLength defaulted to 4 (pending discovery)")
    sendEvent(name: 'maxCodes',          value: 10,             descriptionText: "${device.displayName} maxCodes defaulted to 10 (pending discovery)")
    runIn(2,  'updated')   // delay to allow settings to be saved
    runIn(30, 'getInfo')   // read all Door Lock attributes once discovery has populated fingerprintData
}

// Called when the device is removed
void uninstalled() {
    log.info "${device.displayName} driver uninstalled"
}

// Called when the settings are updated
void updated() {
    log.info "${device.displayName} driver configuration updated"
    clearOldStateVariables()
    state.info = generateInfoString()
    log.info "${device.displayName} ${state.info}"
    if (logEnable) {
        logDebug settings as String
        runIn(86400, 'logsOff')
    }
    updateEncryption()
}

// Clean up old/deprecated state variables
void clearOldStateVariables() {
    List<String> oldStateVars = ['warning', 'working', 'Warning', 'Working', 'comment', 'lastSetCode']
    oldStateVars.each { String varName ->
        if (state.containsKey(varName)) {
            logDebug "clearOldStateVariables: removing '${varName}'"
            state.remove(varName)
        }
    }
}

private void logsOff() {
    log.warn "debug logging disabled for ${device.displayName} "
    device.updateSetting('logEnable', [value: 'false', type: 'bool'] )
}

void refresh() {
    logInfo "refreshing device state and attributes..."
    clearOldStateVariables()
    parent?.componentRefresh(this.device)
}



/**
 * Get the Door Lock cluster AttributeList (0x0101_FFFB)
 * @return List of attribute IDs as 4-digit hex strings (e.g., ["0000", "0001", "0002", ...])
 */
List<String> getDoorLockAttributeList() {
    Map fingerprint = getFingerprintData()
    if (fingerprint == null) {
        logDebug "getDoorLockAttributeList: fingerprint data not available"
        return []
    }
    
    return fingerprint['0101_FFFB'] ?: []
}

/**
 * Check if a specific attribute is supported by the Door Lock cluster
 * @param attrHex Attribute ID as 4-digit hex string (e.g., "0000" for LockState)
 * @return true if attribute is in Door Lock AttributeList
 */
boolean isDoorLockAttributeSupported(String attrHex) {
    List<String> attrList = getDoorLockAttributeList()
    return attrList.contains(attrHex?.toUpperCase())
}

/**
 * Get AcceptedCommandList for Door Lock cluster from fingerprint data
 * @return List of command IDs as 4-digit hex strings (e.g., ['0000', '0001', '0003', ...])
 */
List<String> getDoorLockAcceptedCommandList() {
    Map fingerprint = getFingerprintData()
    if (!fingerprint) {
        logDebug "getDoorLockAcceptedCommandList: fingerprint data not available"
        return []
    }
    return fingerprint.get('0101_FFF9') ?: []
}

/**
 * Check if a specific Door Lock command is supported
 * @param commandHex The command ID as 4-digit hex string (e.g., '0000', '0001', etc.)
 * @return true if command is in the AcceptedCommandList
 */
Boolean isDoorLockCommandSupported(String commandHex) {
    List<String> cmdList = getDoorLockAcceptedCommandList()
    return cmdList.contains(commandHex?.toUpperCase())
}


// Helper function to process event mask attributes (reduces code duplication)
// Returns the message to be logged (caller handles logging)
String processEventMaskAttribute(String attrId, String attrName, Map descMap, Closure decoder) {
    Object rawValue = descMap.value instanceof List
        ? (descMap.value ? descMap.value[0] : null)
        : descMap.value
    Integer mask = rawValue instanceof Number
        ? safeNumberToInt(rawValue, 0)
        : safeHexToInt(rawValue?.toString(), 0)
    String maskValue = String.format('%04X', mask)
    String decoded = decoder(mask)
    
    // Build and return message (prefix will be added by caller)
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${attrId}] " : ""
    return "${prefix}${attrName}: 0x${maskValue} - Enabled: ${decoded}"
}

// Helper function to process numeric attributes in handleLockMessage method
// Returns the message to be logged (caller handles logging)
String processNumericAttribute(String attrName, Map descMap) {
    Integer value = safeHexToInt(descMap.value)
    
    // Build and return message (prefix will be added by caller)
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${descMap.attrId}] " : ""
    return "${prefix}${attrName}: ${value}"
}



void processSetCredentialResponse(Map descMap) {
    if (!(descMap.value instanceof Map)) {
        logWarn "processSetCredentialResponse: malformed response value=${descMap.value}; waiting for LockUserChange or timeout"
        return
    }
    Map values = descMap.value as Map
    Object statusRaw = values.containsKey(0) ? values[0] : values['0']
    Object userIndexRaw = values.containsKey(1) ? values[1] : values['1']
    Object nextCredentialIndexRaw = values.containsKey(2) ? values[2] : values['2']

    Integer credentialStatus = safeNumberToInt(statusRaw, null)
    Integer userIndex = safeNumberToInt(userIndexRaw, null)
    Integer nextCredentialIndex = safeNumberToInt(nextCredentialIndexRaw, null)
    if (credentialStatus == null) {
        logWarn "processSetCredentialResponse: missing or invalid DlStatus in value=${descMap.value}; waiting for LockUserChange or timeout"
        return
    }

    handleDecodedSetCredentialResponse(credentialStatus, userIndex, nextCredentialIndex)
}

private void handleDecodedSetCredentialResponse(Integer credentialStatus, Integer userIndex, Integer nextCredentialIndex) {
    String statusName = DoorLockClusterDlStatus[credentialStatus] ?: 'Unknown'
    String statusHex = String.format('0x%02X', credentialStatus)
    logDebug "processSetCredentialResponse: status=${statusName} (${statusHex}) userIndex=${userIndex} nextCredentialIndex=${nextCredentialIndex}"

    Map pendingInvoke = state.pendingSetCredentialInvoke instanceof Map ? state.pendingSetCredentialInvoke as Map : null
    if (pendingInvoke == null) {
        Map recent = getRecentSetCredentialConfirmation()
        if (credentialStatus == 0 && recent != null) {
            logDebug "processSetCredentialResponse: setCode slot ${recent.credentialKey} was already confirmed by ${recent.source}; duplicate success ignored"
        } else {
            logWarn "processSetCredentialResponse: ${statusName} (${statusHex}) response has no pending SetCredential request; state not changed"
        }
        return
    }

    String credentialKey = pendingInvoke.credentialKey != null ? "${pendingInvoke.credentialKey}" : null
    Boolean fromSetCode = pendingInvoke.fromSetCode == true
    if (credentialStatus == 0) {
        if (!fromSetCode) {
            state.remove('pendingSetCredentialInvoke')
            logDebug 'processSetCredentialResponse: direct SetCredential command succeeded; lockCodes not changed'
            return
        }
        String descriptionText = "${device.displayName} setCode position ${credentialKey} confirmed by SetCredentialResponse"
        if (userIndex != null) { descriptionText += " for User ${userIndex}" }
        if (!completePendingSetCode(credentialKey, userIndex, descriptionText, 'SetCredentialResponse')) {
            logWarn "processSetCredentialResponse: Success received but pending setCode data for slot ${credentialKey} is unavailable; lockCodes not changed"
        }
        return
    }

    String failureReason = setCredentialFailureReason(credentialStatus)
    String nextText = nextCredentialIndex != null ? "; next available credential slot reported by the lock is ${nextCredentialIndex}" : ''
    if (!fromSetCode) {
        state.remove('pendingSetCredentialInvoke')
        logWarn "SetCredential failed: ${statusName} (${statusHex}) - ${failureReason}${nextText}"
        return
    }

    clearSetCodeOperationState(credentialKey, true)
    String descriptionText = "${device.displayName} setCode position ${credentialKey} failed: ${statusName} (${statusHex}) - ${failureReason}${nextText}"
    sendEvent(name: 'codeChanged', value: 'failed', descriptionText: descriptionText, isStateChange: true)
    logWarn descriptionText
}

private String setCredentialFailureReason(Integer status) {
    switch (status) {
        case 0x01: return 'lock reported a general failure'
        case 0x02: return 'credential data is already assigned to another slot'
        case 0x03: return 'credential slot is occupied'
        case 0x85: return 'lock rejected an invalid command field'
        case 0x89: return 'lock credential or user resources are exhausted'
        case 0x8B: return 'referenced credential or user was not found'
        default:   return "lock returned unknown DlStatus ${status}"
    }
}

private Boolean completePendingSetCode(String credentialKey, Integer userIndex, String descriptionText, String source) {
    ensureLockCodeStateMaps()
    if (credentialKey == null) { return false }
    Map entry = state.pendingSetByCredential?.get(credentialKey) instanceof Map ? state.pendingSetByCredential.get(credentialKey) as Map : null
    if (entry == null) { return false }

    String storedPin = entry.pinCode != null ? "${entry.pinCode}" : ''
    String storedName = entry.name ?: (getLockCodes()[credentialKey]?.name ?: "Code ${credentialKey}")
    Map lockcodes = getLockCodes()
    Boolean newCode = !lockcodes.containsKey(credentialKey)
    lockcodes[credentialKey] = [code: storedPin, name: storedName]
    updateLockCodes(lockcodes)

    Map metaPatch = [credentialIndex: safeToInt(credentialKey), lastSetConfirmationSource: source]
    if (userIndex != null) { metaPatch.userIndex = userIndex }
    upsertCredentialMeta(credentialKey, metaPatch)

    String codeChangedValue = newCode ? 'added' : 'changed'
    Map codeData = [(credentialKey): [code: storedPin, name: storedName]]
    def eventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(codeData)) : codeData
    logLockCodeEventPayload('codeChanged', codeChangedValue, codeData)
    sendEvent(name: 'codeChanged', value: codeChangedValue, data: eventData, descriptionText: descriptionText, isStateChange: true)

    state.recentSetCredentialConfirmation = [credentialKey: credentialKey, userIndex: userIndex, confirmedAt: now(), source: source]
    clearSetCodeOperationState(credentialKey, true)
    logDebug "completePendingSetCode: slot=${credentialKey}, result=${codeChangedValue}, source=${source}, lockCodes updated"
    return true
}

private void clearSetCodeOperationState(String credentialKey, Boolean clearPendingEntry) {
    state.isSettingCode = false
    state.isOverwritingCode = false
    unschedule('clearSettingCodeFlagOnTimeout')
    unschedule('proceedWithOverwriteAdd')
    if (clearPendingEntry && credentialKey != null) {
        state.pendingSetByCredential?.remove(credentialKey)
    }
    state.remove('pendingSetCredentialInvoke')
    state.remove('overwriteSlot')
}

private Map getRecentSetCredentialConfirmation() {
    Map recent = state.recentSetCredentialConfirmation instanceof Map ? state.recentSetCredentialConfirmation as Map : null
    if (recent == null) { return null }
    Long confirmedAt = recent.confirmedAt != null ? (recent.confirmedAt as Long) : 0L
    if (confirmedAt <= 0L || (now() - confirmedAt) > SET_CREDENTIAL_CONFIRMATION_DEDUP_MS) {
        state.remove('recentSetCredentialConfirmation')
        return null
    }
    return recent
}

private Boolean isRecentSetCredentialEvent(String credentialKey, Integer userIndex, Integer dataOperationType) {
    if (!(dataOperationType in [0, 2])) { return false }
    Map recent = getRecentSetCredentialConfirmation()
    if (recent == null) { return false }

    Boolean credentialMatches = credentialKey != null && "${recent.credentialKey}" == credentialKey
    Boolean userMatches = userIndex != null && recent.userIndex != null && safeToInt(recent.userIndex) == userIndex
    return credentialMatches || userMatches
}

private Map getRecentClearCredentialConfirmation() {
    Map recent = state.recentClearCredentialConfirmation instanceof Map ? state.recentClearCredentialConfirmation as Map : null
    if (recent == null) { return null }
    Long confirmedAt = recent.confirmedAt != null ? (recent.confirmedAt as Long) : 0L
    if (confirmedAt <= 0L || (now() - confirmedAt) > CLEAR_CREDENTIAL_CONFIRMATION_DEDUP_MS) {
        state.remove('recentClearCredentialConfirmation')
        return null
    }
    return recent
}

private Boolean isRecentClearCredentialEvent(String credentialKey, Integer userIndex, Integer dataIndex, Integer dataOperationType) {
    if (dataOperationType != 1) { return false }
    Map recent = getRecentClearCredentialConfirmation()
    if (recent == null) { return false }

    Boolean credentialMatches = credentialKey != null && recent.credentialKey != null && "${recent.credentialKey}" == credentialKey
    Integer recentUserIndex = safeToInt(recent.userIndex, null)
    Boolean userMatches = recentUserIndex != null && (userIndex == recentUserIndex || dataIndex == recentUserIndex)
    return credentialMatches || userMatches
}

void processGetCredentialStatusResponse(Map descMap) {
    Map pending = state.pendingGetCredentialStatus instanceof Map ? new HashMap(state.pendingGetCredentialStatus as Map) : null
    unschedule('matterGetCredentialStatusTimeout')
    state.remove('pendingGetCredentialStatus')

    Object decodedValue = unwrapMatterValue(descMap.value)
    if (!(decodedValue instanceof Map)) {
        logWarn "processGetCredentialStatusResponse: malformed response value=${descMap.value}"
        if (state.credentialScan?.active == true) {
            finishMatterCredentialScan('malformed GetCredentialStatusResponse payload', false)
        }
        return
    }

    Map values = decodedValue as Map
    Boolean credentialExists = responseBool(responseField(values, 0, 'credentialExists'))
    Integer userIndex = responseInt(responseField(values, 1, 'userIndex'))
    Integer creatorFabricIndex = responseInt(responseField(values, 2, 'creatorFabricIndex'))
    Integer lastModifiedFabricIndex = responseInt(responseField(values, 3, 'lastModifiedFabricIndex'))
    Integer nextCredentialIndex = responseInt(responseField(values, 4, 'nextCredentialIndex'))
    Object credentialDataRaw = responseField(values, 5, 'credentialData')
    Boolean credentialDataPresent = !isMatterNull(unwrapMatterValue(credentialDataRaw))
    String credentialData = credentialDataPresent ? normalizeCredentialDataHex(credentialDataRaw) : null
    Integer credentialDataLength = credentialData != null ? (credentialData.length() / 2) as Integer : null

    if (credentialExists == null) {
        logWarn "processGetCredentialStatusResponse: missing or invalid CredentialExists value=${descMap.value}"
        if (state.credentialScan?.active == true) {
            finishMatterCredentialScan('GetCredentialStatusResponse missing CredentialExists', false)
        }
        return
    }

    Integer credentialType = responseInt(pending?.credentialType)
    Integer credentialIndex = responseInt(pending?.credentialIndex)
    String credentialTypeName = pending?.credentialTypeName ?: (credentialType != null ? (CredentialTypeEnum[credentialType] ?: "Unknown (${credentialType})") : 'unknown credential')
    Map credentialMeta = [
        credentialType: credentialType,
        credentialTypeName: credentialTypeName,
        credentialIndex: credentialIndex,
        credentialExists: credentialExists,
        userIndex: userIndex,
        creatorFabricIndex: creatorFabricIndex,
        lastModifiedFabricIndex: lastModifiedFabricIndex,
        nextCredentialIndex: nextCredentialIndex,
        credentialDataPresent: credentialDataPresent,
        credentialData: credentialData,
        credentialDataLength: credentialDataLength,
        updatedAt: now()
    ]
    state.lastCredentialStatusResponse = credentialMeta

    if (credentialType != null && credentialIndex != null) {
        String metadataKey = "${credentialType}:${credentialIndex}"
        Map credentialMetadata = state.credentialMetaByTypeAndIndex instanceof Map
            ? new HashMap(state.credentialMetaByTypeAndIndex as Map)
            : [:]
        Map previous = credentialMetadata[metadataKey] instanceof Map ? credentialMetadata[metadataKey] as Map : [:]
        credentialMetadata[metadataKey] = [:] + previous + credentialMeta
        state.credentialMetaByTypeAndIndex = credentialMetadata

        if (credentialType == 1) {
            upsertCredentialMeta("${credentialIndex}", [
                credentialType: credentialType,
                credentialExists: credentialExists,
                userIndex: userIndex,
                creatorFabricIndex: creatorFabricIndex,
                lastModifiedFabricIndex: lastModifiedFabricIndex,
                credentialDataPresent: credentialDataPresent,
                credentialData: credentialData,
                credentialDataLength: credentialDataLength,
                updatedAt: now()
            ])
        }
    } else {
        logWarn 'processGetCredentialStatusResponse: response has no matching pending request; stored only as lastCredentialStatusResponse'
    }

    String credentialLabel = credentialIndex != null ? "${credentialTypeName} #${credentialIndex}" : credentialTypeName
    String dataSummary = credentialDataPresent ? "${credentialData} (${credentialDataLength != null ? credentialDataLength : 'unknown'} bytes)" : 'not returned'
    logInfo "GetCredentialStatus Response: ${credentialLabel}, exists=${credentialExists}, userIndex=${userIndex ?: 'not reported'}, creatorFabric=${creatorFabricIndex ?: 'not reported'}, modifiedFabric=${lastModifiedFabricIndex ?: 'not reported'}, nextCredentialIndex=${nextCredentialIndex ?: 'none'}, credentialData=${dataSummary}"
    handleMatterCredentialScanResponse(credentialMeta)
}

private String normalizeCredentialDataHex(Object rawValue) {
    Object value = unwrapMatterValue(rawValue)
    if (isMatterNull(value)) return null

    if (value instanceof byte[]) {
        return (value as byte[]).collect { byte item -> String.format('%02X', item & 0xFF) }.join()
    }

    if (value instanceof Collection) {
        Collection items = value as Collection
        Boolean isByteCollection = items.every { Object item ->
            item instanceof Number && (item as Number).intValue() >= 0 && (item as Number).intValue() <= 255
        }
        if (isByteCollection) {
            return items.collect { Object item -> String.format('%02X', (item as Number).intValue()) }.join()
        }
    }

    String stringValue = "${value}"
    String hexValue = stringValue.startsWith('0x') || stringValue.startsWith('0X') ? stringValue.substring(2) : stringValue
    if (hexValue ==~ /(?i)[0-9a-f]+/ && (hexValue.length() % 2) == 0) {
        return hexValue.toUpperCase()
    }
    return stringValue.getBytes('UTF-8').collect { byte item -> String.format('%02X', item & 0xFF) }.join()
}

private Boolean responseBool(Object rawValue) {
    Object value = unwrapMatterValue(rawValue)
    if (isMatterNull(value)) return null
    if (value instanceof Boolean) return value as Boolean
    if (value instanceof Number) return (value as Number).intValue() != 0
    String normalized = "${value}".trim().toLowerCase()
    if (normalized in ['true', '1']) return true
    if (normalized in ['false', '0']) return false
    return null
}

void processGetUserResponse(Map descMap) {
    if (!(descMap.value instanceof Map)) {
        logWarn "processGetUserResponse: malformed response value=${descMap.value}"
        if (state.pendingClearUser instanceof Map && state.pendingClearUser.stage in ['awaitingPreflight', 'awaitingGetUser']) {
            finishMatterClearUser(false, "malformed GetUser ${state.pendingClearUser.stage == 'awaitingPreflight' ? 'preflight' : 'verification'} response")
        } else if (state.pendingSetUser instanceof Map && state.pendingSetUser.stage in ['awaitingModifyPreflight', 'awaitingGetUser']) {
            finishMatterSetUser(false, "malformed GetUser ${state.pendingSetUser.stage == 'awaitingModifyPreflight' ? 'preflight' : 'verification'} response")
        }
        return
    }

    Map values = descMap.value as Map
    Integer userIndex = responseInt(responseField(values, 0, 'userIndex'))
    if (userIndex == null || userIndex < 1 || userIndex > 65534) {
        logWarn "processGetUserResponse: missing or invalid UserIndex in value=${descMap.value}"
        if (state.pendingClearUser instanceof Map && state.pendingClearUser.stage in ['awaitingPreflight', 'awaitingGetUser']) {
            finishMatterClearUser(false, "GetUser ${state.pendingClearUser.stage == 'awaitingPreflight' ? 'preflight' : 'verification'} response has no valid UserIndex")
        } else if (state.pendingSetUser instanceof Map && state.pendingSetUser.stage in ['awaitingModifyPreflight', 'awaitingGetUser']) {
            finishMatterSetUser(false, "GetUser ${state.pendingSetUser.stage == 'awaitingModifyPreflight' ? 'preflight' : 'verification'} response has no valid UserIndex")
        }
        return
    }

    String userName = responseString(responseField(values, 1, 'userName'))
    Long userUniqueID = responseLong(responseField(values, 2, 'userUniqueID'))
    Integer userStatus = responseInt(responseField(values, 3, 'userStatus'))
    Integer userType = responseInt(responseField(values, 4, 'userType'))
    Integer credentialRule = responseInt(responseField(values, 5, 'credentialRule'))
    List<Map> credentials = decodeGetUserCredentials(responseField(values, 6, 'credentials'))
    Integer creatorFabricIndex = responseInt(responseField(values, 7, 'creatorFabricIndex'))
    Integer lastModifiedFabricIndex = responseInt(responseField(values, 8, 'lastModifiedFabricIndex'))
    Integer nextUserIndex = responseInt(responseField(values, 9, 'nextUserIndex'))

    Map userMeta = [
        userIndex: userIndex,
        userName: userName,
        userUniqueID: userUniqueID,
        userStatus: userStatus,
        userStatusName: DoorLockClusterUserStatus[userStatus] ?: (userStatus != null ? "Unknown (${userStatus})" : null),
        userType: userType,
        userTypeName: DoorLockClusterUserType[userType] ?: (userType != null ? "Unknown (${userType})" : null),
        credentialRule: credentialRule,
        credentialRuleName: DoorLockClusterCredentialRule[credentialRule] ?: (credentialRule != null ? "Unknown (${credentialRule})" : null),
        credentials: credentials,
        creatorFabricIndex: creatorFabricIndex,
        lastModifiedFabricIndex: lastModifiedFabricIndex,
        nextUserIndex: nextUserIndex,
        updatedAt: now()
    ]

    Map userMetaByIndex = state.userMetaByIndex instanceof Map ? new HashMap(state.userMetaByIndex as Map) : [:]
    userMetaByIndex["${userIndex}"] = userMeta
    state.userMetaByIndex = userMetaByIndex
    syncGetUserCredentialMetadata(userMeta)

    String statusText = userMeta.userStatusName ?: 'null'
    String typeText = userMeta.userTypeName ?: 'null'
    String ruleText = userMeta.credentialRuleName ?: 'null'
    String credentialText = credentials.isEmpty()
        ? 'none'
        : credentials.collect { Map credential -> "${credential.credentialTypeName}#${credential.credentialIndex}" }.join(', ')
    String userNameText = userName == null ? 'null' : (userName.isEmpty() ? "'' (empty)" : userName)
    logInfo "GetUser Response: userIndex=${userIndex}, userName=${userNameText}, status=${statusText}, type=${typeText}, rule=${ruleText}, credentials=${credentialText}, nextUserIndex=${nextUserIndex}"
    handleMatterClearUserPreflightResponse(userMeta)
    handleMatterClearUserVerificationResponse(userMeta)
    handleMatterModifyPreflightResponse(userMeta)
    handleMatterSetUserVerificationResponse(userMeta)
    handleMatterUserScanResponse(userMeta)
}

private void handleMatterModifyPreflightResponse(Map userMeta) {
    Map pending = state.pendingSetUser instanceof Map ? state.pendingSetUser as Map : null
    if (pending == null || pending.stage != 'awaitingModifyPreflight') return

    Integer expectedIndex = safeNumberToInt(pending.userIndex, null)
    Integer actualIndex = responseInt(userMeta.userIndex)
    Integer userStatus = responseInt(userMeta.userStatus)
    Integer userType = responseInt(userMeta.userType)
    Integer credentialRule = responseInt(userMeta.credentialRule)
    if (actualIndex != expectedIndex) {
        finishMatterSetUser(false, "preflight GetUser returned UserIndex ${actualIndex}, expected ${expectedIndex}", userMeta)
        return
    }
    if (!(userStatus in [1, 3]) || userType == null || credentialRule == null) {
        finishMatterSetUser(false, "preflight GetUser found no occupied, complete user record at index ${expectedIndex}", userMeta)
        return
    }

    pending.originalUserName = userMeta.userName
    pending.userUniqueID = responseLong(userMeta.userUniqueID)
    pending.userStatus = userStatus
    pending.userType = userType
    pending.credentialRule = credentialRule
    pending.preflightCompletedAt = now()
    state.pendingSetUser = pending
    logDebug "matterModifyUser: preflight matched user ${expectedIndex}; sending complete existing record with the new name"
    sendMatterSetUserInvoke(pending)
}

private void handleMatterSetUserVerificationResponse(Map userMeta) {
    Map pending = state.pendingSetUser instanceof Map ? state.pendingSetUser as Map : null
    if (pending == null || pending.stage != 'awaitingGetUser') return

    Integer expectedIndex = safeNumberToInt(pending.userIndex, null)
    Integer actualIndex = responseInt(userMeta.userIndex)
    String expectedName = pending.userName != null ? "${pending.userName}" : null
    String actualName = userMeta.userName != null ? "${userMeta.userName}" : null
    Integer expectedStatus = safeNumberToInt(pending.userStatus, null)
    Integer expectedType = safeNumberToInt(pending.userType, null)
    Integer expectedRule = safeNumberToInt(pending.credentialRule, null)
    Integer actualStatus = responseInt(userMeta.userStatus)
    Integer actualType = responseInt(userMeta.userType)
    Integer actualRule = responseInt(userMeta.credentialRule)

    List<String> mismatches = []
    if (actualIndex != expectedIndex) {
        mismatches.add("UserIndex expected ${expectedIndex}, got ${actualIndex}")
    }
    if (expectedName != null && actualName != expectedName) {
        mismatches.add("UserName expected '${expectedName}', got '${actualName}'")
    }
    if (expectedStatus != null && actualStatus != expectedStatus) {
        mismatches.add("UserStatus expected ${expectedStatus}, got ${actualStatus}")
    }
    if (expectedType != null && actualType != expectedType) {
        mismatches.add("UserType expected ${expectedType}, got ${actualType}")
    }
    if (expectedRule != null && actualRule != expectedRule) {
        mismatches.add("CredentialRule expected ${expectedRule}, got ${actualRule}")
    }

    if (mismatches.isEmpty()) {
        finishMatterSetUser(true, 'GetUser verification matched all requested fields', userMeta)
    } else {
        finishMatterSetUser(false, "GetUser verification mismatch: ${mismatches.join('; ')}", userMeta, mismatches)
    }
}

private void handleMatterClearUserVerificationResponse(Map userMeta) {
    Map pending = state.pendingClearUser instanceof Map ? state.pendingClearUser as Map : null
    if (pending == null || pending.stage != 'awaitingGetUser') return

    Integer expectedIndex = safeNumberToInt(pending.userIndex, null)
    Integer actualIndex = responseInt(userMeta.userIndex)
    Integer actualStatus = responseInt(userMeta.userStatus)
    List<Map> actualCredentials = userMeta.credentials instanceof List ? userMeta.credentials as List<Map> : []
    List<String> mismatches = []

    if (actualIndex != expectedIndex) {
        mismatches.add("UserIndex expected ${expectedIndex}, got ${actualIndex}")
    }
    if (actualStatus != null && actualStatus != 0) {
        mismatches.add("UserStatus expected Available (0) or null, got ${actualStatus}")
    }
    if (userMeta.userName != null) {
        mismatches.add("UserName expected null, got '${userMeta.userName}'")
    }
    if (userMeta.userUniqueID != null) {
        mismatches.add("UserUniqueID expected null, got ${userMeta.userUniqueID}")
    }
    if (userMeta.userType != null) {
        mismatches.add("UserType expected null, got ${userMeta.userType}")
    }
    if (userMeta.credentialRule != null) {
        mismatches.add("CredentialRule expected null, got ${userMeta.credentialRule}")
    }
    if (!actualCredentials.isEmpty()) {
        mismatches.add("Credentials expected none, got ${actualCredentials.size()}")
    }
    if (userMeta.creatorFabricIndex != null) {
        mismatches.add("CreatorFabricIndex expected null, got ${userMeta.creatorFabricIndex}")
    }
    if (userMeta.lastModifiedFabricIndex != null) {
        mismatches.add("LastModifiedFabricIndex expected null, got ${userMeta.lastModifiedFabricIndex}")
    }

    if (mismatches.isEmpty()) {
        finishMatterClearUser(true, 'GetUser verification confirmed the user record is available', userMeta)
    } else {
        finishMatterClearUser(false, "GetUser verification mismatch: ${mismatches.join('; ')}", userMeta, mismatches)
    }
}

private Object responseField(Map values, Integer fieldId, String fieldName = null) {
    if (values == null) return null
    if (values.containsKey(fieldId)) return values[fieldId]
    String stringKey = "${fieldId}"
    if (values.containsKey(stringKey)) return values[stringKey]
    if (fieldName != null && values.containsKey(fieldName)) return values[fieldName]
    if (fieldName != null) {
        Object namedKey = values.keySet().find { Object key -> "${key}".equalsIgnoreCase(fieldName) }
        if (namedKey != null) return values[namedKey]
    }
    return null
}

private Boolean isMatterNull(Object value) {
    return value == null || "${value}".trim().equalsIgnoreCase('null')
}

private Integer responseInt(Object rawValue) {
    Object value = unwrapMatterValue(rawValue)
    return isMatterNull(value) ? null : safeNumberToInt(value, null)
}

private Long responseLong(Object rawValue) {
    Object value = unwrapMatterValue(rawValue)
    if (isMatterNull(value)) return null
    try {
        String stringValue = "${value}"
        return stringValue.startsWith('0x')
            ? Long.parseLong(stringValue.substring(2), 16)
            : Long.parseLong(stringValue)
    }
    catch (NumberFormatException ignored) {
        return null
    }
}

private String responseString(Object rawValue) {
    Object value = unwrapMatterValue(rawValue)
    if (isMatterNull(value)) return null
    return "${value}"
}

private Object unwrapMatterValue(Object value) {
    Object current = value
    List<String> wrapperNames = ['UINT', 'INT', 'ENUM', 'BOOL', 'STRING', 'UTF8', 'OCTET_STRING', 'OCTETSTRING', 'BYTE_STRING', 'BYTES', 'STRUCT', 'ARRAY', 'LIST']
    while (current instanceof Map && (current as Map).size() == 1) {
        Map wrapper = current as Map
        Object wrapperKey = wrapper.keySet().first()
        if (!wrapperNames.contains("${wrapperKey}".toUpperCase())) break
        current = wrapper[wrapperKey]
    }
    return current
}

private List<Map> decodeGetUserCredentials(Object rawCredentials) {
    List<Map> credentials = []
    appendGetUserCredentials(rawCredentials, credentials)
    return credentials
}

private void appendGetUserCredentials(Object rawValue, List<Map> credentials) {
    Object value = unwrapMatterValue(rawValue)
    if (isMatterNull(value)) return

    if (value instanceof Collection) {
        (value as Collection).each { Object item -> appendGetUserCredentials(item, credentials) }
        return
    }
    if (!(value instanceof Map)) {
        logWarn "processGetUserResponse: ignored malformed credential entry ${value}"
        return
    }

    Map credentialMap = value as Map
    Integer credentialType = responseInt(responseField(credentialMap, 0, 'credentialType'))
    Integer credentialIndex = responseInt(responseField(credentialMap, 1, 'credentialIndex'))
    if (credentialType != null && credentialIndex != null) {
        credentials.add([
            credentialType: credentialType,
            credentialTypeName: CredentialTypeEnum[credentialType] ?: "Unknown (${credentialType})",
            credentialIndex: credentialIndex
        ])
        return
    }

    // Hubitat may expose an ARRAY as a map of element indexes containing STRUCT wrappers.
    credentialMap.values().each { Object item -> appendGetUserCredentials(item, credentials) }
}

private void syncGetUserCredentialMetadata(Map userMeta) {
    Map credentialMetadata = state.credentialMetaByTypeAndIndex instanceof Map
        ? new HashMap(state.credentialMetaByTypeAndIndex as Map)
        : [:]
    ensureLockCodeStateMaps()

    Integer userIndex = responseInt(userMeta.userIndex)
    String userName = userMeta.userName != null ? "${userMeta.userName}" : null
    List<Map> credentials = userMeta.credentials instanceof List ? userMeta.credentials as List<Map> : []
    Map lockCodes = new HashMap(getLockCodes())
    Boolean lockCodesChanged = false

    credentials.each { Map credential ->
        Integer credentialType = responseInt(credential.credentialType)
        Integer credentialIndex = responseInt(credential.credentialIndex)
        if (credentialType == null || credentialIndex == null) return

        String metadataKey = "${credentialType}:${credentialIndex}"
        Map currentMetadata = credentialMetadata[metadataKey] instanceof Map
            ? credentialMetadata[metadataKey] as Map
            : [:]
        credentialMetadata[metadataKey] = [:] + currentMetadata + [
            credentialType: credentialType,
            credentialTypeName: CredentialTypeEnum[credentialType] ?: "Unknown (${credentialType})",
            credentialIndex: credentialIndex,
            userIndex: userIndex,
            userName: userName,
            updatedAt: now()
        ]

        // Hubitat lockCodes slots correspond to PIN credential indexes. Preserve the stored PIN;
        // GetUserResponse contains only CredentialStruct references and cannot retrieve PIN data.
        if (credentialType == 1) {
            String credentialKey = "${credentialIndex}"
            upsertCredentialMeta(credentialKey, [credentialType: credentialType, userIndex: userIndex, userName: userName])
            if (userName && lockCodes.containsKey(credentialKey)) {
                Map currentCode = lockCodes[credentialKey] instanceof Map ? lockCodes[credentialKey] as Map : [:]
                if (currentCode.name != userName) {
                    lockCodes[credentialKey] = [:] + currentCode + [name: userName]
                    lockCodesChanged = true
                }
            }
        }
    }

    state.credentialMetaByTypeAndIndex = credentialMetadata
    if (lockCodesChanged) { updateLockCodes(lockCodes) }
}

// 5.2.11. Events 
void processDoorLockEvent(Map eventMap) {
    def evtId = safeToInt(eventMap.evtId)
    logDebug "processDoorLockEvent: evtId=${evtId}"
    
    switch (evtId) {
        case 0x00: // DoorLockAlarm (0x00)
            processDoorLockAlarmEvent(eventMap)
            break
        case 0x01: // DoorStateChange (0x01)
            processDoorStateChangeEvent(eventMap)
            break
        case 0x02: // LockOperation (0x02)
            processLockOperationEvent(eventMap)
            break
        case 0x03: // LockOperationError (0x03)
            processLockOperationErrorEvent(eventMap)
            break
        case 0x04: // LockUserChange (0x04)
            processLockUserChangeEvent(eventMap)
            break
        default:
            logWarn "processDoorLockEvent: unknown evtId=${evtId}"
    }
}

void processDoorLockAlarmEvent(Map eventMap) {
    // Event fields: alarmCode
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    Integer alarmCode = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null

    String alarmText = DoorLockClusterAlarmCode[alarmCode] ?: "Unknown (${alarmCode})"
    String descriptionText = "${device.displayName} ALARM: ${alarmText}"

    logWarn "${descriptionText}"
    sendEvent(name: 'lockAlarm', value: alarmText, descriptionText: descriptionText, isStateChange: true)
}

void processDoorStateChangeEvent(Map eventMap) {
    // Event fields: doorState
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    Integer doorState = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null

    String doorStateText = DoorLockClusterDoorState[doorState] ?: "Unknown (${doorState})"
    String descriptionText = "${device.displayName} door is ${doorStateText}"

    logInfo "${descriptionText}"
    sendEvent(name: 'doorState', value: doorStateText, descriptionText: descriptionText)
}

// 5.2.11.3. LockOperation Event #2
// The door lock server sends out a LockUserChange event when a lock user, schedule, or credential change has occurred.
void processLockOperationEvent(Map eventMap) {
    // Event fields: lockOperationType, operationSource, userIndex, fabricIndex, sourceNode, credentials
    // eventMap = [callbackType:Event, endpointInt:1, clusterInt:257, evtId:2, timestamp:37455661, priority:2, 
    //           data:[2:STRUCT:[
    //              3:NULL:null,        // FabricIndex
    //              0:UINT:1,           // LockOperationType 
    //              1:UINT:7,           // OperationSource
    //              2:NULL:null,        // UserIndex
    //              5:NULL:null,        // Credentials
    //              4:NULL:null]],      // SourceNode
    //           value:[3:null, 0:1, 1:7, 2:null, 5:null, 4:null], 
    //           cluster:0101, endpoint:01]
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    logDebug "processLockOperationEvent: parsed values=${values}"

    Integer lockOpType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer opSource = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer userIndex = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    logDebug "processLockOperationEvent: lockOpType=${lockOpType}, opSource=${opSource}, userIndex=${userIndex}"

    String operation = DoorLockClusterLockOperationType[lockOpType] ?: "Unknown (${lockOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"

    String descriptionText = "${operation} by ${source}" + (userIndex != null ? " (User ${userIndex})" : "")

    // Optimized lock state mapping — handle 'unlocked with timeout' when triggered by unlockWithTimeout()
    String lockState
    if (lockOpType == 0) {
        lockState = 'locked'
        state.lastCmdIsTimeout = false
    } else if (lockOpType == 1 && state.lastCmdIsTimeout == true) {
        lockState = 'unlocked with timeout'
    } else if (lockOpType == 1) {
        lockState = 'unlocked'
    } else if (lockOpType == 4) {
        lockState = 'unlocked'   // Unlatch (unboltDoor); Hubitat Lock has no 'unlatched' state
    } else {
        lockState = 'unknown'
    }
    String lockDesc = "${device.displayName} is ${lockState} (${descriptionText})"

    // When userIndex is present (keypad/code unlock), resolve credential slot for LCM data matching.
    if (userIndex != null) {
        String credentialKey = resolveCredentialKeyFromUserIndex(userIndex) ?: "${userIndex}"
        Map lockcodes = getLockCodes()
        Map codeEntry = lockcodes[credentialKey]
        if (codeEntry == null) {
            // Auto-discover: credential is not in lockCodes yet — register it so LCM can track it
            String autoPin = String.valueOf(new Random().nextInt(900000) + 100000)  // random 6-digit placeholder
            codeEntry = [code: autoPin, name: "Code ${credentialKey}"]
            lockcodes[credentialKey] = codeEntry
            updateLockCodes(lockcodes)
            Map autoData = [(credentialKey): codeEntry]
            def autoEventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(autoData)) : autoData
            logLockCodeEventPayload('codeChanged', 'added', autoData)
            sendEvent(name: 'codeChanged', value: 'added', data: autoEventData, descriptionText: "${device.displayName} auto-discovered credential at slot ${credentialKey}", isStateChange: true)
            logInfo "processLockOperationEvent: auto-discovered credential at slot ${credentialKey} — registered in lockCodes"
        }
        lockDesc = "${device.displayName} is ${lockState} by ${source.toLowerCase()} (${codeEntry.name})"
        Map codeData = [(credentialKey): codeEntry]
        def lockEventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(codeData)) : codeData
        logLockCodeEventPayload('lock', lockState, codeData)
        sendEvent(name: 'lock', value: lockState, data: lockEventData, descriptionText: lockDesc, isStateChange: true)
        sendEvent(name: 'lastCodeName', value: codeEntry.name, descriptionText: "${device.displayName} operated by ${codeEntry.name}", isStateChange: true)
        upsertCredentialMeta(credentialKey, [
            userIndex: userIndex,
            credentialIndex: safeToInt(credentialKey),
            operationSource: opSource,
            operationSourceName: source
        ])
        logDebug "processLockOperationEvent: userIndex=${userIndex} -> credential=${credentialKey}, codeName='${codeEntry.name}'"
    } else {
        sendEvent(name: 'lock', value: lockState, descriptionText: lockDesc, isStateChange: true)
    }

    logInfo lockDesc
    sendEvent(name: 'lastLockOperation', value: operation, descriptionText: descriptionText, isStateChange: true)
    sendEvent(name: 'lastOperationSource', value: source, descriptionText: descriptionText, isStateChange: true)
}

// LockOperationError (0x03)
void processLockOperationErrorEvent(Map eventMap) {
    // Event fields: lockOperationType, operationSource, operationError, userIndex, fabricIndex, sourceNode, credentials
    logDebug "processLockOperationErrorEvent: description=${eventMap}"
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    logDebug "processLockOperationErrorEvent: parsed values=${values}"

    Integer lockOpType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer opSource = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer opError = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    Integer userIndex = values[3] != null && values[3] != 'null' ? safeToInt(values[3]) : null

    String operation = DoorLockClusterLockOperationType[lockOpType] ?: "Unknown (${lockOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"
    String error = DoorLockClusterOperationError[opError] ?: "Unknown (${opError})"

    String descriptionText = "${device.displayName} ${operation} FAILED: ${error} (source: ${source}"
    if (userIndex != null) {
        descriptionText += ", User ${userIndex}"
    }
    descriptionText += ")"

    logWarn "*** ${descriptionText} ***"
    sendEvent(name: 'lastLockOperationError', value: error, descriptionText: descriptionText, isStateChange: true)
}

// LockUserChange (0x04) event
// Observed U200 behavior:
//   setCode(pos)   → TWO events: PIN Add (DataIndex=codePosition) then UserIndex Add (DataIndex=userSlot)
//   deleteCode(pos)→ ONE event:  UserIndex Clear (DataIndex=userSlot; codePosition NOT in event)
//
// codeChanged deduplication strategy:
//   - recent command confirmation: response/event counterpart updates metadata but does not re-fire codeChanged
//   - isSettingCode==true   : LockUserChange arrived first or Invoke callbacks are unavailable → complete setCode
//   - isDeletingCode==true  : deleteCode waiting for confirmation → fire 'deleted' + sync lockCodes
//   - isPinEvent (type==PIN): external credential change → fire codeChanged
//   - UserIndex Add/Modify  : follow-up from our setCode or unhandled → suppress codeChanged
//   - UserIndex Clear (external): external delete → fire 'deleted', warn lockCodes may be out of sync
void processLockUserChangeEvent(Map description) {
    Map values = description.value instanceof Map ? description.value : [:]

    Integer lockDataType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer dataOpType   = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer opSource     = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    Integer userIndex    = values[3] != null && values[3] != 'null' ? safeToInt(values[3]) : null
    Integer fabricIndex  = values[4] != null && values[4] != 'null' ? safeToInt(values[4]) : null
    Integer sourceNode   = values[5] != null && values[5] != 'null' ? safeToInt(values[5]) : null
    Integer dataIndex    = values[6] != null && values[6] != 'null' ? safeToInt(values[6]) : null

    String dataType  = DoorLockClusterLockDataType[lockDataType] ?: "Unknown (${lockDataType})"
    String operation = DoorLockClusterDataOperationType[dataOpType] ?: "Unknown (${dataOpType})"
    String source    = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"

    logDebug "processLockUserChangeEvent: type=${dataType}(${lockDataType}), op=${operation}, user=${userIndex}, dataIdx=${dataIndex}, source=${source}"
    Boolean pendingClearUserEvent = isPendingClearUserEvent(lockDataType, dataOpType, userIndex, dataIndex)

    // Recover Hubitat credential slot where possible.
    boolean isPinEvent = (lockDataType == 0x06)
    Map recentClearConfirmation = getRecentClearCredentialConfirmation()
    String credentialKey = null
    if (isPinEvent && dataIndex != null) {
        credentialKey = "${dataIndex}"   // PIN events carry credential index in DataIndex
    } else if (state.isDeletingCode && state.lastDeleteCode?.codePosition != null) {
        credentialKey = "${state.lastDeleteCode.codePosition}" // command correlation for deleteCode()
    } else if (dataOpType == 1 && recentClearConfirmation != null) {
        Integer recentUserIndex = safeToInt(recentClearConfirmation.userIndex, null)
        if (recentUserIndex != null && (userIndex == recentUserIndex || dataIndex == recentUserIndex)) {
            credentialKey = recentClearConfirmation.credentialKey != null ? "${recentClearConfirmation.credentialKey}" : null
        }
    }
    if (credentialKey == null && dataOpType == 1 && userIndex != null) {
        // External UserIndex Clear: try resolving slot from metadata learned from prior events.
        credentialKey = resolveCredentialKeyFromUserIndex(userIndex)
    }
    ensureLockCodeStateMaps()
    if (credentialKey == null && state.isSettingCode == true && state.pendingSetByCredential?.size() == 1) {
        // Fallback when lock omits expected slot fields for set confirmation.
        credentialKey = state.pendingSetByCredential.keySet().first()
    }
    Integer codePosition = credentialKey != null ? safeToInt(credentialKey) : null
    Boolean recentClearEvent = isRecentClearCredentialEvent(credentialKey, userIndex, dataIndex, dataOpType)

    if (credentialKey != null && !recentClearEvent && !pendingClearUserEvent) {
        upsertCredentialMeta(credentialKey, [
            userIndex: userIndex,
            credentialIndex: codePosition,
            lastDataIndex: dataIndex,
            lastDataType: lockDataType,
            lastDataOperationType: dataOpType,
            lastSource: opSource,
            lastSourceName: source,
            fabricIndex: fabricIndex,
            sourceNode: sourceNode
        ])
    }

    String posText = codePosition != null ? " [pos=${codePosition}]" : ""
    String descriptionText = "${device.displayName}${posText} ${dataType} ${operation}"
    if (userIndex    != null) { descriptionText += " for User ${userIndex}" }
    if (dataIndex    != null) { descriptionText += ", (Data Index ${dataIndex})" }
    if (fabricIndex  != null) { descriptionText += ", (Fabric ${fabricIndex})" }
    if (sourceNode   != null) { descriptionText += ", (Node ${sourceNode})" }
    descriptionText += " (source: ${source})"

    logInfo "${descriptionText}"
    sendEvent(name: 'lastUserChange', value: "${operation} ${dataType}", descriptionText: descriptionText, isStateChange: true)

    // --- codeChanged and lockCodes sync ---
    if (pendingClearUserEvent) {
        Map clearEvent = [
            receivedAt: now(),
            lockDataType: lockDataType,
            dataOperationType: dataOpType,
            userIndex: userIndex,
            dataIndex: dataIndex,
            operationSource: opSource
        ]
        Map pending = state.pendingClearUser instanceof Map ? state.pendingClearUser as Map : null
        Map recent = getRecentClearUserConfirmation()
        Integer clearUserIndex = pending != null
            ? safeNumberToInt(pending.userIndex, null)
            : safeNumberToInt(recent?.userIndex, null)
        if (pending != null) {
            pending.clearEvent = clearEvent
            state.pendingClearUser = pending
        } else if (recent != null) {
            recent.clearEvent = clearEvent
            state.recentClearUserConfirmation = recent
        }
        logDebug "processLockUserChangeEvent: suppressing codeChanged for standalone ClearUser user ${clearUserIndex}"
        return
    }
    if (recentClearEvent) {
        String matchedCredentialKey = credentialKey ?: (recentClearConfirmation?.credentialKey != null ? "${recentClearConfirmation.credentialKey}" : 'unknown')
        logDebug "processLockUserChangeEvent: deleteCode slot ${matchedCredentialKey} was already completed from ${recentClearConfirmation?.source}; duplicate codeChanged suppressed"
        return
    }

    // Overwrite mode: intercept the Clear confirmation and proceed with the Add step
    if (state.isOverwritingCode == true && dataOpType == 1) {
        state.isOverwritingCode = false
        unschedule('proceedWithOverwriteAdd')  // slot was occupied and cleared — cancel the fallback timer
        // Use state.overwriteSlot (not the event-derived codePosition) — Aqara U200 reports dataIndex=N-1 for credentialIndex=N
        Integer overwriteSlot = safeToInt(state.overwriteSlot)
        String overwriteKey = "${overwriteSlot}"
        Map pendingEntry = state.pendingSetByCredential?.get(overwriteKey)
        if (pendingEntry != null) {
            logInfo "setCode: overwrite — slot ${overwriteSlot} cleared, now adding new PIN"
            matterSetCredentialPIN(overwriteSlot as BigDecimal, pendingEntry.pinCode)
        } else {
            logWarn "setCode: overwrite clear received but no pending entry for slot ${overwriteSlot} — aborting"
            clearSetCodeOperationState(overwriteKey, true)
            sendEvent(name: 'codeChanged', value: 'failed', descriptionText: "${device.displayName} setCode overwrite failed: no pending data for slot ${overwriteSlot}", isStateChange: true)
        }
        return
    }
    if (isRecentSetCredentialEvent(credentialKey, userIndex, dataOpType)) {
        Map recentConfirmation = getRecentSetCredentialConfirmation()
        String matchedCredentialKey = credentialKey ?: (recentConfirmation?.credentialKey != null ? "${recentConfirmation.credentialKey}" : 'unknown')
        logDebug "processLockUserChangeEvent: setCode slot ${matchedCredentialKey} was already completed from SetCredentialResponse; duplicate codeChanged suppressed"
        return
    }
    if (state.isSettingCode == true) {
        // Legacy fallback for Hubitat versions without Invoke callbacks, and for locks that emit the event first.
        if (!completePendingSetCode(credentialKey, userIndex, descriptionText, 'LockUserChange')) {
            logWarn "processLockUserChangeEvent: setCode confirmation received but pending data for slot ${credentialKey} is unavailable"
        }

    } else if (state.isDeletingCode == true && dataOpType == 1) {
        // Legacy fallback when LockUserChange arrives before (or instead of) the Invoke callback.
        completePendingDeleteCode('LockUserChange event', true, descriptionText)

    } else if (isPinEvent) {
        // External PIN credential change (not from our commands)
        String hubitatOperation = HubitatCodeChangedType[dataOpType] ?: 'unknown'
        Map extPinData
        if (dataOpType == 1 && credentialKey != null) {
            extPinData = [(credentialKey): getLockCodes()[credentialKey] ?: [:]]
        } else if (dataOpType == 0 && credentialKey != null) {
            Map lockcodes = getLockCodes()
            Map codeEntry = lockcodes[credentialKey]
            if (codeEntry == null) {
                String autoPin = String.valueOf(new Random().nextInt(900000) + 100000)
                codeEntry = [code: autoPin, name: "Code ${credentialKey}"]
                lockcodes[credentialKey] = codeEntry
                updateLockCodes(lockcodes)
                logInfo "processLockUserChangeEvent: external PIN Add at slot ${credentialKey} registered in lockCodes with a placeholder PIN"
            }
            extPinData = [(credentialKey): codeEntry]
        } else {
            extPinData = credentialKey != null ? [(credentialKey): [name: "Code ${credentialKey}"]] : [:]
        }
        def extPinEventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(extPinData)) : extPinData
        logLockCodeEventPayload('codeChanged', hubitatOperation, extPinData)
        sendEvent(name: 'codeChanged', value: hubitatOperation, data: extPinEventData, descriptionText: descriptionText, isStateChange: true)
        if (dataOpType == 1 && codePosition != null) {
            removeLockCode(codePosition)   // external PIN Clear — remove from lockCodes
            removeCredentialMeta("${codePosition}")
        } else if (dataOpType == 0 && credentialKey != null) {
            logDebug "processLockUserChangeEvent: external PIN Add at slot ${credentialKey} is now tracked in lockCodes"
        } else {
            logWarn "processLockUserChangeEvent: external credential change (pos=${codePosition}) — lockCodes attribute not automatically synced"
        }

    } else if (dataOpType == 1) {
        // UserIndex Clear with no pending deleteCode — external delete; try metadata mapping.
        String posDesc = credentialKey != null ? "pos=${credentialKey}" : "userIndex=${userIndex}"
        if (credentialKey == null) {
            logWarn "processLockUserChangeEvent: external credential delete (${posDesc}) — lockCodes attribute not automatically synced"
        } else {
            logInfo "processLockUserChangeEvent: external credential delete resolved (${posDesc})"
        }
        Map extDelEntry = credentialKey != null ? (getLockCodes()[credentialKey] ?: [:]) : [:]
        Map extDelData = credentialKey != null ? [(credentialKey): extDelEntry] : [:]
        def extDelEventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(extDelData)) : extDelData
        logLockCodeEventPayload('codeChanged', 'deleted', extDelData)
        sendEvent(name: 'codeChanged', value: 'deleted', data: extDelEventData, descriptionText: descriptionText, isStateChange: true)
        if (credentialKey != null && codePosition != null) {
            removeLockCode(codePosition)
            removeCredentialMeta("${codePosition}")
        }

    } else {
        // UserIndex Add/Modify follow-up or other unhandled type — suppress codeChanged
        logDebug "processLockUserChangeEvent: suppressing codeChanged for non-PIN ${operation} event (type=${dataType})"
    }
}

private Boolean isPendingClearUserEvent(Integer lockDataType, Integer dataOpType, Integer userIndex, Integer dataIndex) {
    Map pending = state.pendingClearUser instanceof Map ? state.pendingClearUser as Map : null
    Integer expectedUserIndex = pending != null && pending.stage in ['awaitingInvoke', 'awaitingGetUser']
        ? safeNumberToInt(pending.userIndex, null)
        : safeNumberToInt(getRecentClearUserConfirmation()?.userIndex, null)
    return lockDataType == 0x02 && dataOpType == 0x01 &&
        expectedUserIndex != null && (userIndex == expectedUserIndex || dataIndex == expectedUserIndex)
}

private Map getRecentClearUserConfirmation() {
    Map recent = state.recentClearUserConfirmation instanceof Map ? state.recentClearUserConfirmation as Map : null
    if (recent == null) return null
    Long expiresAt = recent.expiresAt != null ? recent.expiresAt as Long : 0L
    if (expiresAt <= now()) {
        state.remove('recentClearUserConfirmation')
        return null
    }
    return recent
}

// Remove a code entry from the lockCodes attribute by Hubitat codePosition
private void removeLockCode(Integer codePosition) {
    Map lockcodes = new HashMap(getLockCodes())   // copy into mutable HashMap to avoid LazyMap.remove() issues
    String key = "${codePosition}"
    if (lockcodes.containsKey(key)) {
        lockcodes.remove(key)
        updateLockCodes(lockcodes)
        logDebug "removeLockCode: removed codePosition=${codePosition} from lockCodes"
    } else {
        logDebug "removeLockCode: codePosition=${codePosition} not found in lockCodes (already removed or never added)"
    }
}

// ---- Lock code helpers (Hubitat Lock Code Manager compatibility) ----

private void ensureLockCodeStateMaps() {
    if (state.pendingSetByCredential == null) { state.pendingSetByCredential = [:] }
    if (state.codeMetaByCredential == null) { state.codeMetaByCredential = [:] }
    if (state.lastProcessedEventSerialById == null) { state.lastProcessedEventSerialById = [:] }
}

private void ensureStats() {
    if (state.stats == null) { state.stats = [:] }
    if (state.stats.totalEvents    == null) { state.stats.totalEvents    = 0 }
    if (state.stats.duplicateEvents == null) { state.stats.duplicateEvents = 0 }
    if (state.stats.outOfOrderEvents == null) { state.stats.outOfOrderEvents = 0 }
    if (state.stats.lastSerialByStream == null) { state.stats.lastSerialByStream = [:] }
}

void clearStatistics() {
    state.stats = [totalEvents: 0, duplicateEvents: 0, outOfOrderEvents: 0, lastSerialByStream: [:]]
    state.seenDoorLockEvents = [:]
    logInfo 'clearStatistics: event statistics and duplicate-event cache cleared'
}

private Boolean isDuplicateDoorLockEvent(Map descMap) {
    if (descMap?.callbackType != "Event") return false
    if ((descMap.clusterInt as Integer) != 0x0101) return false
    if (descMap.eventSerial == null) return false

    ensureStats()
    state.stats.totalEvents = (state.stats.totalEvents as Integer) + 1

    // Out-of-order detection: compare serial against highest seen for this stream
    String streamKey = "${descMap.endpointInt}:${descMap.clusterInt}:${descMap.evtId}"
    Long currentSerial = descMap.eventSerial as Long
    Long lastSerial = state.stats.lastSerialByStream[streamKey] != null ? (state.stats.lastSerialByStream[streamKey] as Long) : null
    if (lastSerial != null && currentSerial < lastSerial) {
        state.stats.outOfOrderEvents = (state.stats.outOfOrderEvents as Integer) + 1
        logDebug "isDuplicateDoorLockEvent: out-of-order event detected stream=${streamKey}, serial=${currentSerial} < lastSeen=${lastSerial}"
    }
    if (lastSerial == null || currentSerial > lastSerial) {
        state.stats.lastSerialByStream[streamKey] = currentSerial
    }

    String key = "${descMap.endpointInt}:${descMap.clusterInt}:${descMap.evtId}:${descMap.eventSerial}"
    Long nowMs = now()

    Map seen = state.seenDoorLockEvents ?: [:]

    // Keep only recent events
    seen = seen.findAll { k, v ->
        (nowMs - ((v ?: 0L) as Long)) < 10000L
    }

    if (seen.containsKey(key)) {
        state.stats.duplicateEvents = (state.stats.duplicateEvents as Integer) + 1
        logDebug "Duplicate DoorLock event suppressed: ${key}"
        state.seenDoorLockEvents = seen
        return true
    }

    seen[key] = nowMs
    state.seenDoorLockEvents = seen
    return false
}

private String resolveCredentialKeyFromUserIndex(Integer userIndex) {
    if (userIndex == null) return null
    ensureLockCodeStateMaps()
    String direct = "${userIndex}"
    if (getLockCodes().containsKey(direct)) {
        return direct
    }
    def found = state.codeMetaByCredential.find { String k, def v ->
        safeToInt(v?.userIndex) == userIndex
    }
    return found?.key
}

private void upsertCredentialMeta(String credentialKey, Map patch) {
    if (credentialKey == null) return
    ensureLockCodeStateMaps()
    Map credentialMetadata = new HashMap(state.codeMetaByCredential as Map)
    Map cur = credentialMetadata[credentialKey] instanceof Map ? credentialMetadata[credentialKey] as Map : [:]
    Map merged = [:] + cur + (patch ?: [:])
    merged.updatedAt = now()
    credentialMetadata[credentialKey] = merged
    state.codeMetaByCredential = credentialMetadata
}

private void removeCredentialMeta(String credentialKey) {
    if (credentialKey == null) return
    ensureLockCodeStateMaps()
    Map credentialMetadata = new HashMap(state.codeMetaByCredential as Map)
    credentialMetadata.remove(credentialKey)
    state.codeMetaByCredential = credentialMetadata
}

private Map redactLockCodePayload(Map payload) {
    Map redacted = [:]
    (payload ?: [:]).each { String slot, def entry ->
        if (entry instanceof Map) {
            Map copy = [:] + (Map) entry
            if (copy.containsKey('code')) {
                String codeString = copy.code != null ? "${copy.code}" : ''
                copy.code = codeString ? ('*' * codeString.length()) : ''
                copy.codeLength = codeString.length()
            }
            redacted[slot] = copy
        } else {
            redacted[slot] = entry
        }
    }
    return redacted
}

private void logLockCodeEventPayload(String eventName, String eventValue, Map payload) {
    Map redacted = redactLockCodePayload(payload)
    String mode = settings?.optEncrypt ? 'encrypted' : 'plain'
    logDebug "sendEvent payload: name=${eventName}, value=${eventValue}, mode=${mode}, data=${redacted}"
}

// Read the lockCodes attribute and return as a Map; handles optional encryption transparently.
private Map getLockCodes() {
    String current = device.currentValue('lockCodes') ?: '{}'
    try {
        if (current[0] != '{') { current = decrypt(current) }  // encrypted strings don\'t start with '{'
        return parseJson(current) ?: [:]
    } catch (Exception e) {
        logWarn "getLockCodes: failed to parse lockCodes: ${e.message}"
        return [:]
    }
}

// Serialize lockCodes Map and send as the lockCodes attribute, encrypting if optEncrypt is set.
private void updateLockCodes(Map lockcodes) {
    String json = JsonOutput.toJson(lockcodes ?: [:])
    String value = settings?.optEncrypt ? encrypt(json) : json
    logLockCodeEventPayload('lockCodes', 'updated', lockcodes ?: [:])
    sendEvent(name: 'lockCodes', value: value, isStateChange: true)
}

// Re-encrypt or decrypt the stored lockCodes attribute when the optEncrypt preference changes.
private void updateEncryption() {
    String current = device.currentValue('lockCodes')
    if (!current) return
    if (settings?.optEncrypt && current[0] == '{') {        // currently plain — re-send encrypted
        sendEvent(name: 'lockCodes', value: encrypt(current), isStateChange: true)
    } else if (!settings?.optEncrypt && current[0] != '{') {  // currently encrypted — re-send plain
        sendEvent(name: 'lockCodes', value: decrypt(current), isStateChange: true)
    }
}

// Command to get all supported Door Lock attributes (for info/debugging)
void getInfo() {
    // Check if Door Lock cluster is supported
    if (!isClusterSupported('0101')) {
        logWarn "getInfo: Door Lock cluster (0x0101) is not supported by this device"
        logInfo "getInfo: ServerList contains: ${getServerList()}"
        return
    }
    List<String> expectedAttrs = getDoorLockAttributeList()
    logInfo "getInfo: reading all supported Door Lock attributes: ${expectedAttrs}"
    
    // Set state flags for info mode
    if (state.states == null) { state.states = [:] }
    if (state.lastTx == null) { state.lastTx = [:] }
    state.states.isInfo = true
    state.states.infoBuffer = []
    state.states.infoExpectedAttrs = expectedAttrs.collect { it }
    state.lastTx.infoTime = now()
    
    // Schedule job to turn off info mode after 10 seconds (fallback flush)
    runIn(10, 'clearInfoMode')
    
    String endpointHex = device.getDataValue('id') ?: '1'
    Integer endpoint = HexUtils.hexStringToInt(endpointHex)
    parent?.readAttribute(endpoint, 0x0101, -1)      // 0x00 Door Lock cluster - read all attributes
    // battery info is processed in parent driver !
    // parent?.readAttribute(endpoint, 0x002F, -1)       // 0x002F Power Source cluster - read all attributes
}

// Flush accumulated getInfo buffer to a single logInfo entry
void flushInfoBuffer() {
    List<String> buf = state.states?.infoBuffer ?: []
    if (buf) {
        buf.sort { String line -> line.substring(1, 5) }   // sort by [XXXX] attrId prefix
        logInfo "getInfo:<br>" + buf.join('<br>')
    }
    if (state.states == null) { state.states = [:] }
    state.states.infoBuffer = []
    state.states.infoExpectedAttrs = null
    state.states.isInfo = false
    unschedule('clearInfoMode')
}

// Clear info mode flag (timeout fallback — flushes any buffered lines)
void clearInfoMode() {
    flushInfoBuffer()
    logDebug "clearInfoMode: info mode disabled"
}

// ============ Matter Door Lock Cluster Attributes Map ============
// Complete list of all Door Lock cluster (0x0101) attributes per Matter spec
@Field static final Map<Integer, String> DoorLockClusterAttributes = [
    // Mandatory and common attributes
    0x0000  : 'LockState',                                          // LockStateEnum, R V, M
    0x0001  : 'LockType',                                           // LockTypeEnum, R V, M
    0x0002  : 'ActuatorEnabled',                                    // bool, R V, M
    0x0003  : 'DoorState',                                          // DoorStateEnum, R V, DPS
    0x0004  : 'DoorOpenEvents',                                     // uint32, RW, DPS
    0x0005  : 'DoorClosedEvents',                                   // uint32, RW, DPS
    0x0006  : 'OpenPeriod',                                         // uint16, RW, DPS
    
    // User and credential management
    0x0010  : 'NumberOfLogRecordsSupported',                        // uint16, R V, O
    0x0011  : 'NumberOfTotalUsersSupported',                        // uint16, R V, USR
    0x0012  : 'NumberOfPINUsersSupported',                          // uint16, R V, PIN
    0x0013  : 'NumberOfRFIDUsersSupported',                         // uint16, R V, RID
    0x0014  : 'NumberOfWeekDaySchedulesSupportedPerUser',           // uint8, R V, WDSCH
    0x0015  : 'NumberOfYearDaySchedulesSupportedPerUser',           // uint8, R V, YDSCH
    0x0016  : 'NumberOfHolidaySchedulesSupported',                  // uint8, R V, HDSCH
    0x0017  : 'MaxPINCodeLength',                                   // uint8, R V, PIN
    0x0018  : 'MinPINCodeLength',                                   // uint8, R V, PIN
    0x0019  : 'MaxRFIDCodeLength',                                  // uint8, R V, RID
    0x001A  : 'MinRFIDCodeLength',                                  // uint8, R V, RID
    0x001B  : 'CredentialRulesSupport',                             // DlCredentialRuleMask, R V, USR
    0x001C  : 'NumberOfCredentialsSupportedPerUser',                // uint8, R V, USR
    
    // Lock configuration attributes
    0x0020  : 'EnableLogging',                                      // bool, RW, O
    0x0021  : 'Language',                                           // string, RW, O
    0x0022  : 'LEDSettings',                                        // uint8, RW, O
    0x0023  : 'AutoRelockTime',                                     // uint32, RW, O
    0x0024  : 'SoundVolume',                                        // uint8, RW, O
    0x0025  : 'OperatingMode',                                      // OperatingModeEnum, RW, M
    0x0026  : 'SupportedOperatingModes',                            // DlSupportedOperatingModes, R V, M
    0x0027  : 'DefaultConfigurationRegister',                       // DlDefaultConfigurationRegister, R V, O
    0x0028  : 'EnableLocalProgramming',                             // bool, RW, O
    0x0029  : 'EnableOneTouchLocking',                              // bool, RW, O
    0x002A  : 'EnableInsideStatusLED',                              // bool, RW, O
    0x002B  : 'EnablePrivacyModeButton',                            // bool, RW, O
    0x002C  : 'LocalProgrammingFeatures',                           // DlLocalProgrammingFeatures, RW, O
    
    // Security and access control
    0x0030  : 'WrongCodeEntryLimit',                                // uint8, RW, O
    0x0031  : 'UserCodeTemporaryDisableTime',                       // uint8, RW, O
    0x0032  : 'SendPINOverTheAir',                                  // bool, RW, O
    0x0033  : 'RequirePINforRemoteOperation',                       // bool, RW, O
    0x0034  : 'SecurityLevel',                                      // SecurityLevelEnum, RW, O (Deprecated)
    0x0035  : 'ExpiringUserTimeout',                                // uint16, RW, O
    
    // Event masks (Notification feature)
    0x0040  : 'AlarmMask',                                          // DlAlarmMask, RW, NOT
    0x0041  : 'KeypadOperationEventMask',                           // DlKeypadOperationEventMask, RW, NOT
    0x0042  : 'RemoteOperationEventMask',                           // DlRemoteOperationEventMask, RW, NOT
    0x0043  : 'ManualOperationEventMask',                           // DlManualOperationEventMask, RW, NOT
    0x0044  : 'RFIDOperationEventMask',                             // DlRFIDOperationEventMask, RW, NOT
    0x0045  : 'KeypadProgrammingEventMask',                         // DlKeypadProgrammingEventMask, RW, NOT
    0x0046  : 'RemoteProgrammingEventMask',                         // DlRemoteProgrammingEventMask, RW, NOT
    0x0047  : 'RFIDProgrammingEventMask',                           // DlRFIDProgrammingEventMask, RW, NOT
    
    // Standard cluster attributes
    0xFFF8  : 'GeneratedCommandList',                               // list, R V, M
    0xFFF9  : 'AcceptedCommandList',                                // list, R V, M
    0xFFFB  : 'AttributeList',                                      // list, R V, M
    0xFFFC  : 'FeatureMap',                                         // FeatureMap, R V, M
    0xFFFD  : 'ClusterRevision'                                     // uint16, R V, M
]

// Aqara U200 : [FFF9] AcceptedCommandList: [0000, 0001, 0003, 001A, 001B, 001D, 0022, 0024, 0026]
// Aqara U200 : [FFF8] GeneratedCommandList: [001C, 0023, 0025]

@Field static final Map<Integer, String> DoorLockClusterCommands = [
    // Command ID : Name (per Matter 5.2.10)
    0x00    : 'LockDoor',                    // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:M
    0x01    : 'UnlockDoor',                  // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:M
    0x02    : 'Toggle',                      // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:X
    0x03    : 'UnlockWithTimeout',           // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:O
    0x04    : 'GetLogRecord',                // Direction:client ⇒ server; Response:GetLogRecordResponse; Access:M; Conformance:LOG
    0x05    : 'SetPINCode',                  // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x06    : 'GetPINCode',                  // Direction:client ⇒ server; Response:GetPINCodeResponse; Access:A; Conformance:!USR & PIN
    0x07    : 'ClearPINCode',                // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x08    : 'ClearAllPINCodes',            // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x09    : 'SetUserStatus',               // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x0A    : 'GetUserStatus',               // Direction:client ⇒ server; Response:GetUserStatusResponse; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x0B    : 'SetWeekDaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:WDSCH
    0x0C    : 'GetWeekDaySchedule',          // Direction:client ⇒ server; Response:GetWeekDayScheduleResponse; Access:A; Conformance:WDSCH
    0x0D    : 'ClearWeekDaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:WDSCH
    0x0E    : 'SetYearDaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:YDSCH
    0x0F    : 'GetYearDaySchedule',          // Direction:client ⇒ server; Response:GetYearDayScheduleResponse; Access:A; Conformance:YDSCH
    0x10    : 'ClearYearDaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:YDSCH
    0x11    : 'SetHolidaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:HDSCH
    0x12    : 'GetHolidaySchedule',          // Direction:client ⇒ server; Response:GetHolidayScheduleResponse; Access:A; Conformance:HDSCH
    0x13    : 'ClearHolidaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:HDSCH
    0x14    : 'SetUserType',                 // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x15    : 'GetUserType',                 // Direction:client ⇒ server; Response:GetUserTypeResponse; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x16    : 'SetRFIDCode',                 // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x17    : 'GetRFIDCode',                 // Direction:client ⇒ server; Response:GetRFIDCodeResponse; Access:A; Conformance:!USR & RID
    0x18    : 'ClearRFIDCode',               // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x19    : 'ClearAllRFIDCodes',           // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x1A    : 'SetUser',                     // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x1B    : 'GetUser',                     // Direction:client ⇒ server; Response:GetUserResponse; Access:A; Conformance:USR
    0x1C    : 'GetUserResponse',             // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x1D    : 'ClearUser',                   // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x20    : 'OperatingEventNotification',  // Direction:client ⇐ server; Response:No; Access:N; Conformance:[NOT]
    0x21    : 'ProgrammingEventNotification',// Direction:client ⇐ server; Response:No; Access:N; Conformance:[NOT]
    0x22    : 'SetCredential',               // Direction:client ⇒ server; Response:SetCredentialResponse; Access:A T; Conformance:USR
    0x23    : 'SetCredentialResponse',       // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x24    : 'GetCredentialStatus',         // Direction:client ⇒ server; Response:GetCredentialStatusResponse; Access:A; Conformance:USR
    0x25    : 'GetCredentialStatusResponse', // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x26    : 'ClearCredential',             // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x27    : 'UnboltDoor'                   // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:UBOLT
]



// 5.2.10.37 SetCredentialResponse status field (DlStatus)
@Field static final Map<Integer, String> DoorLockClusterDlStatus = [
    0x00    : 'Success',
    0x01    : 'Failure',
    0x02    : 'Duplicate',
    0x03    : 'Occupied',
    0x85    : 'InvalidField',
    0x89    : 'ResourceExhausted',
    0x8B    : 'NotFound'
]

// 5.2.6.2. LockState Attribute (0x0000)
@Field static final Map<Integer, String> DoorLockClusterLockState = [
    0x00    : 'NotFullyLocked',
    0x01    : 'Locked',
    0x02    : 'Unlocked',
    0x03    : 'Unlatched'   // optional
]

// 5.2.6.3. LockType Attribute (0x0001)
@Field static final Map<Integer, String> DoorLockClusterLockType = [
    0x00    : 'deadbolt',           // Physical lock type is dead bolt
    0x01    : 'magnetic',           // Physical lock type is magnetic
    0x02    : 'other',              // Physical lock type is other
    0x03    : 'mortise',            // Physical lock type is mortise
    0x04    : 'rim',                // Physical lock type is rim
    0x05    : 'latchbolt',          // Physical lock type is latch bolt
    0x06    : 'cylindricalLock',    // Physical lock type is cylindrical lock
    0x07    : 'tubularLock',        // Physical lock type is tubular lock
    0x08    : 'interconnectedLock', // Physical lock type is interconnected lock
    0x09    : 'deadLatch',          // Physical lock type is dead latch
    0x0A    : 'doorFurniture',      // Physical lock type is door furniture
    0x0B    : 'eurocylinder'        // Physical lock type is eurocylinder
]

/*
The ActuatorEnabled attribute indicates if the lock is currently able to (Enabled) or not able to (Disabled)
process remote Lock, Unlock, or Unlock with Timeout commands.
This attribute has the following possible values:
Boolean Value Summary
0 Disabled
1 Enabled
*/

@Field static final Map<Integer, String> DoorLockClusterSupportedOperatingModes = [
    0x00    : 'Normal',             // (mandatory)
    0x01    : 'Vacation',
    0x02    : 'Privacy',
    0x03    : 'NoRemoteLockUnlock', // (mandatory)
    0x04    : 'Passage'
]

@Field static final Map<Integer, String> DoorLockClusterOperatingModeEnum = [
    0x00    : 'Normal',
    0x01    : 'Vacation',
    0x02    : 'Privacy',
    0x03    : 'NoRemoteLockUnlock',
    0x04    : 'Passage'
]

// Door Lock Event Enums
@Field static final Map<Integer, String> DoorLockClusterAlarmCode = [
    0x00    : 'LockJammed',
    0x01    : 'LockFactoryReset',
    0x03    : 'LockRadioPowerCycled',
    0x04    : 'WrongCodeEntryLimit',
    0x05    : 'FrontEscutcheonRemoved',
    0x06    : 'DoorForcedOpen',
    0x07    : 'DoorAjar',
    0x08    : 'ForcedUser'
]

@Field static final Map<Integer, String> DoorLockClusterDoorState = [
    0x00    : 'Open',
    0x01    : 'Closed',
    0x02    : 'Jammed',
    0x03    : 'ForcedOpen',
    0x04    : 'UnspecifiedError',
    0x05    : 'Ajar'
]

@Field static final Map<Integer, String> DoorLockClusterLockOperationType = [
    0x00    : 'Lock',
    0x01    : 'Unlock',
    0x02    : 'NonAccessUserEvent',
    0x03    : 'ForcedUserEvent',
    0x04    : 'Unlatch'
]

@Field static final Map<Integer, String> DoorLockClusterOperationSource = [
    0x00    : 'Unspecified',
    0x01    : 'Manual',
    0x02    : 'ProprietaryRemote',
    0x03    : 'Keypad',
    0x04    : 'Auto',
    0x05    : 'Button',
    0x06    : 'Schedule',
    0x07    : 'Remote',
    0x08    : 'RFID',
    0x09    : 'Biometric',
    0x0A    : 'Aliro (UWB/Apple Watch)'       // UWB/Apple Watch
]

@Field static final Map<Integer, String> DoorLockClusterOperationError = [
    0x00    : 'Unspecified',
    0x01    : 'InvalidCredential',
    0x02    : 'DisabledUserDenied',
    0x03    : 'Restricted',
    0x04    : 'InsufficientBattery'
]

@Field static final Map<Integer, String> DoorLockClusterLockDataType = [
    0x00    : 'Unspecified',
    0x01    : 'ProgrammingCode',
    0x02    : 'UserIndex',
    0x03    : 'WeekDaySchedule',
    0x04    : 'YearDaySchedule',
    0x05    : 'HolidaySchedule',
    0x06    : 'PIN',
    0x07    : 'RFID',
    0x08    : 'Fingerprint',
    0x09    : 'FingerVein',
    0x0A    : 'Face'
]

@Field static final Map<Integer, String> DoorLockClusterDataOperationType = [
    0x00    : 'Add',
    0x01    : 'Clear',
    0x02    : 'Modify'
]

@Field static final Map<Integer, String> HubitatCodeChangedType = [
    0x00    : 'added',
    0x01    : 'deleted',
    0x02    : 'changed',
    0x04    : 'failed'
]

@Field static final Map<Integer, String> CredentialTypeEnum = [
    0: 'ProgrammingPIN', // Programming PIN code credential type (O)
    1: 'PIN',            // PIN code credential type (PIN)
    2: 'RFID',           // RFID identifier credential type (RID)
    3: 'Fingerprint',    // Fingerprint identifier credential type (FGP)
    4: 'FingerVein',     // Finger vein identifier credential type (FGP)
    5: 'Face',           // Face identifier credential type (FACE)
    6: 'AliroCredentialIssuerKey',
    7: 'AliroEvictableEndpointKey',
    8: 'AliroNonEvictableEndpointKey'
]

@Field static final Map<Integer, String> DoorLockClusterUserStatus = [
    0: 'Available',
    1: 'OccupiedEnabled',
    3: 'OccupiedDisabled'
]

@Field static final Map<Integer, String> DoorLockClusterUserType = [
    0: 'UnrestrictedUser',
    1: 'YearDayScheduleUser',
    2: 'WeekDayScheduleUser',
    3: 'ProgrammingUser',
    4: 'NonAccessUser',
    5: 'ForcedUser',
    6: 'DisposableUser',
    7: 'ExpiringUser',
    8: 'ScheduleRestrictedUser',
    9: 'RemoteOnlyUser'
]

@Field static final Map<Integer, String> DoorLockClusterCredentialRule = [
    0: 'Single',
    1: 'Dual',
    2: 'Tri'
]

@Field static final Map<Integer, String> DataOperationTypeEnum = [
    0: 'Add',    // Data is being added or was added (M)
    1: 'Clear',  // Data is being cleared or was cleared (M)
    2: 'Modify'  // Data is being modified or was modified (M)
]

// Helper method to decode CredentialRulesSupport bitmap
String decodeCredentialRules(Integer rules) {
    List<String> supported = []
    if (rules & 0x01) { supported.add('Single') }
    if (rules & 0x02) { supported.add('Dual') }
    if (rules & 0x04) { supported.add('Triple') }
    return supported.isEmpty() ? 'None' : supported.join(', ')
}


// 5.2.4. Features This cluster SHALL support the FeatureMap bitmap attribute as defined below.

// Matter Door Lock Feature Map bits (from Matter specification 1.3)
@Field static final Integer FEATURE_PIN_CREDENTIAL = 0x0001          // Bit 0: PIN credential support
@Field static final Integer FEATURE_RFID_CREDENTIAL = 0x0002         // Bit 1: RFID credential support
@Field static final Integer FEATURE_FINGER_CREDENTIALS = 0x0004      // Bit 2: Fingerprint credential support
@Field static final Integer FEATURE_LOGGING = 0x0008                 // Bit 3: Logging support
@Field static final Integer FEATURE_WEEK_DAY_SCHEDULES = 0x0010      // Bit 4: Week day access schedules
@Field static final Integer FEATURE_DOOR_POSITION_SENSOR = 0x0020    // Bit 5: Door position sensor
@Field static final Integer FEATURE_FACE_CREDENTIALS = 0x0040        // Bit 6: Face recognition credentials
@Field static final Integer FEATURE_COTA = 0x0080                    // Bit 7: Credential Over The Air (COTA)
@Field static final Integer FEATURE_USER_MANAGEMENT = 0x0100         // Bit 8: User management
@Field static final Integer FEATURE_NOTIFICATION = 0x0200            // Bit 9: Notification support
@Field static final Integer FEATURE_YEAR_DAY_SCHEDULES = 0x0400      // Bit 10: Year day access schedules
@Field static final Integer FEATURE_HOLIDAY_SCHEDULES = 0x0800       // Bit 11: Holiday schedules
@Field static final Integer FEATURE_UNBOLT = 0x1000                  // Bit 12: Unbolt support

String decodeFeatureMap(Integer featureMap) {
    if (featureMap == 0) { return 'None (Mandatory features only)' }
    List<String> features = []
    
    if (featureMap & 0x0001) { features.add('PIN') }                     // Bit 0   PIN - Lock supports PIN credentials (via keypad, or over-the-air)
    if (featureMap & 0x0002) { features.add('RFID') }                    // Bit 1   RID - Lock supports RFID credentials
    if (featureMap & 0x0004) { features.add('Fingerprint') }             // Bit 2   FGP - Lock supports finger related credentials (fingerprint, finger vein)
    if (featureMap & 0x0008) { features.add('Logging') }                 // Bit 3   LOG
    if (featureMap & 0x0010) { features.add('WeekDaySchedules') }        // Bit 4   WDSCH
    if (featureMap & 0x0020) { features.add('DoorPositionSensor') }      // Bit 5   DPS
    if (featureMap & 0x0040) { features.add('FaceCredential') }          // Bit 6   FACE
    if (featureMap & 0x0080) { features.add('COTA') }                    // Bit 7   COTA - CredentialOverTheAirAccess - PIN codes overtheair supported for lock/unlock operations
    if (featureMap & 0x0100) { features.add('UserManagement') }          // Bit 8   USR - [ PIN | RID | FGP |FACE ] - Lock supports the user commands and database
    if (featureMap & 0x0200) { features.add('Notification') }            // Bit 9   NOT
    if (featureMap & 0x0400) { features.add('YearDaySchedules') }        // Bit 10  YDSCH
    if (featureMap & 0x0800) { features.add('HolidaySchedules') }        // Bit 11  HDSCH
    if (featureMap & 0x1000) { features.add('Unbolt') }                  // Bit 12  UBOLT - Unbolting - Lock supports unbolting
    
    return features.join(', ')
}

// Helper method to decode KeypadOperationEventMask bitmap (DlKeypadOperationEventMask)
String decodeKeypadOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidPIN') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidCode') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    if (mask & 0x80) { enabled.add('NonAccessUserOpEvent') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode KeypadProgrammingEventMask bitmap (DlKeypadProgrammingEventMask)
String decodeKeypadProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ProgrammingPINChanged') }
    if (mask & 0x04) { enabled.add('PINAdded') }
    if (mask & 0x08) { enabled.add('PINCleared') }
    if (mask & 0x10) { enabled.add('PINChanged') }
    if (mask & 0x20) { enabled.add('Reserved(0x20)') }
    if (mask & 0x40) { enabled.add('Unknown/Proprietary(0x40)') }  // Nuki specific?
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode RemoteOperationEventMask bitmap (DlRemoteOperationEventMask)
String decodeRemoteOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidCode') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidCode') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode ManualOperationEventMask bitmap (DlManualOperationEventMask)
String decodeManualOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ThumbturnLock') }
    if (mask & 0x04) { enabled.add('ThumbturnUnlock') }
    if (mask & 0x08) { enabled.add('OneTouchLock') }
    if (mask & 0x10) { enabled.add('KeyLock') }
    if (mask & 0x20) { enabled.add('KeyUnlock') }
    if (mask & 0x40) { enabled.add('AutoLock') }
    if (mask & 0x80) { enabled.add('ScheduleLock') }
    if (mask & 0x100) { enabled.add('ScheduleUnlock') }
    if (mask & 0x200) { enabled.add('ManualLock') }
    if (mask & 0x400) { enabled.add('ManualUnlock') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode RFIDOperationEventMask bitmap (DlRFIDOperationEventMask)
String decodeRFIDOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidRFID') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidRFID') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// AlarmMask (0x0080) decoder
String decodeAlarmMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('LockJammed') }
    if (mask & 0x02) { enabled.add('LockFactoryReset') }
    if (mask & 0x04) { enabled.add('LockRadioPowerCycled') }
    if (mask & 0x08) { enabled.add('WrongCodeEntryLimit') }
    if (mask & 0x10) { enabled.add('FrontEscutcheonRemoved') }
    if (mask & 0x20) { enabled.add('DoorForcedOpen') }
    if (mask & 0x40) { enabled.add('DoorAjar') }
    if (mask & 0x80) { enabled.add('ForcedUser') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// RemoteProgrammingEventMask (0x0046) decoder - per Matter specification
String decodeRemoteProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ProgrammingPINChanged') }
    if (mask & 0x04) { enabled.add('PINAdded') }
    if (mask & 0x08) { enabled.add('PINCleared') }
    if (mask & 0x10) { enabled.add('PINChanged') }
    if (mask & 0x20) { enabled.add('PINCodeDuplicate') }
    if (mask & 0x40) { enabled.add('Reserved(0x40)') }
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// RFIDProgrammingEventMask (0x0047) decoder - per Matter specification
String decodeRFIDProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('RFIDCodeAdded') }
    if (mask & 0x04) { enabled.add('RFIDCodeCleared') }
    if (mask & 0x08) { enabled.add('RFIDCodeDuplicate') }
    if (mask & 0x10) { enabled.add('RFIDCodeInvalid') }
    if (mask & 0x20) { enabled.add('RFIDCodeChanged') }
    if (mask & 0x40) { enabled.add('Reserved(0x40)') }
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// ============ Lock Command Helper Methods ============

/**
 * Convert ASCII PIN string to hex bytes
 * @param s ASCII string (e.g., "123456")
 * @return hex string (e.g., "313233343536")
 */
private static String asciiToHex(final String s) {
    if (s == null) return ''
    byte[] bytes = s.getBytes('US-ASCII')
    return bytes.collect { String.format('%02X', it) }.join()
}

@Field static final String DRIVER = 'Matter Advanced Bridge'
@Field static final String COMPONENT = 'Matter Generic Component Door Lock'
@Field static final String WIKI   = 'Get help on GitHub Wiki page:'
@Field static final String COMM_LINK =   "https://community.hubitat.com/t/release-matter-advanced-bridge-limited-device-support/135252/1"
@Field static final String GITHUB_LINK = "https://github.com/kkossev/Hubitat---Matter-Advanced-Bridge/wiki/Matter-Advanced-Bridge-%E2%80%90-Door-Locks"
// credits @jtp10181
String fmtHelpInfo(String str) {
	String info = "${DRIVER} v${parent?.version()}<br> ${COMPONENT} v${matterComponentLockVersion}"
	String prefLink = "<a href='${GITHUB_LINK}' target='_blank'>${WIKI}<br><div style='font-size: 70%;'>${info}</div></a>"
    String topStyle = "style='font-size: 18px; padding: 1px 12px; border: 2px solid green; border-radius: 6px; color: green;'"
    String topLink = "<a ${topStyle} href='${COMM_LINK}' target='_blank'>${str}<br><div style='font-size: 14px;'>${info}</div></a>"

	return "<div style='font-size: 160%; font-style: bold; padding: 2px 0px; text-align: center;'>${prefLink}</div>" +
		"<div style='text-align: center; position: absolute; top: 46px; right: 60px; padding: 0px;'><ul class='nav'><li>${topLink}</ul></li></div>"
}


// Helper method to safely parse hex string to Integer
Integer safeParseHex(String hexValue) {
    try {
        return Integer.parseInt(hexValue, 16)
    } catch (NumberFormatException e) {
        logWarn "safeParseHex: failed to parse '${hexValue}', returning 0"
        return 0
    }
}



def testInvoke(params) {

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) {
        logWarn "testSetCredentialSmartThingsStyleRemoteOnly: deviceNumber is null"
        return
    }

    /*
     * Same as SmartThings-style test, but:
     * userType = 9  REMOTE_ONLY_USER
     */

    String tlv = "1524000035012400012501010018300206313233343536340324040124050918"

    String cmd = matter.invoke(deviceNumber, 0x0101, 0x0022, 2000, tlv)

    logDebug "testSetCredentialSmartThingsStyleRemoteOnly: tlv=${tlv}, cmd=${cmd}"
    parent?.componentLog(device, 'debug', "testing SmartThings-style SetCredential: PIN 123456, credentialIndex=1, userIndex=NULL, userType=REMOTE_ONLY_USER...")
    parent?.sendToDevice(cmd)


}

void testUnlockWithCode(code = null) {
    if (logEnable) log.debug "testUnlockWithCode: ${code}"
    // getLockCodes() is the Hubitat-standard helper; in the virtual lock reference this is the implicit 'lockCodes' property
    Map lockCodesMap = getLockCodes()
    Object lockCode = lockCodesMap.find { it.value.code == "${code}" }
    if (lockCode) {
        Map payloadData = ["${lockCode.key}": lockCode.value]
        String descriptionText = "${device.displayName} was unlocked by ${lockCode.value.name}"
        if (txtEnable) log.info "${descriptionText}"
        def eventData = settings?.optEncrypt ? encrypt(JsonOutput.toJson(payloadData)) : payloadData
        logLockCodeEventPayload('lock', 'unlocked', payloadData)
        sendEvent(name: 'lock', value: 'unlocked', descriptionText: descriptionText, type: 'physical', data: eventData, isStateChange: true)
        sendEvent(name: 'lastCodeName', value: lockCode.value.name, descriptionText: descriptionText, isStateChange: true)
    } else {
        if (txtEnable) log.debug "testUnlockWithCode: no matching code found for '${code}'"
    }
}

// --------- common matter libraries included below --------

#include kkossev.matterCommonLib
#include kkossev.matterHealthStatusLib
