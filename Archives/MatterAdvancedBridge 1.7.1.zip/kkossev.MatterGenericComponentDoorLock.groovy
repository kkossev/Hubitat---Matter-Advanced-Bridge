
/*
  *  'Matter Generic Component Door Lock' - component driver for Matter Advanced Bridge
  *
  *  https://community.hubitat.com/t/dynamic-capabilities-commands-and-attributes-for-drivers/98342
  *  https://community.hubitat.com/t/project-zemismart-m1-matter-bridge-for-tuya-zigbee-devices-matter/127009
  *
  *  Licensed Virtual the Apache License, Version 2.0 (the "License"); you may not use this file except
  *  in compliance with the License. You may obtain a copy of the License at:
  *
  *      http://www.apache.org/licenses/LICENSE-2.0
  *
  *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
  *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
  *  for the specific language governing permissions and limitations under the License.
  *
  * ver. 1.0.0  2024-04-05 dds82   - first version
  * ver. 1.1.0  2024-07-20 kkossev - added Battery capability; added Identify command; added warning state and log messages; added handling of unprocessed Door Lock events
  * ver. 1.1.1  2024-07-23 kkossev - added switch capability (for Apple Home integration workaround)
  * ver. 1.1.2  2024-08-12 kkossev - fixed importURL
  * ver. 1.2.0  2025-01-10 kkossev + Calude Sonnet 4.5 : Matter events handling rework; Door Lock working! :) added ping command and RTT attribute; removed switch capability
  * ver. 1.3.0  2025-01-14 kkossev - moved component methods from parent to component driver; major refactoring 
  * ver. 1.3.1  2025-01-22 kkossev + Claude Haiku 4.5 : Aqara U200 Door Lock support improvements (clearUser seems to be working!)
  * ver. 1.3.2  2025-01-25 kkossev + GPT-4.1 : newParse: true decoding; use matterCommonLib; 
  *                                  capability 'LockCodes' is commented out temporarily: (lock codes still not working)
  * 
  *                                  TODO: fingerprintData "AcceptedCommandList is empty !!!
  *                                  TODO: add driver version to the state variables
  *                                  TODO: initialize lock with 'unknown' attributes when the device is created
  *                                  TODO: filter duplicated events
  *                                  TODO: add [physical] [digital] event type to events and logs
  *                                  TODO: analyze https://github.com/SmartThingsCommunity/SmartThingsEdgeDrivers/tree/main/drivers/SmartThings/matter-lock 
  *                                  TODO: analyze https://matter-survey.org/cluster/0x0101
  *                                  TODO: update gitHub documentation
  *                                  
  *
*/

import groovy.transform.Field
import groovy.transform.CompileStatic
import hubitat.helper.HexUtils
import hubitat.matter.DataType

@Field static final String matterComponentLockVersion = '1.3.2'
@Field static final String matterComponentLockStamp   = '2025/01/25 8:36 AM'

@Field static final Boolean _DEBUG_LOCK = false              // MAKE IT false for PRODUCTION !   
@Field static final Boolean _DEFAULT_LOG_ENABLE = false      // disable on production

// Matter Door Lock Feature Map bits (from Matter specification 1.3)
@Field static final Integer FEATURE_PIN_CREDENTIAL = 0x0001          // Bit 0: PIN credential support
@Field static final Integer FEATURE_RFID_CREDENTIAL = 0x0002         // Bit 1: RFID credential support
@Field static final Integer FEATURE_FINGER_CREDENTIALS = 0x0004      // Bit 2: Fingerprint credential support
@Field static final Integer FEATURE_LOGGING = 0x0008                 // Bit 3: Logging support
@Field static final Integer FEATURE_WEEK_DAY_SCHEDULES = 0x0010      // Bit 4: Week day access schedules
@Field static final Integer FEATURE_DOOR_POSITION_SENSOR = 0x0020    // Bit 5: Door position sensor
@Field static final Integer FEATURE_FACE_CREDENTIALS = 0x0040        // Bit 6: Face recognition credentials
@Field static final Integer FEATURE_COTA = 0x0080                    // Bit 7: Credential Over The Air (COTA)
@Field static final Integer FEATURE_USER_MANAGEMENT = 0x0100         // Bit 8: User management
@Field static final Integer FEATURE_NOTIFICATION = 0x0200            // Bit 9: Notification support
@Field static final Integer FEATURE_YEAR_DAY_SCHEDULES = 0x0400      // Bit 10: Year day access schedules
@Field static final Integer FEATURE_HOLIDAY_SCHEDULES = 0x0800       // Bit 11: Holiday schedules
@Field static final Integer FEATURE_UNBOLT = 0x1000                  // Bit 12: Unbolt support

metadata {
    definition(name: 'Matter Generic Component Door Lock', namespace: 'kkossev', author: 'Daniel Segall', importUrl: 'https://raw.githubusercontent.com/kkossev/Hubitat---Matter-Advanced-Bridge/main/Components/Matter_Generic_Component_Door_Lock') {
        capability 'Sensor'
        capability 'Actuator'
        capability 'Battery'
        capability 'Lock'       // lock - ENUM ["locked", "unlocked with timeout", "unlocked", "unknown"]
        //capability 'LockCodes'  // lockCodes, codeChanged, codeLength, maxCodes | setCode(pos,pin,name), deleteCode(pos), getCodes(), setCodeLength(len)
        capability 'Refresh'

        command    'identify', [[name: 'Identify the lock device']]
        command    'getInfo', [[name: 'Check the live logs and the device data for additional infoormation on this device']]
        /*
        //command    'unlockWithPIN', [[name: 'pin*', type: 'STRING', description: 'unlock with PIN (not available on all locks)']]
        command    'unboltDoor', [[name: 'Unbolt door (not available on all locks)']]
        
        // LockCodes custom commands with dynamic feature support indication
        command    'setCode', [[name: 'codePosition*', type: 'NUMBER', description: 'Code slot (1-based)'],
                               [name: 'pinCode*', type: 'STRING', description: 'PIN code (4-8 digits)'],
                               [name: 'name', type: 'STRING', description: "User name (optional)<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        command    'deleteCode', [[name: 'codePosition*', type: 'NUMBER', description: "Code slot to delete<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        command    'getCodes', [[name: "Retrieve all PIN codes<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
        */
        // TODO - move these to state variables or device data ?
        attribute 'lockType', 'ENUM', ['deadbolt', 'magnetic', 'other', 'mortise', 'rim', 'latchbolt', 'cylindricalLock', 'tubularLock', 'interconnectedLock', 'deadLatch', 'doorFurniture', 'eurocylinder']
        attribute 'actuatorEnabled', 'ENUM', ['enabled', 'disabled']
        attribute 'operatingMode', 'ENUM', ['Normal', 'Vacation', 'Privacy', 'NoRemoteLockUnlock', 'Passage']
        attribute 'supportedOperatingModes', 'STRING'
        
        // Event-related attributes
        // TODO: consider moving these to state variables or device data instead of attributes ?
        attribute 'lastLockOperation', 'STRING'
        attribute 'lastOperationSource', 'STRING'
        attribute 'lastLockOperationError', 'STRING'
        attribute 'lastUserChange', 'STRING'
        attribute 'lockAlarm', 'STRING'
        attribute 'doorState', 'STRING'
        
        // Infrastructure/health-check attributes
        attribute 'powerSourceStatus', 'ENUM', ['active', 'standby', 'unavailable']

        if (_DEBUG_LOCK) {
            command 'getCredentialStatus', [[name:'pinIndex*', type: 'STRING', description: 'PIN Index (1-255)', defaultValue: '1']]
            command 'getUser', [[name:'userIndex*', type: 'STRING', description: 'User Index (0-65534)', defaultValue: '1']]
            command 'clearUser', [[name:'userIndex*', type: 'STRING', description: 'User Index (0-65534)', defaultValue: '1']]
            command 'setUser', [[name: 'codePosition*', type: 'NUMBER', description: 'Code slot (1-based)'],
                                           [name: 'pinCode*', type: 'STRING', description: 'PIN code (4-8 digits)'],
                                           [name: 'name', type: 'STRING', description: "User name (optional)<br><br><b>See State Varables INFO whether your lock supports this function</b>"]]
            command 'clearCredential', [[name:'credentialType*', type: 'NUMBER', description: 'Credential Type (0:ProgrammingPIN,1:PIN,2:RFID,3:Fingerprint,4:FingerVein,5:Face)', defaultValue: '1'],
                                     [name:'credentialIndex', type: 'NUMBER', description: 'Credential Index (0 to clear all)', defaultValue: '9']]
            command 'testInvoke', [[name: 'testInvoke', type: 'STRING', description: 'test', defaultValue : '']]    // for debug purposes only
        }
    }
}

preferences {
    section {
	    input name: "helpInfo", type: "hidden", title: fmtHelpInfo("Community Link")
        input name: 'logEnable',
              type: 'bool',
              title: '<b>Enable debug logging</b>',
              required: false,
              defaultValue: _DEFAULT_LOG_ENABLE

        input name: 'txtEnable',
              type: 'bool',
              title: '<b>Enable descriptionText logging</b>',
              required: false,
              defaultValue: true
        input name: 'advancedOptions', type: 'bool', title: '<b>Advanced Options</b>', description: '<i>These advanced options should be already automatically set in an optimal way for your device...</i>', defaultValue: false
        if (device && advancedOptions == true) {
            input name: 'ignoreCompatibilityChecks', type: 'bool', title: '<b>Ignore Compatibility Checks</b>', description: '<i>Allow executing commands that may not be supported by this lock</i>', defaultValue: false
        }

    }
}

import groovy.transform.CompileStatic

void parse(String description) { log.warn 'parse(String description) not implemented' }

// parse commands from parent
void parse(List<Map> parsedEvents) {
    //if (logEnable) { log.debug "${parsedEvents}" }
    parsedEvents.each { d ->
        if (d.name == 'lock') {
            if (device.currentValue('lock') != d.value) {
                if (d.descriptionText) { logInfo "${d.descriptionText}" }
                sendEvent(d)
            }
            else {
                logDebug ": ignored lock event '${d.value}' (no change)"
            }
        }
        else if (d.name == 'rtt') {
            // Delegate to health status library
            parseRttEvent(d)
        }
        else if (d.name in  ['unprocessed', 'handleInChildDriver']) {
            handleUnprocessedMessageInChildDriver(d)
        }
        else {
            if (d.descriptionText) { logInfo "${d.descriptionText}" }
            sendEvent(d)
        }
    }
}

void handleUnprocessedMessageInChildDriver(Map description) {
    //logDebug "handleUnprocessedMessageInChildDriver: description = ${description}"
    Map descMap =[:]
    try {
        descMap = description.value as Map
    }
    catch (e) {
        logWarn "handleUnprocessedMessageInChildDriver: exception ${e} while parsing description.value = ${description.value}"
        return
    }
    logDebug "handleUnprocessedMessageInChildDriver: parsed descMap = ${descMap}"
    if (descMap.cluster != '0101') { logWarn "handleUnprocessedMessageInChildDriver: unexpected cluster:${descMap.cluster} (attrId:${descMap.attrId})"; return }

    // Check if this is an event (has evtId) or an attribute (has attrId)
    if (descMap.evtId != null) {
        processDoorLockEvent(descMap)
        return
    }
    // else - process attribute report
    processDoorLockAttributeReport(descMap)
}

void processDoorLockAttributeReport(Map descMap) {
    
    String eventValue = descMap.value
    String descriptionText = "${device.displayName} ${descMap.cluster}:${descMap.attrId} value:${eventValue}"
    
    // Declare variables for conditional logging
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${descMap.attrId}] " : ""
    String message = null
    boolean useDebugLog = false  // Flag to use logDebug instead of logInfo when isInfoMode is false
    
    switch (descMap.attrId) {
        case '0000': // LockState
            // LockState is typically handled by parent driver
            // But log it here for debugging if it arrives
            String lockStateText = DoorLockClusterLockState[safeHexToInt(descMap.value)] ?: "Unknown (${descMap.value})"
            message = "${prefix}LockState: ${lockStateText} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0001': // LockType
            eventValue= DooorLockClusterLockType[safeHexToInt(descMap.value)]
            descriptionText = "${device.displayName} lockType: ${eventValue} (raw:${descMap.value})"
            sendEvent(name: 'lockType', value: eventValue, descriptionText: descriptionText)
            message = "${prefix}lockType: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0002': // ActuatorEnabled
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            descriptionText = "${device.displayName} ActuatorEnabled: ${eventValue} (raw:${descMap.value})"
            sendEvent(name: 'actuatorEnabled', value: eventValue, descriptionText: descriptionText)
            message = "${prefix}ActuatorEnabled: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0003': // DoorState
            Integer doorStateValue = safeHexToInt(descMap.value)
            eventValue = DoorLockClusterDoorState[doorStateValue] ?: "Unknown/OutOfSpec"
            if (doorStateValue > 0x05) {
                message = "${prefix}DoorState: ${eventValue} (raw:0x${descMap.value} - value out of spec 0x00-0x05)"
            } else {
                descriptionText = "${device.displayName} DoorState: ${eventValue} (raw:${descMap.value})"
                //sendEvent(name: 'doorState', value: eventValue, descriptionText: descriptionText)
                message = "${prefix}DoorState: ${eventValue} (raw:${descMap.value})"
            }
            useDebugLog = true
            break
        case '0004': // DoorOpenEvents
            Integer doorOpenEvents = safeHexToInt(descMap.value)
            message = "${prefix}DoorOpenEvents: ${doorOpenEvents}"
            break
        case '0005': // DoorClosedEvents
            Integer doorClosedEvents = safeHexToInt(descMap.value)
            message = "${prefix}DoorClosedEvents: ${doorClosedEvents}"
            break
        case '0006': // OpenPeriod
            Integer openPeriod = safeHexToInt(descMap.value)
            message = "${prefix}OpenPeriod: ${openPeriod} minutes"
            break
        case '0010': // NumberOfLogRecordsSupported
            message = processNumericAttribute('NumberOfLogRecordsSupported', descMap)
            break
        case '0011': // NumberOfTotalUsersSupported
            message = processNumericAttribute('NumberOfTotalUsersSupported', descMap)
            break
        case '0012': // NumberOfPINUsersSupported
            message = processNumericAttribute('NumberOfPINUsersSupported', descMap)
            break
        case '0013': // NumberOfRFIDUsersSupported
            message = processNumericAttribute('NumberOfRFIDUsersSupported', descMap)
            break
        case '0014': // NumberOfWeekDaySchedulesSupportedPerUser
            message = processNumericAttribute('NumberOfWeekDaySchedulesSupportedPerUser', descMap)
            break
        case '0015': // NumberOfYearDaySchedulesSupportedPerUser
            message = processNumericAttribute('NumberOfYearDaySchedulesSupportedPerUser', descMap)
            break
        case '0016': // NumberOfHolidaySchedulesSupported
            message = processNumericAttribute('NumberOfHolidaySchedulesSupported', descMap)
            break
        case '0017': // MaxPINCodeLength
            Integer maxPinLength = safeHexToInt(descMap.value)
            descriptionText = "${device.displayName} maximum PIN code length is ${maxPinLength}"
            sendEvent(name: 'codeLength', value: maxPinLength, type: 'physical', descriptionText: descriptionText)
            message = "${prefix}MaxPINCodeLength: ${maxPinLength}"
            break
        case '0018': // MinPINCodeLength
            Integer minPinLength = safeHexToInt(descMap.value)
            message = "${prefix}MinPINCodeLength: ${minPinLength}"
            break
        case '0019': // MaxRFIDCodeLength
            message = processNumericAttribute('MaxRFIDCodeLength', descMap)
            break
        case '001A': // MinRFIDCodeLength
            message = processNumericAttribute('MinRFIDCodeLength', descMap)
            break
        case '001B': // CredentialRulesSupport
            Integer credRules = safeHexToInt(descMap.value)
            String credRulesText = decodeCredentialRules(credRules)
            message = "${prefix}CredentialRulesSupport: ${credRulesText} (0x${descMap.value})"
            break
        case '001C': // NumberOfCredentialsSupportedPerUser
            message = processNumericAttribute('NumberOfCredentialsSupportedPerUser', descMap)
            break
        case '0020': // EnableLogging
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableLogging: ${eventValue} (raw:${descMap.value})"
            break
        case '0021': // Language
            String language = descMap.value instanceof List ? descMap.value.join('') : descMap.value
            message = "${prefix}Language: ${language}"
            break
        case '0022': // LEDSettings
            Integer ledSettings = safeHexToInt(descMap.value)
            message = "${prefix}LEDSettings: 0x${descMap.value}"
            break
        case '0023': // AutoRelockTime
            Integer autoRelockTime = safeHexToInt(descMap.value)
            message = "${prefix}AutoRelockTime: ${autoRelockTime} seconds"
            break
        case '0024': // SoundVolume
            Integer soundVolume = safeHexToInt(descMap.value)
            message = "${prefix}SoundVolume: ${soundVolume}"
            break
        case '0025' : // OperatingMode
            // OperatingMode: 00 (raw:00)
            eventValue = DoorLockClusterOperatingModeEnum[safeHexToInt(descMap.value)]
            descriptionText = "${device.displayName} OperatingMode: ${eventValue} (raw:${descMap.value})"
            sendEvent(name: 'operatingMode', value: eventValue, descriptionText: descriptionText)
            message = "${prefix}OperatingMode: ${eventValue} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0026' : // SupportedOperatingModes
            // SupportedOperatingModes: FFF6 (raw:FFF6)
            Integer intValue = safeHexToInt(descMap.value)
            List<String> supportedModes = []
            // Iterate through each bit position and check if the corresponding bit in eventValue is set to 0
            DoorLockClusterSupportedOperatingModes.each { bitPosition, modeName ->
                if ((intValue & (1 << bitPosition)) == 0) {/* ...existing code... */}
            }
            String supportedModesString = supportedModes.join(', ')
            descriptionText = "${device.displayName} SupportedOperatingModes: ${supportedModesString} (raw:${descMap.value})"
            sendEvent(name: 'supportedOperatingModes', value: supportedModesString, descriptionText: descriptionText)
            message = "${prefix}SupportedOperatingModes: ${supportedModesString} (raw:${descMap.value})"
            useDebugLog = true
            break
        case '0027': // DefaultConfigurationRegister
            message = "${prefix}DefaultConfigurationRegister: 0x${descMap.value}"
            break
        case '0028': // EnableLocalProgramming
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableLocalProgramming: ${eventValue} (raw:${descMap.value})"
            break
        case '0029': // EnableOneTouchLocking
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableOneTouchLocking: ${eventValue} (raw:${descMap.value})"
            break
        case '002A': // EnableInsideStatusLED
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnableInsideStatusLED: ${eventValue} (raw:${descMap.value})"
            break
        case '002B': // EnablePrivacyModeButton
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}EnablePrivacyModeButton: ${eventValue} (raw:${descMap.value})"
            break
        case '002C': // LocalProgrammingFeatures
            message = "${prefix}LocalProgrammingFeatures: 0x${descMap.value}"
            break
        case '0030': // WrongCodeEntryLimit
            Integer wrongCodeLimit = safeHexToInt(descMap.value)
            message = "${prefix}WrongCodeEntryLimit: ${wrongCodeLimit}"
            break
        case '0031': // UserCodeTemporaryDisableTime
            Integer disableTime = safeHexToInt(descMap.value)
            message = "${prefix}UserCodeTemporaryDisableTime: ${disableTime} seconds"
            break
        case '0032': // SendPINOverTheAir
            eventValue = descMap.value == '01' ? 'enabled' : 'disabled'
            message = "${prefix}SendPINoverTheAir: ${eventValue} (raw:${descMap.value})"
            break
        case '0033': // RequirePINforRemoteOperation
            eventValue = descMap.value == '01' ? 'required' : 'not required'
            message = "${prefix}RequirePINforRemoteOperation: ${eventValue} (raw:${descMap.value})"
            break
        case '0034': // SecurityLevel (Deprecated)
            Integer securityLevel = safeHexToInt(descMap.value)
            String securityLevelName = ['Unspecified', 'Low', 'Medium', 'High'][securityLevel] ?: "Unknown(${securityLevel})"
            message = "${prefix}SecurityLevel: ${securityLevelName} (deprecated, raw:${descMap.value})"
            break
        case '0035': // ExpiringUserTimeout
            Integer expiringUserTimeout = safeHexToInt(descMap.value)
            message = "${prefix}ExpiringUserTimeout: ${expiringUserTimeout} minutes"
            break
        case '0042': // RemoteOperationEventMask
            message = processEventMaskAttribute('0042', 'RemoteOperationEventMask', descMap, this.&decodeRemoteOperationEventMask)
            useDebugLog = true
            break
        case '0043': // ManualOperationEventMask
            message = processEventMaskAttribute('0043', 'ManualOperationEventMask', descMap, this.&decodeManualOperationEventMask)
            useDebugLog = true
            break
        case '0044': // RFIDOperationEventMask
            message = processEventMaskAttribute('0044', 'RFIDOperationEventMask', descMap, this.&decodeRFIDOperationEventMask)
            useDebugLog = true
            break
        case '0045': // KeypadProgrammingEventMask
            message = processEventMaskAttribute('0045', 'KeypadProgrammingEventMask', descMap, this.&decodeKeypadProgrammingEventMask)
            // NOTE: Nuki disables PINCleared (0x08) and PINChanged (0x10) events
            // This means PIN deletion/modification events won't be received automatically
            useDebugLog = true
            break
        case '0046': // RemoteProgrammingEventMask
            message = processEventMaskAttribute('0046', 'RemoteProgrammingEventMask', descMap, this.&decodeRemoteProgrammingEventMask)
            useDebugLog = true
            break
        case '0047': // RFIDProgrammingEventMask
            message = processEventMaskAttribute('0047', 'RFIDProgrammingEventMask', descMap, this.&decodeRFIDProgrammingEventMask)
            useDebugLog = true
            break
        case '0080': // Nuki non-standard attribute (spec=0x40 AlarmMask)
        case '0081': // Nuki non-standard attribute (spec=0x41 KeypadOperationEventMask)
        case '0082': // Nuki non-standard attribute (spec=0x42 RemoteOperationEventMask)
        case '0083': // Nuki non-standard attribute (spec=0x43 ManualOperationEventMask)
        case '0087': // Nuki non-standard attribute (spec=0x44 RFIDOperationEventMask)
        case '0088': // Nuki non-standard attribute (spec=0x45 KeypadProgrammingEventMask)
            message = "${prefix} UNKNOWN Nuki non-standard attribute 0x${descMap.attrId}: ${descMap.value}"
            break
        case 'FFFC': // FeatureMap
            Integer featureMap = safeHexToInt(descMap.value)
            String featuresText = decodeFeatureMap(featureMap)
            // FeatureMapRaw is stored in fingerprintData as '0101_FFFC'
            message = "${prefix}FeatureMap: ${featuresText} (0x${descMap.value})"
            break
        case 'FFFB': // AttributeList
            // AttributeList is stored in fingerprintData, no need to store separately
            message = "${prefix}AttributeList: ${descMap.value}"
            useDebugLog = true
            // device.updateDataValue('AttributeList', ...) - removed, now in fingerprintData
            break
        case 'FFFD': // ClusterRevision
            Integer revision = safeHexToInt(descMap.value)
            message = "${prefix}ClusterRevision: ${revision}"
            break
        case 'FFF8': // GeneratedCommandList (events supported) - stored in fingerprintData only
            message = "${prefix}GeneratedCommandList: ${descMap.value}"
            useDebugLog = true
            // Data is in fingerprintData['0101_FFF8'], no duplicate storage needed
            break
        case 'FFF9': // AcceptedCommandList - stored in fingerprintData only
            message = "${prefix}AcceptedCommandList: ${descMap.value}"
            useDebugLog = true
            // Data is in fingerprintData['0101_FFF9'], no duplicate storage needed
            break
        default:
            // Check for command responses
            if (descMap.cmdId == '25' || descMap.value?.contains('credentialExists')) {
                processGetCredentialStatusResponse(descMap)
            } else if (descMap.cmdId == '28' || descMap.value?.contains('userName')) {
                processGetUserResponse(descMap)
            } else {
                logWarn "handleUnprocessedMessageInChildDriver: unexpected attrId:${descMap.attrId}"
            }
            break
    }
    
    // Conditional logging after the switch
    if (message != null) {
        if (isInfoMode) {
            logInfo message
        } else {
            if (useDebugLog) {
                logDebug message
            } else {
                logInfo message
            }
        }
    }
}





void identify() {
    List<String> serverList = getFingerprintData()?.get('ServerList') ?: []
    if (!serverList.contains('0003')) {
        logWarn "Identify command not supported: Cluster 0003 not present in ServerList"
        return
    }
    logInfo "identifying ..."
    parent?.componentIdentify(device)
}

// 5.2.10.1. LockDoor Command (0x00)
// This command causes the lock device to lock the door. This command includes an optional code for the lock. The door lock MAY require a PIN depending on the value of the RequirePINForRemoteOperation attribute.
void lock() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', 'locking...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x00, 2000)
    parent?.sendToDevice(cmd)
}

// 5.2.10.2. UnlockDoor Command (0x01)
// This command causes the lock device to unlock the door. This command includes an optional code for the lock. The door lock MAY require a code depending on the value of the RequirePINForRemoteOperation attribute.
void unlock() {
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', 'unlocking...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x01, 2000)
    parent?.sendToDevice(cmd)
}

// 5.2.10.3. UnlockWithTimeout Command (0x02) - TODO: implemented it later if needed

// Hubitat wrap for setUser
void setCode(codePosition, pinCode, name = null) {
    setUser(codePosition, pinCode, name)
}   


// NOT WORKING! :( )
// 5.2.10.34. SetUser Command (0x1A)
void setUser(codePosition, pinCode, name = null) {
    if (!supportsLockCodes()) {
        logWarn "setCode: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'codeChanged', value: "${codePosition} failed", descriptionText: "Lock <b>does not</b> support PIN codes", isStateChange: true)
        return
    }
    
    if (!codePosition) {
        logWarn 'setUser: user index is required'
        sendEvent(name: 'codeChanged', value: "${codePosition} failed", descriptionText: 'setUser: missing user index', isStateChange: true)
        return
    }

    Integer userIndex
    try {
        userIndex = (codePosition as BigDecimal)?.intValue()
    } catch (Exception ignored) {
        userIndex = null
    }
    if (userIndex == null || userIndex < 1 || userIndex > 255) {
        logWarn "setUser: user index must be 1-255, got '${codePosition}'"
        sendEvent(name: 'codeChanged', value: "${codePosition} failed", descriptionText: "setUser: invalid user index '${codePosition}'", isStateChange: true)
        return
    }

    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) {
        sendEvent(name: 'codeChanged', value: "${codePosition} failed", descriptionText: 'setUser: deviceNumber is null', isStateChange: true)
        return
    }

    // Matter SetUser (0x1A) payload is a TLV structure with context-tagged fields:
    // 0: userIndex (uint16)
    // 1: userName (string)
    // 2: userUniqueID (uint32) (nullable)
    // 3: userStatus (enum8)
    // 4: userType (enum8)
    // 5: credentialRule (enum8)
    // We build it manually (same approach as clearCredential) because nested/typed payloads can be finicky.

    int index = userIndex
    String userIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(index, 2))

    // Default values (works well for typical locks; can be made configurable later)
    int userStatus = 0x01      // commonly "OccupiedEnabled" in Matter/Zigbee family enums
    int userType = 0x00        // commonly "UnrestrictedUser"
    int credentialRule = 0x00  // Single

    String userStatusHex = HexUtils.integerToHexString(userStatus, 1)
    String userTypeHex = HexUtils.integerToHexString(userType, 1)
    String credentialRuleHex = HexUtils.integerToHexString(credentialRule, 1)

    // UserName: send as UTF-8 string (empty string if not provided)
    String userName = (name != null) ? name.toString() : ''
    byte[] userNameBytes = userName.getBytes('UTF-8')
    int userNameLen = userNameBytes.length
    String userNameHex = userNameBytes.collect { String.format('%02X', it) }.join()

    // TLV element for context tag 1: UTF8 string with 1-byte or 2-byte length
    String userNameTlv
    if (userNameLen <= 0xFF) {
        // control 0x2C = context-specific (1-byte tag) + UTF81 (0x0C)
        userNameTlv = '2C' + '01' + HexUtils.integerToHexString(userNameLen, 1) + userNameHex
    } else {
        // control 0x2D = context-specific (1-byte tag) + UTF82 (0x0D)
        String lenHexLE = zigbee.swapOctets(HexUtils.integerToHexString(userNameLen, 2))
        userNameTlv = '2D' + '01' + lenHexLE + userNameHex
    }

    // userUniqueID: leave NULL for now (many locks ignore it / don't require it)
    // control 0x34 = context-specific (1-byte tag) + NULL (0x14)
    String userUniqueIdTlv = '34' + '02'

    // Build TLV structure (anonymous struct)
    String tlv =
            '15' +
            '25' + '00' + userIndexHexLE +
            userNameTlv +
            userUniqueIdTlv +
            '24' + '03' + userStatusHex +
            '24' + '04' + userTypeHex +
            '24' + '05' + credentialRuleHex +
            '18'

    String endpointHex = HexUtils.integerToHexString(deviceNumber, 1)

    String cmd = "he invoke 0x${endpointHex} 0x0101 0x001A 0x07D0 {1518} {${tlv}}"

    logDebug "setUser: index=${index}, nameLen=${userNameLen}, tlv=${tlv}, cmd=${cmd}"
    parent?.sendToDevice(cmd)

    // NOTE: This only creates/updates the user record. Setting the actual PIN credential requires SetCredential (0x22).
    // We keep that separate for now.
    sendEvent(name: 'codeChanged', value: "${codePosition} set", descriptionText: "setUser sent for user ${index}", isStateChange: true)
}


// TODO
// 5.2.10.35. GetUser Command (0x1B)
// Retrieve user.
void getUser(String userIndex) {
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "getUser: This lock <b>does not</b> support User management (FeatureMap indicates no User support)"
        return
    }
    
    if (!userIndex) { logWarn "getUser: User index is required" ; return }

    Integer index = userIndex as Integer
    // TODO: use device data "Number Of Total Users Supported" to validate index ! ( U200 supports up to 10 users )
    if (index < 1 || index > 10) {
        logWarn "getUser: User index must be 1-10, got '${userIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    

    // cmdFields: ID:0, Name:UserIndex, Type:uint16, Constraint: 1 to NumberOfTotalUsersSupported, Conformance:Mandatory
    // An InvokeResponse command SHALL be sent with an appropriate error (e.g. FAILURE, INVALID COMMAND, etc.) as needed otherwise the GetUserResponse Command SHALL be sent implying a status of SUCCESS
    // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    List<Map<String, String>> cmdFields = []
    cmdFields.add(matter.cmdField(0x05, 0x00, zigbee.swapOctets(HexUtils.integerToHexString(index, 2))))

    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001B, cmdFields)
    logDebug "getUser: cmd=${cmd}"
    parent?.componentLog(device, 'debug', "querying user information for index ${index}...")
    parent?.sendToDevice(cmd)
}

// 5.2.10.37. ClearUser Command (0x1D) - WORKING ! :) 
// Clears a user or all Users. 
// // cmdFields: ID:0, Name:UserIndex, Type:uint16, Constraint: 1 to NumberOfTotalUsersSupported, Default:0xFFFE, Conformance:Mandatory
void clearUser(String userIndex) {
    if (!isFeatureEnabled(FEATURE_USER_MANAGEMENT)) {
        logWarn "clearUser: This lock <b>does not</b> support User management (FeatureMap indicates no User support)"
        return
    }
    
    if (!userIndex) {
        logWarn "clearUser: User index is required"
        return
    }
    // TODO: use device data "Number Of Total Users Supported" to validate index ! ( U200 supports up to 10 users )
    Integer index = userIndex as Integer
    if (index < 1 || index > 10) {
        logWarn "clearUser: User index must be 1-10, got '${userIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', "clearing user at index ${index}...")
    logDebug "clearUser: clearing user at index ${index}"
    List<Map<String, String>> cmdFields = []
    cmdFields.add(matter.cmdField(DataType.UINT16, 0x00, zigbee.swapOctets(HexUtils.integerToHexString(index, 2))))
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x001D, 2000, cmdFields)

    parent?.sendToDevice(cmd)
    // clearUser is working, for existing users it returns a response in an event : 
    //       descMap = [callbackType:Event, endpointInt:1, clusterInt:257, evtId:4, timestamp:946765068557, priority:1, data:[4:STRUCT:[6:UINT:8, 3:UINT:8, 0:UINT:2, 1:UINT:1, 4:UINT:3, 5:UINT:112233, 2:UINT:7]], value:[6:8, 3:8, 0:2, 1:1, 4:3, 5:112233, 2:7], cluster:0101, endpoint:01]
    // :) 
}



// 5.2.10.44. ClearCredential Command (0x26)
// Clears a single credential, all credentials of one type, or all credentials of all types.
// Usage:
//   clearCredential()                  // Clear all credentials of all types
//   clearCredential(type)              // Clear all credentials of one type (type: CredentialTypeEnum)
//   clearCredential(type, index)       // Clear a single credential (type: CredentialTypeEnum, index: credential index)
//
// CredentialTypeEnum: 1=PIN, 2=RFID, 3=Fingerprint, 4=Face, etc. (ProgrammingPIN not allowed)
// For all credentials of a type: index = 0xFFFE
// For all credentials of all types: type = null, index = null
// For a single credential: type = credential type, index = credential index
//
// cmdFields: ID:0, Name:Credential, Type:CredentialStruct, Quality:desc, Conformance:Mandatory
void clearCredential(BigDecimal credentialTypePar = null, BigDecimal credentialIndexPar = null) {
    Integer credentialType = credentialTypePar != null ? credentialTypePar.intValue() : null
    Integer credentialIndex = credentialIndexPar != null ? credentialIndexPar.intValue() : null
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return

    if (credentialType == null && credentialIndex == null) {
        // Clear all credentials of all types (Credential field SHALL be null)
        logInfo 'clearCredential: clearing all credentials of all types'
        String cmd = matter.invoke(deviceNumber, 0x0101, 0x26)
        parent?.sendToDevice(cmd)
        return
    }

    if (credentialType == 0) {
        logWarn 'clearCredential: ProgrammingPIN cannot be cleared.'
        return
    }

    int index = (credentialIndex != null) ? credentialIndex : 0xFFFE

    String typeHex  = HexUtils.integerToHexString(credentialType, 1)             // e.g. "01"
    String indexHex = zigbee.swapOctets(HexUtils.integerToHexString(index, 2))  // e.g. "0900"

    // Build TLV dynamically
    String tlv =
            "15" +            // start outer struct
            "35" + "00" +     // context tag 0, STRUCTURE (CredentialStruct)
            "24" + "00" + typeHex +     // tag 0: uint8 credentialType
            "25" + "01" + indexHex +    // tag 1: uint16 credentialIndex (LE)
            "18" +            // end inner struct
            "18"              // end outer struct

    String cmd = "he invoke 0x01 0x0101 0x0026 0x07D0 {1518} {${tlv}}"

    logDebug "clearCredential: type=${credentialType}, index=${index}, tlv=${tlv}, cmd=${cmd}"
    parent?.sendToDevice(cmd)   
}

@Field static final Map<Integer, String> CredentialTypeEnum = [
    0: 'ProgrammingPIN', // Programming PIN code credential type (O)
    1: 'PIN',            // PIN code credential type (PIN)
    2: 'RFID',           // RFID identifier credential type (RID)
    3: 'Fingerprint',    // Fingerprint identifier credential type (FGP)
    4: 'FingerVein',     // Finger vein identifier credential type (FGP)
    5: 'Face'            // Face identifier credential type (FACE)
]

@Field static final Map<Integer, String> DataOperationTypeEnum = [
    0: 'Add',    // Data is being added or was added (M)
    1: 'Clear',  // Data is being cleared or was cleared (M)
    2: 'Modify'  // Data is being modified or was modified (M)
]






















// Command to unbolt door (for locks with separate bolt mechanism)
void unboltDoor() {
    // TODO: check if the lock supports this feature
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', 'unbolting door...')
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x27, 2000)
    parent?.sendToDevice(cmd)
}


// Command to query PIN credential status
void getCredentialStatus(String pinIndex) {
    if (!supportsLockCodes()) {
        logWarn "getCredentialStatus: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }
    
    if (!pinIndex) {
        logWarn "getCredentialStatus: PIN index is required"
        return
    }
    Integer index = pinIndex as Integer
    if (index < 1 || index > 255) {
        logWarn "getCredentialStatus: PIN index must be 1-255, got '${pinIndex}'"
        return
    }
    
    Integer deviceNumber = getDeviceNumber()
    if (deviceNumber == null) return
    
    parent?.componentLog(device, 'debug', "querying PIN credential status for index ${index}...")
    
    // Build GetCredentialStatus command (0x24)
    // Command has single field: credential structure {credentialType: enum8, credentialIndex: uint16}
    // Build TLV manually since we need nested structure
    
    String credIndexHexLE = zigbee.swapOctets(HexUtils.integerToHexString(index, 2))
    
    // Build credential structure (anonymous struct)
    String credentialStruct = '15'  // Structure start (anonymous)
    credentialStruct += '2400' + '01'  // Context tag 0: credentialType = 1 (PIN), UINT8
    credentialStruct += '2501' + credIndexHexLE  // Context tag 1: credentialIndex, UINT16
    credentialStruct += '18'  // Structure end
    
    // Wrap the structure as field 0 of the command
    String cmdPayload = '15'  // Command structure start
    cmdPayload += '30' + credentialStruct  // Context tag 0: credential structure
    cmdPayload += '18'  // Command structure end
    
    logDebug "getCredentialStatus: payload={${cmdPayload}}"
    
    String cmd = matter.invoke(deviceNumber, 0x0101, 0x24) + " {${cmdPayload}}"
    parent?.sendToDevice(cmd)
}



// Helper function to check if setCodeLength is supported by this lock
Boolean isSetCodeLengthEnabled() {
    // TODO: Check FeatureMap or device capabilities to determine support
    return false
}

/**
 * Check if a specific Matter Door Lock feature is enabled on this lock
 * @param featureBit The feature bit to check (use FEATURE_* constants)
 * @return true if the feature is enabled, false otherwise
 */
Boolean isFeatureEnabled(Integer featureBit) {
    // Bypass feature checks if ignoreCompatibilityChecks is enabled
    if (settings?.ignoreCompatibilityChecks == true) {
        logDebug "isFeatureEnabled: ignoreCompatibilityChecks enabled - bypassing feature check for 0x${Integer.toHexString(featureBit).toUpperCase()}"
        return true
    }
    
    // Get FeatureMap from fingerprintData
    Map fingerprint = getFingerprintData()
    String featureMapHex = fingerprint?.get('0101_FFFC')
    
    if (!featureMapHex) {
        logWarn "isFeatureEnabled: FeatureMap not available in fingerprintData - features unknown"
        return false
    }
    
    // Parse FeatureMap value
    Integer featureMap = 0
    try {
        // Remove 0x prefix if present
        featureMapHex = featureMapHex.replaceFirst('^0x', '')
        featureMap = Integer.parseInt(featureMapHex, 16)
    } catch (Exception e) {
        logWarn "isFeatureEnabled: Failed to parse FeatureMap '${featureMapHex}': ${e.message}"
        return false
    }
    
    // Check if the specific feature bit is set
    boolean enabled = (featureMap & featureBit) != 0
    
    logDebug "isFeatureEnabled: FeatureMap=0x${Integer.toHexString(featureMap).toUpperCase()}, checking bit 0x${Integer.toHexString(featureBit).toUpperCase()}: ${enabled}"
    
    return enabled
}

/**
 * Check if this lock supports PIN credential management (LockCodes capability)
 * @return true if PIN credentials and user management are supported
 */
Boolean supportsLockCodes() {
    // Bypass feature checks if ignoreCompatibilityChecks is enabled
    if (settings?.ignoreCompatibilityChecks == true) {
        logDebug "supportsLockCodes: ignoreCompatibilityChecks enabled - bypassing PIN/User feature checks"
        return true
    }
    
    return isFeatureEnabled(FEATURE_PIN_CREDENTIAL) && isFeatureEnabled(FEATURE_USER_MANAGEMENT)
}

/**
 * Helper method for dynamic command parameter display
 * Returns a string indicating whether this device supports PIN code management
 * Used in command metadata to show feature support status to users
 */
String isCodeAllowed() {
    if (false/*supportsLockCodes()*/) {
        return "Your device ${device?.displayName} SUPPORTS PIN code management"
    } else {
        Map fingerprint = getFingerprintData()
        String featureMapHex = fingerprint?.get('0101_FFFC') ?: '??'
        return "Your device ${device?.displayName} <b>does NOT</b> support PIN code management (FeatureMap=0x${featureMapHex})"
    }
}

// ========== LockCodes Capability Methods ==========
// Note: These methods are part of the LockCodes capability which is always declared
// However, not all Matter locks support PIN management. Each method checks feature support.




/**
 * Delete a PIN code (LockCodes capability)
 * @param codePosition Position/slot number (1-based)
 */
void deleteCode(codePosition) {
    if (!supportsLockCodes()) {
        logWarn "deleteCode: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        return
    }
    
    logInfo "deleteCode: position=${codePosition}"
    
    // TODO: Implement ClearCredential command (0x26)
    // May also need to clear the user (ClearUser 0x1D) depending on lock behavior
    
    logWarn "deleteCode: Not yet implemented - requires Matter Credential management"
    sendEvent(name: 'codeChanged', value: "${codePosition} deleted", descriptionText: "deleteCode not yet implemented", isStateChange: true)
}

/**
 * Get all PIN codes (LockCodes capability)
 * This populates the lockCodes attribute with current code information
 */
void getCodes() {
    if (!supportsLockCodes()) {
        logWarn "getCodes: This lock <b>does not</b> support PIN credential management (FeatureMap indicates no PIN/User support)"
        sendEvent(name: 'lockCodes', value: '{}', descriptionText: "Lock <b>does not</b> support PIN codes")
        return
    }
    
    logInfo "getCodes: retrieving all PIN codes"
    
    // TODO: Implement:
    // 1. Get NumberOfPINUsersSupported to know how many to query
    // 2. Loop through GetUser (0x1B) for each position
    // 3. Build lockCodes JSON and update attribute
    
    logWarn "getCodes: Not yet implemented - requires Matter User query"
    sendEvent(name: 'lockCodes', value: '{}', descriptionText: "getCodes not yet implemented")
}

// ========== End LockCodes Capability Methods ==========

// Command to set the maximum PIN code length for this lock (per Hubitat LockCodes capability)
// NOTE: Matter locks have FIXED PIN length constraints (MaxPINCodeLength/MinPINCodeLength are read-only)
// This command only updates the Hubitat codeLength attribute for compatibility
void setCodeLength(BigDecimal length) {
    if (!length) {
        logWarn "setCodeLength: PIN code length is required"
        return
    }
    Integer codeLength = length.toInteger()
    if (codeLength < 4 || codeLength > 8) {
        logWarn "setCodeLength: PIN code length must be 4-8 digits, got '${length}'"
        return
    }
    
    logInfo "setCodeLength: updating Hubitat codeLength attribute to ${codeLength} (Matter locks have fixed PIN length constraints)"
    
    // Update codeLength attribute with digital event type for Hubitat compatibility
    sendEvent(name: 'codeLength', value: codeLength, type: 'digital', descriptionText: "${device.displayName} code length set to ${codeLength}")
}

// Read FeatureMap attribute to see which features are supported
// TODO - move to the main driver
void readFeatureMap() {
    parent?.componentLog(device, 'debug', 'reading FeatureMap attribute...')
    String endpoint = device.getDataValue('id') ?: '1'
    String cluster = '257'  // 0x0101 Door Lock cluster
    String attribute = '65532'  // 0xFFFC FeatureMap
    parent?.readAttribute([endpoint, cluster, attribute])
}


// Helper method to generate info string with feature support status
String generateInfoString() {
    Map fingerprint = getFingerprintData()
    String featureMapHex = fingerprint?.get('0101_FFFC') ?: '??'
    String featureInfo = supportsLockCodes() ? 
        "Your lock ${device.displayName} supports PIN codes/users management" : 
        "Your lock ${device.displayName} <b>does NOT</b> support PIN codes/users management (FeatureMap=0x${featureMapHex})"
    return "${featureInfo}"
}

// Called when the device is first created
void installed() {
    log.info "${device.displayName} driver installed"
    runIn(2, 'updated')  // delay to allow settings to be saved
}

// Called when the device is removed
void uninstalled() {
    log.info "${device.displayName} driver uninstalled"
}

// Called when the settings are updated
void updated() {
    log.info "${device.displayName} driver configuration updated"
    clearOldStateVariables()
    state.info = generateInfoString()
    log.info "${device.displayName} ${state.info}"
    if (logEnable) {
        logDebug settings as String
        runIn(86400, 'logsOff')
    }
}

// Clean up old/deprecated state variables
void clearOldStateVariables() {
    List<String> oldStateVars = ['warning', 'working', 'Warning', 'Working', 'comment', 'info']
    oldStateVars.each { String varName ->
        if (state.containsKey(varName)) {
            logDebug "clearOldStateVariables: removing '${varName}'"
            state.remove(varName)
        }
    }
}

private void logsOff() {
    log.warn "debug logging disabled for ${device.displayName} "
    device.updateSetting('logEnable', [value: 'false', type: 'bool'] )
}

void refresh() {
    clearOldStateVariables()
    parent?.componentRefresh(this.device)
}

// for use by parent driver
void setState(String stateName, String stateValue) {
    logDebug "setting state '${stateName}' to '${stateValue}'"
    state[stateName] = stateValue
}

// for use by parent driver
String getState(String stateName) {
    logDebug "getting state '${stateName}'"
    return state[stateName]
}

/**
 * Get the complete fingerprint data stored in device data
 * @return Map containing fingerprint data or null if not found
 */
Map getFingerprintData() {
    String fingerprintJson = device.getDataValue('fingerprintData')
    if (!fingerprintJson) {
        logDebug "getFingerprintData: fingerprintData not found in device data"
        return null
    }
    
    try {
        return new groovy.json.JsonSlurper().parseText(fingerprintJson)
    } catch (Exception e) {
        logWarn "getFingerprintData: failed to parse fingerprintData: ${e.message}"
        return null
    }
}

/**
 * Get ServerList from fingerprint data
 * @return List of cluster IDs as hex strings (e.g., ["03", "1D", "2F", "0101"])
 */
List<String> getServerList() {
    Map fingerprint = getFingerprintData()
    if (fingerprint == null) {
        logDebug "getServerList: fingerprint data not available"
        return []
    }
    
    return fingerprint['ServerList'] ?: []
}

/**
 * Check if a specific cluster is supported by this device
 * @param clusterHex Cluster ID as hex string (e.g., "0101" for Door Lock)
 * @return true if cluster is in ServerList
 */
boolean isClusterSupported(String clusterHex) {
    List<String> serverList = getServerList()
    return serverList.contains(clusterHex?.toUpperCase())
}

/**
 * Get the Door Lock cluster AttributeList (0x0101_FFFB)
 * @return List of attribute IDs as hex strings (e.g., ["00", "01", "02", ...])
 */
List<String> getDoorLockAttributeList() {
    Map fingerprint = getFingerprintData()
    if (fingerprint == null) {
        logDebug "getDoorLockAttributeList: fingerprint data not available"
        return []
    }
    
    return fingerprint['0101_FFFB'] ?: []
}

/**
 * Check if a specific attribute is supported by the Door Lock cluster
 * @param attrHex Attribute ID as hex string (e.g., "00" for LockState)
 * @return true if attribute is in Door Lock AttributeList
 */
boolean isDoorLockAttributeSupported(String attrHex) {
    List<String> attrList = getDoorLockAttributeList()
    return attrList.contains(attrHex?.toUpperCase())
}

/**
 * Get AcceptedCommandList for Door Lock cluster from fingerprint data
 * @return List of command IDs in hex (e.g., ['00', '01', '02', ...])
 */
List<String> getDoorLockAcceptedCommandList() {
    Map fingerprint = getFingerprintData()
    if (!fingerprint) {
        logDebug "getDoorLockAcceptedCommandList: fingerprint data not available"
        return []
    }
    return fingerprint.get('0101_FFF9') ?: []
}

/**
 * Check if a specific Door Lock command is supported
 * @param commandHex The command ID in hex (e.g., '00', '01', etc.)
 * @return true if command is in the AcceptedCommandList
 */
Boolean isDoorLockCommandSupported(String commandHex) {
    List<String> cmdList = getDoorLockAcceptedCommandList()
    return cmdList.contains(commandHex?.toUpperCase())
}


// Helper function to process event mask attributes (reduces code duplication)
// Returns the message to be logged (caller handles logging)
String processEventMaskAttribute(String attrId, String attrName, Map descMap, Closure decoder) {
    String rawValue = (descMap.value instanceof List) ? 
        (descMap.value.size() > 0 ? descMap.value[0]?.toString() : '00') : 
        descMap.value?.toString()
    String maskValue = rawValue?.take(4) ?: '00'
    Integer mask = safeParseHex(maskValue)
    String decoded = decoder(mask)
    
    if (rawValue?.length() > 4) { 
        logWarn "${attrName}: value truncated from 0x${rawValue}" 
    }
    
    // Build and return message (prefix will be added by caller)
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${attrId}] " : ""
    return "${prefix}${attrName}: 0x${maskValue} - Enabled: ${decoded}"
}

// Helper function to process numeric attributes in handleUnprocessedMessageInChildDriver method
// Returns the message to be logged (caller handles logging)
String processNumericAttribute(String attrName, Map descMap) {
    Integer value = safeHexToInt(descMap.value)
    
    // Build and return message (prefix will be added by caller)
    boolean isInfoMode = state.states?.isInfo == true
    String prefix = isInfoMode ? "[${descMap.attrId}] " : ""
    return "${prefix}${attrName}: ${value}"
}



void processGetCredentialStatusResponse(Map descMap) {
    logDebug "processGetCredentialStatusResponse: descMap=${descMap}"
    
    // Response fields: credentialExists, userIndex, creatorFabricIndex, lastModifiedFabricIndex, nextCredentialIndex
    // For now, just log the raw response to see the format
    logInfo "GetCredentialStatus Response: ${descMap}"
    
    // TODO: Parse TLV response structure once we see the actual format
    // Expected structure: {credentialExists: bool, userIndex: uint16, ...}
}

void processGetUserResponse(Map descMap) {
    logDebug "processGetUserResponse: descMap=${descMap}"
    
    // Response fields: userIndex, userName, userUniqueID, userStatus, userType, credentialRule, credentials, creatorFabricIndex, lastModifiedFabricIndex
    // For now, just log the raw response to see the format
    logInfo "GetUser Response: ${descMap}"
    
    // TODO: Parse TLV response structure once we see the actual format
    // Expected structure: {userIndex: uint16, userName: string, userStatus: enum8, userType: enum8, ...}
}

// 5.2.11. Events 
void processDoorLockEvent(Map eventMap) {
    def evtId = safeToInt(eventMap.evtId)
    logDebug "processDoorLockEvent: evtId=${evtId}"
    
    switch (evtId) {
        case 0x00: // DoorLockAlarm (0x00)
            processDoorLockAlarmEvent(eventMap)
            break
        case 0x01: // DoorStateChange (0x01)
            processDoorStateChangeEvent(eventMap)
            break
        case 0x02: // LockOperation (0x02)
            processLockOperationEvent(eventMap)
            break
        case 0x03: // LockOperationError (0x03)
            processLockOperationErrorEvent(eventMap)
            break
        case 0x04: // LockUserChange (0x04)
            processLockUserChangeEvent(eventMap)
            break
        default:
            logWarn "processDoorLockEvent: unknown evtId=${evtId}"
    }
}

void processDoorLockAlarmEvent(Map eventMap) {
    // Event fields: alarmCode
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    Integer alarmCode = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null

    String alarmText = DoorLockClusterAlarmCode[alarmCode] ?: "Unknown (${alarmCode})"
    String descriptionText = "${device.displayName} ALARM: ${alarmText}"

    logWarn "${descriptionText}"
    sendEvent(name: 'lockAlarm', value: alarmText, descriptionText: descriptionText, isStateChange: true)
}

void processDoorStateChangeEvent(Map eventMap) {
    // Event fields: doorState
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    Integer doorState = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null

    String doorStateText = DoorLockClusterDoorState[doorState] ?: "Unknown (${doorState})"
    String descriptionText = "${device.displayName} door is ${doorStateText}"

    logInfo "${descriptionText}"
    sendEvent(name: 'doorState', value: doorStateText, descriptionText: descriptionText)
}

// 5.2.11.3. LockOperation Event #2
// The door lock server sends out a LockUserChange event when a lock user, schedule, or credential change has occurred.
void processLockOperationEvent(Map eventMap) {
    // Event fields: lockOperationType, operationSource, userIndex, fabricIndex, sourceNode, credentials
    // eventMap = [callbackType:Event, endpointInt:1, clusterInt:257, evtId:2, timestamp:37455661, priority:2, 
    //           data:[2:STRUCT:[
    //              3:NULL:null,        // FabricIndex
    //              0:UINT:1,           // LockOperationType 
    //              1:UINT:7,           // OperationSource
    //              2:NULL:null,        // UserIndex
    //              5:NULL:null,        // Credentials
    //              4:NULL:null]],      // SourceNode
    //           value:[3:null, 0:1, 1:7, 2:null, 5:null, 4:null], 
    //           cluster:0101, endpoint:01]
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    logDebug "processLockOperationEvent: parsed values=${values}"

    Integer lockOpType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer opSource = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer userIndex = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    logDebug "processLockOperationEvent: lockOpType=${lockOpType}, opSource=${opSource}, userIndex=${userIndex}"

    String operation = DoorLockClusterLockOperationType[lockOpType] ?: "Unknown (${lockOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"

    String descriptionText = "${operation} by ${source}" + (userIndex != null ? " (User ${userIndex})" : "")

    // Optimized lock state mapping
    Map lockStateMap = [0: 'locked', 1: 'unlocked']
    String lockState = lockStateMap.get(lockOpType, 'unknown')
    String lockDesc = "${device.displayName} is ${lockState} (${descriptionText})"
    sendEvent(name: 'lock', value: lockState, descriptionText: lockDesc, isStateChange: true)

    logInfo descriptionText
    sendEvent(name: 'lastLockOperation', value: operation, descriptionText: descriptionText, isStateChange: true)
    sendEvent(name: 'lastOperationSource', value: source, descriptionText: descriptionText, isStateChange: true)
}

// LockOperationError (0x03)
void processLockOperationErrorEvent(Map eventMap) {
    // Event fields: lockOperationType, operationSource, operationError, userIndex, fabricIndex, sourceNode, credentials
    logDebug "processLockOperationErrorEvent: description=${eventMap}"
    Map values = eventMap.value instanceof Map ? eventMap.value : [:]
    logDebug "processLockOperationErrorEvent: parsed values=${values}"

    Integer lockOpType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer opSource = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer opError = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    Integer userIndex = values[3] != null && values[3] != 'null' ? safeToInt(values[3]) : null

    String operation = DoorLockClusterLockOperationType[lockOpType] ?: "Unknown (${lockOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"
    String error = DoorLockClusterOperationError[opError] ?: "Unknown (${opError})"

    String descriptionText = "${device.displayName} ${operation} FAILED: ${error} (source: ${source}"
    if (userIndex != null) {
        descriptionText += ", User ${userIndex}"
    }
    descriptionText += ")"

    logWarn "*** ${descriptionText} ***"
    sendEvent(name: 'lastLockOperationError', value: error, descriptionText: descriptionText, isStateChange: true)
}

// LockUserChange (0x04) event
void processLockUserChangeEvent(Map description) {
    // Event fields: lockDataType, dataOperationType, operationSource, userIndex, fabricIndex, sourceNode, dataIndex
    // descMap = [callbackType:Event, endpointInt:1, clusterInt:257, evtId:4, timestamp:946743149680, priority:1, 
    // data:[4:STRUCT:[
    //       0:UINT:6,          // LockDataType -> LockDataTypeEnum
    //       1:UINT:0,          // DataOperationType -> DataOperationTypeEnum
    //       2:UINT:7,          // OperationSource -> OperationSourceEnum (Unspecified, Keypad, Remote)
    //       3:UINT:7,          // UserIndex uint16
    //       4:UINT:1,          // FabricIndex fabric-idx
    //       5:UINT:791750490,  // SourceNode node-id
    //       6:UINT:6           // DataIndex uint16
    // ]]
    // value:[6:6, 3:7, 0:6, 1:0, 4:1, 5:791750490, 2:7], 
    // cluster:0101, endpoint:01]
    //
    Map values = description.value instanceof Map ? description.value : [:]

    Integer lockDataType = values[0] != null && values[0] != 'null' ? safeToInt(values[0]) : null
    Integer dataOpType = values[1] != null && values[1] != 'null' ? safeToInt(values[1]) : null
    Integer opSource = values[2] != null && values[2] != 'null' ? safeToInt(values[2]) : null
    Integer userIndex = values[3] != null && values[3] != 'null' ? safeToInt(values[3]) : null
    Integer fabricIndex = values[4] != null && values[4] != 'null' ? safeToInt(values[4]) : null
    Integer sourceNode = values[5] != null && values[5] != 'null' ? safeToInt(values[5]) : null
    Integer dataIndex = values[6] != null && values[6] != 'null' ? safeToInt(values[6]) : null


    String dataType = DoorLockClusterLockDataType[lockDataType] ?: "Unknown (${lockDataType})"
    String operation = DoorLockClusterDataOperationType[dataOpType] ?: "Unknown (${dataOpType})"
    String source = DoorLockClusterOperationSource[opSource] ?: "Unknown (${opSource})"
    String fabricText = fabricIndex != null ? "Fabric ${fabricIndex}" : "Unknown Fabric"
    String sourceNodeText = sourceNode != null ? "Node ${sourceNode}" : "Unknown Node"
    String dataIndexText = dataIndex != null ? "Data Index ${dataIndex}" : "Unknown Data Index"

    String descriptionText = "${device.displayName} ${dataType} ${operation}"
    if (userIndex != null) {
        descriptionText += " for User ${userIndex}"
    }
    if (dataIndex != null) {
        descriptionText += ", (${dataIndexText})"
    }
    if (fabricIndex != null) {
        descriptionText += ", (${fabricText})"
    }
    if (sourceNode != null) {
        descriptionText += ", (${sourceNodeText})"
    }
    descriptionText += " (source: ${source})"

    logInfo "${descriptionText}"
    sendEvent(name: 'lastUserChange', value: "${operation} ${dataType}", descriptionText: descriptionText, isStateChange: true)
}

// Command to get all supported Door Lock attributes (for info/debugging)
void getInfo() {
    // Check if Door Lock cluster is supported
    if (!isClusterSupported('0101')) {
        logWarn "getInfo: Door Lock cluster (0x0101) is not supported by this device"
        logInfo "getInfo: ServerList contains: ${getServerList()}"
        return
    }
    logInfo "getInfo: reading all supported Door Lock attributes: ${getDoorLockAttributeList()}"
    
    // Set state flags for info mode
    if (state.states == null) { state.states = [:] }
    if (state.lastTx == null) { state.lastTx = [:] }
    state.states.isInfo = true
    state.lastTx.infoTime = now()
    
    // Schedule job to turn off info mode after 10 seconds
    runIn(10, 'clearInfoMode')
    
    String endpointHex = device.getDataValue('id') ?: '1'
    Integer endpoint = HexUtils.hexStringToInt(endpointHex)
    parent?.readAttribute(endpoint, 0x0101, -1)      // 0x00 Door Lock cluster - read all attributes
    // battery info is processed in parent driver !
    // parent?.readAttribute(endpoint, 0x002F, -1)       // 0x002F Power Source cluster - read all attributes
}

// Clear info mode flag (called by scheduled job)
void clearInfoMode() {
    if (state.states == null) { state.states = [:] }
    state.states.isInfo = false
    logDebug "clearInfoMode: info mode disabled"
}

// ============ Matter Door Lock Cluster Attributes Map ============
// Complete list of all Door Lock cluster (0x0101) attributes per Matter spec
@Field static final Map<Integer, String> DoorLockClusterAttributes = [
    // Mandatory and common attributes
    0x0000  : 'LockState',                                          // LockStateEnum, R V, M
    0x0001  : 'LockType',                                           // LockTypeEnum, R V, M
    0x0002  : 'ActuatorEnabled',                                    // bool, R V, M
    0x0003  : 'DoorState',                                          // DoorStateEnum, R V, DPS
    0x0004  : 'DoorOpenEvents',                                     // uint32, RW, DPS
    0x0005  : 'DoorClosedEvents',                                   // uint32, RW, DPS
    0x0006  : 'OpenPeriod',                                         // uint16, RW, DPS
    
    // User and credential management
    0x0010  : 'NumberOfLogRecordsSupported',                        // uint16, R V, O
    0x0011  : 'NumberOfTotalUsersSupported',                        // uint16, R V, USR
    0x0012  : 'NumberOfPINUsersSupported',                          // uint16, R V, PIN
    0x0013  : 'NumberOfRFIDUsersSupported',                         // uint16, R V, RID
    0x0014  : 'NumberOfWeekDaySchedulesSupportedPerUser',           // uint8, R V, WDSCH
    0x0015  : 'NumberOfYearDaySchedulesSupportedPerUser',           // uint8, R V, YDSCH
    0x0016  : 'NumberOfHolidaySchedulesSupported',                  // uint8, R V, HDSCH
    0x0017  : 'MaxPINCodeLength',                                   // uint8, R V, PIN
    0x0018  : 'MinPINCodeLength',                                   // uint8, R V, PIN
    0x0019  : 'MaxRFIDCodeLength',                                  // uint8, R V, RID
    0x001A  : 'MinRFIDCodeLength',                                  // uint8, R V, RID
    0x001B  : 'CredentialRulesSupport',                             // DlCredentialRuleMask, R V, USR
    0x001C  : 'NumberOfCredentialsSupportedPerUser',                // uint8, R V, USR
    
    // Lock configuration attributes
    0x0020  : 'EnableLogging',                                      // bool, RW, O
    0x0021  : 'Language',                                           // string, RW, O
    0x0022  : 'LEDSettings',                                        // uint8, RW, O
    0x0023  : 'AutoRelockTime',                                     // uint32, RW, O
    0x0024  : 'SoundVolume',                                        // uint8, RW, O
    0x0025  : 'OperatingMode',                                      // OperatingModeEnum, RW, M
    0x0026  : 'SupportedOperatingModes',                            // DlSupportedOperatingModes, R V, M
    0x0027  : 'DefaultConfigurationRegister',                       // DlDefaultConfigurationRegister, R V, O
    0x0028  : 'EnableLocalProgramming',                             // bool, RW, O
    0x0029  : 'EnableOneTouchLocking',                              // bool, RW, O
    0x002A  : 'EnableInsideStatusLED',                              // bool, RW, O
    0x002B  : 'EnablePrivacyModeButton',                            // bool, RW, O
    0x002C  : 'LocalProgrammingFeatures',                           // DlLocalProgrammingFeatures, RW, O
    
    // Security and access control
    0x0030  : 'WrongCodeEntryLimit',                                // uint8, RW, O
    0x0031  : 'UserCodeTemporaryDisableTime',                       // uint8, RW, O
    0x0032  : 'SendPINOverTheAir',                                  // bool, RW, O
    0x0033  : 'RequirePINforRemoteOperation',                       // bool, RW, O
    0x0034  : 'SecurityLevel',                                      // SecurityLevelEnum, RW, O (Deprecated)
    0x0035  : 'ExpiringUserTimeout',                                // uint16, RW, O
    
    // Event masks (Notification feature)
    0x0040  : 'AlarmMask',                                          // DlAlarmMask, RW, NOT
    0x0041  : 'KeypadOperationEventMask',                           // DlKeypadOperationEventMask, RW, NOT
    0x0042  : 'RemoteOperationEventMask',                           // DlRemoteOperationEventMask, RW, NOT
    0x0043  : 'ManualOperationEventMask',                           // DlManualOperationEventMask, RW, NOT
    0x0044  : 'RFIDOperationEventMask',                             // DlRFIDOperationEventMask, RW, NOT
    0x0045  : 'KeypadProgrammingEventMask',                         // DlKeypadProgrammingEventMask, RW, NOT
    0x0046  : 'RemoteProgrammingEventMask',                         // DlRemoteProgrammingEventMask, RW, NOT
    0x0047  : 'RFIDProgrammingEventMask',                           // DlRFIDProgrammingEventMask, RW, NOT
    
    // Standard cluster attributes
    0xFFFB  : 'AttributeList',                                      // list, R V, M
    0xFFFC  : 'FeatureMap',                                         // FeatureMap, R V, M
    0xFFFD  : 'ClusterRevision'                                     // uint16, R V, M
]

// Aqara U200 : [FFF9] AcceptedCommandList: [0000, 0001, 0003, 001A, 001B, 001D, 0022, 0024, 0026]
// Aqara U200 : [FFF8] GeneratedCommandList: [001C, 0023, 0025]

@Field static final Map<Integer, String> DoorLockClusterCommands = [
    // Command ID : Name (per Matter 5.2.10)
    0x00    : 'LockDoor',                    // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:M
    0x01    : 'UnlockDoor',                  // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:M
    0x02    : 'Toggle',                      // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:X
    0x03    : 'UnlockWithTimeout',           // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:O
    0x04    : 'GetLogRecord',                // Direction:client ⇒ server; Response:GetLogRecordResponse; Access:M; Conformance:LOG
    0x05    : 'SetPINCode',                  // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x06    : 'GetPINCode',                  // Direction:client ⇒ server; Response:GetPINCodeResponse; Access:A; Conformance:!USR & PIN
    0x07    : 'ClearPINCode',                // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x08    : 'ClearAllPINCodes',            // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & PIN
    0x09    : 'SetUserStatus',               // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x0A    : 'GetUserStatus',               // Direction:client ⇒ server; Response:GetUserStatusResponse; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x0B    : 'SetWeekDaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:WDSCH
    0x0C    : 'GetWeekDaySchedule',          // Direction:client ⇒ server; Response:GetWeekDayScheduleResponse; Access:A; Conformance:WDSCH
    0x0D    : 'ClearWeekDaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:WDSCH
    0x0E    : 'SetYearDaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:YDSCH
    0x0F    : 'GetYearDaySchedule',          // Direction:client ⇒ server; Response:GetYearDayScheduleResponse; Access:A; Conformance:YDSCH
    0x10    : 'ClearYearDaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:YDSCH
    0x11    : 'SetHolidaySchedule',          // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:HDSCH
    0x12    : 'GetHolidaySchedule',          // Direction:client ⇒ server; Response:GetHolidayScheduleResponse; Access:A; Conformance:HDSCH
    0x13    : 'ClearHolidaySchedule',        // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:HDSCH
    0x14    : 'SetUserType',                 // Direction:client ⇒ server; Response:Yes; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x15    : 'GetUserType',                 // Direction:client ⇒ server; Response:GetUserTypeResponse; Access:A; Conformance:!USR & (PIN | RID | FGP)
    0x16    : 'SetRFIDCode',                 // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x17    : 'GetRFIDCode',                 // Direction:client ⇒ server; Response:GetRFIDCodeResponse; Access:A; Conformance:!USR & RID
    0x18    : 'ClearRFIDCode',               // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x19    : 'ClearAllRFIDCodes',           // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:!USR & RID
    0x1A    : 'SetUser',                     // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x1B    : 'GetUser',                     // Direction:client ⇒ server; Response:GetUserResponse; Access:A; Conformance:USR
    0x1C    : 'GetUserResponse',             // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x1D    : 'ClearUser',                   // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x20    : 'OperatingEventNotification',  // Direction:client ⇐ server; Response:No; Access:N; Conformance:[NOT]
    0x21    : 'ProgrammingEventNotification',// Direction:client ⇐ server; Response:No; Access:N; Conformance:[NOT]
    0x22    : 'SetCredential',               // Direction:client ⇒ server; Response:SetCredentialResponse; Access:A T; Conformance:USR
    0x23    : 'SetCredentialResponse',       // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x24    : 'GetCredentialStatus',         // Direction:client ⇒ server; Response:GetCredentialStatusResponse; Access:A; Conformance:USR
    0x25    : 'GetCredentialStatusResponse', // Direction:client ⇐ server; Response:No; Access:N; Conformance:USR
    0x26    : 'ClearCredential',             // Direction:client ⇒ server; Response:Yes; Access:A T; Conformance:USR
    0x27    : 'UnboltDoor'                   // Direction:client ⇒ server; Response:Yes; Access:O T; Conformance:UBOLT
]



// 5.2.6.2. LockState Attribute (0x0000)
@Field static final Map<Integer, String> DoorLockClusterLockState = [
    0x00    : 'NotFullyLocked',
    0x01    : 'Locked',
    0x02    : 'Unlocked',
    0x03    : 'Unlatched'   // optional
]

// 5.2.6.3. LockType Attribute (0x0001)
@Field static final Map<String, String> DooorLockClusterLockType = [
    0x00    : 'deadbolt',   // Physical lock type is dead bolt
    0x01    : 'magnetic',   // Physical lock type is magnetic
    0x02    : 'other',      // Physical lock type is other
    0x03    : 'mortise',    // Physical lock type is mortise
    0x04    : 'rim',        // Physical lock type is rim
    0x05    : 'latchbolt',  // Physical lock type is latch bolt
    0x06    : 'cylindricalLock',// Physical lock type is cylindrical lock
    0x07    : 'tubularLock',    // Physical lock type is tubular lock
    0x08    : 'interconnectedLock', // Physical lock type is interconnected lock
    0x09    : 'deadLatch',  // Physical lock type is dead latch
    0x0A    : 'doorFurniture', // Physical lock type is door furniture
    0x0B    : 'eurocylinder'   // Physical lock type is eurocylinder
]

/*
The ActuatorEnabled attribute indicates if the lock is currently able to (Enabled) or not able to (Disabled)
process remote Lock, Unlock, or Unlock with Timeout commands.
This attribute has the following possible values:
Boolean Value Summary
0 Disabled
1 Enabled
*/

@Field static final Map<Integer, String> DoorLockClusterSupportedOperatingModes = [
    0x00    : 'Normal',             // (mandatory)
    0x01    : 'Vacation',
    0x02    : 'Privacy',
    0x03    : 'NoRemoteLockUnlock', // (mandatory)
    0x04    : 'Passage'
]

@Field static final Map<Integer, String> DoorLockClusterOperatingModeEnum = [
    0x00    : 'Normal',
    0x01    : 'Vacation',
    0x02    : 'Privacy',
    0x03    : 'NoRemoteLockUnlock',
    0x04    : 'Passage'
]

// Door Lock Event Enums
@Field static final Map<Integer, String> DoorLockClusterAlarmCode = [
    0x00    : 'LockJammed',
    0x01    : 'LockFactoryReset',
    0x03    : 'LockRadioPowerCycled',
    0x04    : 'WrongCodeEntryLimit',
    0x05    : 'FrontEsceutcheonRemoved',
    0x06    : 'DoorForcedOpen',
    0x07    : 'DoorAjar',
    0x08    : 'ForcedUser'
]

@Field static final Map<Integer, String> DoorLockClusterDoorState = [
    0x00    : 'Open',
    0x01    : 'Closed',
    0x02    : 'Jammed',
    0x03    : 'ForcedOpen',
    0x04    : 'UnspecifiedError',
    0x05    : 'Ajar'
]

@Field static final Map<Integer, String> DoorLockClusterLockOperationType = [
    0x00    : 'Lock',
    0x01    : 'Unlock',
    0x02    : 'NonAccessUserEvent',
    0x03    : 'ForcedUserEvent',
    0x04    : 'Unlatch'
]

@Field static final Map<Integer, String> DoorLockClusterOperationSource = [
    0x00    : 'Unspecified',
    0x01    : 'Manual',
    0x02    : 'ProprietaryRemote',
    0x03    : 'Keypad',
    0x04    : 'Auto',
    0x05    : 'Button',
    0x06    : 'Schedule',
    0x07    : 'Remote',
    0x08    : 'RFID',
    0x09    : 'Biometric'
]

@Field static final Map<Integer, String> DoorLockClusterOperationError = [
    0x00    : 'Unspecified',
    0x01    : 'InvalidCredential',
    0x02    : 'DisabledUserDenied',
    0x03    : 'Restricted',
    0x04    : 'InsufficientBattery'
]

@Field static final Map<Integer, String> DoorLockClusterLockDataType = [
    0x00    : 'Unspecified',
    0x01    : 'ProgrammingCode',
    0x02    : 'UserIndex',
    0x03    : 'WeekDaySchedule',
    0x04    : 'YearDaySchedule',
    0x05    : 'HolidaySchedule',
    0x06    : 'PIN',
    0x07    : 'RFID',
    0x08    : 'Fingerprint',
    0x09    : 'FingerVein',
    0x0A    : 'Face'
]

@Field static final Map<Integer, String> DoorLockClusterDataOperationType = [
    0x00    : 'Add',
    0x01    : 'Clear',
    0x02    : 'Modify'
]


// Helper method to decode CredentialRulesSupport bitmap
String decodeCredentialRules(Integer rules) {
    List<String> supported = []
    if (rules & 0x01) { supported.add('Single') }
    if (rules & 0x02) { supported.add('Dual') }
    if (rules & 0x04) { supported.add('Triple') }
    return supported.isEmpty() ? 'None' : supported.join(', ')
}


// 5.2.4. Features This cluster SHALL support the FeatureMap bitmap attribute as defined below.
String decodeFeatureMap(Integer featureMap) {
    if (featureMap == 0) { return 'None (Mandatory features only)' }
    List<String> features = []
    
    if (featureMap & 0x0001) { features.add('PIN') }                     // Bit 0   PIN - Lock supports PIN credentials (via keypad, or over-the-air)
    if (featureMap & 0x0002) { features.add('RFID') }                    // Bit 1   RID - Lock supports RFID credentials
    if (featureMap & 0x0004) { features.add('Fingerprint') }             // Bit 2   FGP - Lock supports finger related credentials (fingerprint, finger vein)
    if (featureMap & 0x0008) { features.add('Logging') }                 // Bit 3   LOG
    if (featureMap & 0x0010) { features.add('WeekDaySchedules') }        // Bit 4   WDSCH
    if (featureMap & 0x0020) { features.add('DoorPositionSensor') }      // Bit 5   DPS
    if (featureMap & 0x0040) { features.add('FaceCredential') }          // Bit 6   FACE
    if (featureMap & 0x0080) { features.add('COTA') }                    // Bit 7   COTA - CredentialOverTheAirAccess - PIN codes overtheair supported for lock/unlock operations
    if (featureMap & 0x0100) { features.add('UserManagement') }          // Bit 8   USR - [ PIN | RID | FGP |FACE ] - Lock supports the user commands and database
    if (featureMap & 0x0200) { features.add('Notification') }            // Bit 9   NOT
    if (featureMap & 0x0400) { features.add('YearDaySchedules') }        // Bit 10  YDSCH
    if (featureMap & 0x0800) { features.add('HolidaySchedules') }        // Bit 11  HDSCH
    if (featureMap & 0x1000) { features.add('Unbolt') }                  // Bit 12  UBOLT - Unbolting - Lock supports unbolting
    
    return features.join(', ')
}

// Helper method to decode KeypadOperationEventMask bitmap (DlKeypadOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidPIN
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidCode
// Bit 6 (0x40): UnlockInvalidSchedule
// Bit 7 (0x80): NonAccessUserOpEvent
String decodeKeypadOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidPIN') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidCode') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    if (mask & 0x80) { enabled.add('NonAccessUserOpEvent') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode KeypadProgrammingEventMask bitmap (DlKeypadProgrammingEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ProgrammingPINChanged
// Bit 2 (0x04): PINAdded
// Bit 3 (0x08): PINCleared
// Bit 4 (0x10): PINChanged
// Bit 6 (0x40): OUT OF SPEC - possibly Nuki proprietary extension
String decodeKeypadProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ProgrammingPINChanged') }
    if (mask & 0x04) { enabled.add('PINAdded') }
    if (mask & 0x08) { enabled.add('PINCleared') }
    if (mask & 0x10) { enabled.add('PINChanged') }
    if (mask & 0x20) { enabled.add('Reserved(0x20)') }
    if (mask & 0x40) { enabled.add('Unknown/Proprietary(0x40)') }  // Nuki specific?
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode RemoteOperationEventMask bitmap (DlRemoteOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidCode
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidCode
// Bit 6 (0x40): UnlockInvalidSchedule
String decodeRemoteOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidCode') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidCode') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode ManualOperationEventMask bitmap (DlManualOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ThumbturnLock
// Bit 2 (0x04): ThumbturnUnlock
// Bit 3 (0x08): OneTouchLock
// Bit 4 (0x10): KeyLock
// Bit 5 (0x20): KeyUnlock
// Bit 6 (0x40): AutoLock
// Bit 7 (0x80): ScheduleLock
// Bit 8 (0x100): ScheduleUnlock
// Bit 9 (0x200): ManualLock
// Bit 10 (0x400): ManualUnlock
String decodeManualOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ThumbturnLock') }
    if (mask & 0x04) { enabled.add('ThumbturnUnlock') }
    if (mask & 0x08) { enabled.add('OneTouchLock') }
    if (mask & 0x10) { enabled.add('KeyLock') }
    if (mask & 0x20) { enabled.add('KeyUnlock') }
    if (mask & 0x40) { enabled.add('AutoLock') }
    if (mask & 0x80) { enabled.add('ScheduleLock') }
    if (mask & 0x100) { enabled.add('ScheduleUnlock') }
    if (mask & 0x200) { enabled.add('ManualLock') }
    if (mask & 0x400) { enabled.add('ManualUnlock') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// Helper method to decode RFIDOperationEventMask bitmap (DlRFIDOperationEventMask)
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): Lock
// Bit 2 (0x04): Unlock
// Bit 3 (0x08): LockInvalidRFID
// Bit 4 (0x10): LockInvalidSchedule
// Bit 5 (0x20): UnlockInvalidRFID
// Bit 6 (0x40): UnlockInvalidSchedule
String decodeRFIDOperationEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('Lock') }
    if (mask & 0x04) { enabled.add('Unlock') }
    if (mask & 0x08) { enabled.add('LockInvalidRFID') }
    if (mask & 0x10) { enabled.add('LockInvalidSchedule') }
    if (mask & 0x20) { enabled.add('UnlockInvalidRFID') }
    if (mask & 0x40) { enabled.add('UnlockInvalidSchedule') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// AlarmMask (0x0080) decoder
// Bit 0 (0x01): LockJammed
// Bit 1 (0x02): LockFactoryReset
// Bit 2 (0x04): LockRadioPowerCycled
// Bit 3 (0x08): WrongCodeEntryLimit
// Bit 4 (0x10): FrontEscutcheonRemoved
// Bit 5 (0x20): DoorForcedOpen
// Bit 6 (0x40): DoorAjar
// Bit 7 (0x80): ForcedUser
String decodeAlarmMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('LockJammed') }
    if (mask & 0x02) { enabled.add('LockFactoryReset') }
    if (mask & 0x04) { enabled.add('LockRadioPowerCycled') }
    if (mask & 0x08) { enabled.add('WrongCodeEntryLimit') }
    if (mask & 0x10) { enabled.add('FrontEscutcheonRemoved') }
    if (mask & 0x20) { enabled.add('DoorForcedOpen') }
    if (mask & 0x40) { enabled.add('DoorAjar') }
    if (mask & 0x80) { enabled.add('ForcedUser') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// RemoteProgrammingEventMask (0x0046) decoder - per Matter specification
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): ProgrammingPINChanged
// Bit 2 (0x04): PINAdded
// Bit 3 (0x08): PINCleared
// Bit 4 (0x10): PINChanged
// Bit 5 (0x20): PINCodeDuplicate
// Bit 6 (0x40): Reserved
// Bit 7 (0x80): Reserved
String decodeRemoteProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('ProgrammingPINChanged') }
    if (mask & 0x04) { enabled.add('PINAdded') }
    if (mask & 0x08) { enabled.add('PINCleared') }
    if (mask & 0x10) { enabled.add('PINChanged') }
    if (mask & 0x20) { enabled.add('PINCodeDuplicate') }
    if (mask & 0x40) { enabled.add('Reserved(0x40)') }
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// RFIDProgrammingEventMask (0x0047) decoder - per Matter specification
// Bit 0 (0x01): Unknown
// Bit 1 (0x02): RFIDCodeAdded
// Bit 2 (0x04): RFIDCodeCleared
// Bit 3 (0x08): RFIDCodeDuplicate
// Bit 4 (0x10): RFIDCodeInvalid
// Bit 5 (0x20): RFIDCodeChanged
// Bit 6 (0x40): Reserved
// Bit 7 (0x80): Reserved
String decodeRFIDProgrammingEventMask(Integer mask) {
    List<String> enabled = []
    if (mask & 0x01) { enabled.add('Unknown') }
    if (mask & 0x02) { enabled.add('RFIDCodeAdded') }
    if (mask & 0x04) { enabled.add('RFIDCodeCleared') }
    if (mask & 0x08) { enabled.add('RFIDCodeDuplicate') }
    if (mask & 0x10) { enabled.add('RFIDCodeInvalid') }
    if (mask & 0x20) { enabled.add('RFIDCodeChanged') }
    if (mask & 0x40) { enabled.add('Reserved(0x40)') }
    if (mask & 0x80) { enabled.add('Reserved(0x80)') }
    return enabled.isEmpty() ? 'None' : enabled.join(', ')
}

// ============ Lock Command Helper Methods ============

/**
 * Convert ASCII PIN string to hex bytes
 * @param s ASCII string (e.g., "123456")
 * @return hex string (e.g., "313233343536")
 */
private static String asciiToHex(final String s) {
    if (s == null) return ''
    byte[] bytes = s.getBytes('US-ASCII')
    return bytes.collect { String.format('%02X', it) }.join()
}

@Field static final String DRIVER = 'Matter Advanced Bridge'
@Field static final String COMPONENT = 'Matter Generic Component Door Lock'
@Field static final String WIKI   = 'Get help on GitHub Wiki page:'
@Field static final String COMM_LINK =   "https://community.hubitat.com/t/release-matter-advanced-bridge-limited-device-support/135252/1"
@Field static final String GITHUB_LINK = "https://github.com/kkossev/Hubitat---Matter-Advanced-Bridge/wiki/Matter-Advanced-Bridge-%E2%80%90-Door-Locks"
// credits @jtp10181
String fmtHelpInfo(String str) {
	String info = "${DRIVER} v${parent?.version()}<br> ${COMPONENT} v${matterComponentLockVersion}"
	String prefLink = "<a href='${GITHUB_LINK}' target='_blank'>${WIKI}<br><div style='font-size: 70%;'>${info}</div></a>"
    String topStyle = "style='font-size: 18px; padding: 1px 12px; border: 2px solid green; border-radius: 6px; color: green;'"
    String topLink = "<a ${topStyle} href='${COMM_LINK}' target='_blank'>${str}<br><div style='font-size: 14px;'>${info}</div></a>"

	return "<div style='font-size: 160%; font-style: bold; padding: 2px 0px; text-align: center;'>${prefLink}</div>" +
		"<div style='text-align: center; position: absolute; top: 46px; right: 60px; padding: 0px;'><ul class='nav'><li>${topLink}</ul></li></div>"
}


// Helper method to safely parse hex string to Integer
Integer safeParseHex(String hexValue) {
    try {
        return Integer.parseInt(hexValue, 16)
    } catch (NumberFormatException e) {
        logWarn "safeParseHex: failed to parse '${hexValue}', returning 0"
        return 0
    }
}


def testInvoke(params) {
    // 0x01 0x0101 0x0000 0x07D0 {1518}
    logDebug "testInvoke called with params: ${params}"
    String cmd = "he invoke ${params}"
    log.warn "testInvoke: sending command: ${cmd}"
    parent?.sendToDevice(cmd)    

}

// --------- common matter libraries included below --------

#include kkossev.matterCommonLib
#include kkossev.matterHealthStatusLib
